/* eslint-disable */
import React, { useState, useRef, useEffect } from "react";
import "./Grid.css";
import useFetch from "../../api/useFetch";

import { getinventorycsvdownloadsApiURL } from "../../utils/apiURLs";
const SaveAction = (props) => {
  /* Helper function */
  function download_file(fileURL, fileName) {
    var save = document.createElement("a");
    save.href = fileURL;
    save.target = "_parent";
    // var filename = fileURL?.substring(fileURL.lastIndexOf("/") + 1);
    save.download = fileName;
    var evt = new MouseEvent("click", {
      view: window,
      bubbles: true,
      cancelable: false,
    });
    save.dispatchEvent(evt);
  }

  const getCSVData = () => {
    download_file(props.data.csv_download_link, "Report.csv");
  };

  return (
    <button
      type="button"
      className={
        (props.data.updated_status === "Pending" || props.data.updated_status == "NA")
          ? "savebtninventorydisabled"
          : "savebtninventory"
      }
      onClick={getCSVData}
    >
      Request Download
    </button>
  );
};
export default SaveAction;
