import React, { useEffect, useState } from "react";
import { makeStyles, Theme } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Paper from "@material-ui/core/Paper";
import "../../Pages/Header.css";
import "../../Pages/Level2Header.css";
import userLogo from "../../images/Back Arrow.svg";

const useStyles = makeStyles({
  root: {},
});

const Level2Header_IR = (props) => {
  return (
    <div className="disp_flex Level2_IR">
      <div
        className={
          "level2HeaderTitle" + (props.isLoading ? " level2TabLoading" : "")
        }
        onClick={() => props.onChange(0)}
      >
        <div className="disp_flex alignitemsCenter">
          <img className="homepageIcon" src={userLogo} alt="user_logo"></img>
        </div>
      </div>
      <div
        className={
          "level2HeaderTitle" + (props.value == 1 ? " bottomBorder_IR" : "")
        }
      >
        Inventory API Reports
      </div>
    </div>
  );
};

export default Level2Header_IR;
