/* eslint-disable */
export const cellbg = (params) => {
  let classnames = "";
  const bgClr = params.node.selected ? " greenColor " : " whiteColor ";
  const is_expired = params.data.is_expired === 1;
  classnames = (is_expired ? " disableCell " : bgClr) + classnames;

  if (params.colDef.field == "sku") {
    classnames =
      classnames +
      " skuTextStyle skuHeaderClass" +
      (is_expired ? " skuCell" : "");
  }

  return classnames;
};

const GridColumns_IR = () => {
  let defaultdridcols = [
    {
      headerName: "Request Id",
      field: "request_id",
      tooltipField: "request_id",
      flex: 1,
      cellClass: cellbg,
      cellStyle: {
        borderRight: "1px solid lightgrey !important",
        borderBottom: "1px solid #E8E7E6 !important",
      },
    },
    {
      headerName: "Date&Time",
      field: "created_at",
      cellRenderer: "DateTime",
      flex: 1,
      cellClass: cellbg,
      cellStyle: {
        borderRight: "1px solid lightgrey !important",
        borderBottom: "1px solid #E8E7E6 !important",
      },
    },
    {
      headerName: "Request status",
      field: "request_status",
      flex: 1,
      cellClass: cellbg,
      valueGetter: (params) => {
        console.log("params", params);
        return params.data.request_status === 1 ? "Accepted" : "Rejected";
      },
      cellStyle: {
        borderRight: "1px solid lightgrey !important",
        borderBottom: "1px solid #E8E7E6 !important",
      },
    },
    {
      headerName: "Update status",
      field: "updated_status",
      flex: 1,
      cellClass: cellbg,
      cellStyle: {
        borderRight: "1px solid lightgrey !important",
        borderBottom: "1px solid #E8E7E6 !important",
      },
    },
    {
      headerName: "Action",
      field: "action",
      cellRenderer: "saveaction",
      flex: 1,
      lockPinned: true,
      cellClass: cellbg,
      cellStyle: {
        borderBottom: "1px solid #E8E7E6 !important",
      },
    },
  ];
  return defaultdridcols;
};

export default GridColumns_IR;
