/* eslint-disable */
import React, { useEffect, useRef, useState } from "react";
import { faCaretDown } from "@fortawesome/free-solid-svg-icons";
import { library } from "@fortawesome/fontawesome-svg-core";
import AttributeOptions from "./AttributeOptions_IR";
//import NoOptions from "./NoOptions";
//import { selectAllItem, selectAllGtm } from "../../gtm";
import arrowDown from "../../images/blueArrow.svg";

library.add(faCaretDown);

const MultiCheckbox = (props) => {
  const [isOpen, setIsOpen] = useState(false);
  const [listItems, setListItems] = useState([]);
  const [checkedValues, setCheckedValues] = useState([]);
  const [checkboxLabel, setCheckboxLabel] = useState(props.label);

  const wrapperRef = useRef(null);

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  });

  /**
   * Hide Component Dropdown if clicked on outside of element
   */
  const handleClickOutside = (event) => {
    if (wrapperRef && !wrapperRef?.current?.contains(event.target)) {
      if (isOpen) {
        setIsOpen(false);
      }
    }
  };
  const loadDropDown = (event) => {
    if (props?.inventoryData?.length !== 0 && !props.status) {
      setListItems(props.options);
      setIsOpen(!isOpen);
    }
  };

  let renderSearchOption = props.options ? props.options : [];
  let searchInputClass = "search-option";

  const setValues = (event) => {
    if (event.target.checked) {
      let value = event.target.value;
      if (
        typeof props.selectedTab !== "undefined" &&
        props.selectedTab == "new" &&
        checkedValues.length + 1 > 10
      ) {
        return false;
      }
      const selectedItems = [...checkedValues, value];
      setCheckedValues(selectedItems);
    } else {
      removeOptions(event);
    }
  };

  const removeOptions = (e) => {
    var array = [...checkedValues]; // make a separate copy of the array
    var index = array.indexOf(e.target.value);
    if (index !== -1) {
      array.splice(index, 1);
      setCheckedValues(array);
    }
  };

  const isChecked = (value) => {
    var array = [...checkedValues]; // make a separate copy of the array
    var index = array.indexOf(value);
    return index !== -1 ? true : false;
  };

  const handleApply = () => {
    const items = checkedValues.map((item) => {
      return item === "Accepted" ? 1 : 2;
    });
    let selectedItems =
      props.label === "Request Status" ? items : checkedValues;
    setCheckboxLable();
    let json = {
      label: props.label,
      value: selectedItems,
    };
    props.changeFilter(json);
    props.onApply(selectedItems, props.label);
    setIsOpen(!isOpen);
  };

  useEffect(() => {
    if (props.resetFilter && checkedValues.length > 0) {
      setCheckedValues([]);
      setCheckboxLabel(props.label);
    }
  }, [props, checkedValues]);

  const setCheckboxLable = () => {
    setIsOpen(false);
    if (checkedValues.length > 1) {
      setCheckboxLabel(checkedValues.length + " selected");
    } else if (checkedValues.length == 1) {
      let label =
        checkedValues[0].length <= 6
          ? checkedValues[0]
          : checkedValues[0].substring(0, 6) + "...";
      setCheckboxLabel(label);
    } else {
      setCheckboxLabel(props.label);
    }
  };

  const handleReset = () => {
    setCheckedValues([]);
    setCheckboxLabel(props.label);
    setIsOpen(false);
    props.onReset([], props.label);
    let json = {
      label: props.label,
      value: [],
    };
    props.changeFilter(json);
  };
  return (
    <div ref={wrapperRef} className="main-select-wrapper">
      <div
        className={
          props?.inventoryData == null && props.status === false
            ? "filterdropdowninventorydisable filterdropdowninventory"
            : "filterdropdowninventory"
        }
        onClick={loadDropDown}
      >
        <div style={{ display: "flex" }}>
          <span
            className={
              props.status ? "div_row labelInventory" : "labelInventory"
            }
          >
            {checkboxLabel}
          </span>
          {props.status && (
            <span className="icon-cross">
              <i
                class="fa fa-times"
                aria-hidden="true"
                onClick={handleReset}
              ></i>
            </span>
          )}
        </div>
        <span>
          <img
            src={arrowDown}
            height="15px"
            className={isOpen ? " rotateIcon" : ""}
          />
        </span>
      </div>
      {isOpen && (
        <AttributeOptions
          setValues={setValues}
          handleApply={handleApply}
          renderSearchOption={renderSearchOption}
          searchInputClass={searchInputClass}
          isChecked={isChecked}
          checkedValues={checkedValues}
        />
      )}
    </div>
  );
};

export default MultiCheckbox;
