import React, { useEffect, useState } from "react";
import Grid from "./Grid_IR";
import HeaderIR from "./Header_IR";
import Level2HeaderIR from "./Level2Header_IR";
import Filters from "./Filters_IR";
import GoToTopLogo from "../../images/Top_Icon.png";
import stickyGridHeader from "./stickyGridHeader";
import useFetch from "../../api/useFetch";
import {
  inventoryOfferListListAPI,
  inventoryFilterListListAPI,
} from "../../utils/apiURLs";
import "./Grid.css";
const Dashboard = (props) => {
  const [level2Headervalue, setLevel2Headervalue] = useState(1);
  const [fetchedData, setFetchedFilterData] = useState();
  const [status, setStatus] = useState(true);
  const [inventoryData, setInventoryData] = useState([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const [pageNo, SetPageNo] = useState(1);
  const [selectLimit, setSelectedLimit] = useState(10);
  const [searchParam, setSearchParam] = useState("");
  const [reqStatus, setRequestStatus] = useState([]);
  const [updStatus, setUpdatedStatus] = useState([]);
  const [isFilterSearch, setIsFilterSearch] = useState(false);
  const [selectedPage, setSelectedPage] = useState(1);
  const [sortBy, setSortBy] = useState();
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  const [{ data }, fetchData] = useFetch("POST", "/inventoryrequestlist", null);

  const [getFiltersDataResp, fetchFilterData] = useFetch(
    "POST",
    "/inventoryfilterlist",
    null
  );

  useEffect(() => {
    if (getFiltersDataResp)
      setFetchedFilterData(getFiltersDataResp?.data?.payload?.filters);
  }, [getFiltersDataResp]);

  const getSearchVal = (e) => {
    setSearchParam(e.target.value);
  };

  const resetSearch = () => {
    fetchData(inventoryOfferListListAPI(), {
      pm_key: props.md5value,
      data: {
        dealer_grp_id: props.dealerGroupId,
        page: 1,
        sort: "",
        limit: 10,
        filters: {
          search: "",
          from_date: "",
          to_date: "",
          request_status: "",
          updated_status: "",
          sort_by: "",
        },
      },
    });
  };

  const callSearch = (event) => {
    setIsFilterSearch(true);
    const re = /^[0-9\b]+$/;
    if (re.test(event) || event === "") {
      fetchData(inventoryOfferListListAPI(), {
        pm_key: props.md5value,
        data: {
          dealer_grp_id: props.dealerGroupId,
          page: 1,
          sort: "",
          limit: 10,
          filters: {
            search: event,
            from_date: fromDate,
            to_date: toDate,
            request_status: "",
            updated_status: "",
            sort_by: "",
          },
        },
      });
    } else {
      setInventoryData(null);
    }
  };

  useEffect(() => {
    callOffersListApi("", "", "", "", "", 1, 10);
  }, []);

  useEffect(() => {
    if (data?.data) {
      setInventoryData(data?.data);
      let totalPages = 0;
      setTotalItems(totalPages);
      if (data.totalRecords > 0 && data.totalRecords <= 10) {
        totalPages = 1;
        setTotalItems(totalPages);
      } else {
        let perPagerecords = data.totalRecords / 10; //divide by records per page,configured in OffersLIstGrid
        totalPages = Math.ceil(perPagerecords);
      }
      setTotalRecords(totalPages);
      setTotalItems(data.totalRecords);
    } else if (!data?.status) {
      setInventoryData(null);
    }
  }, [data]);

  // useEffect(() => {
  //   window.addEventListener("scroll", handleScroll);
  // }, []);

  const tabChange = (newValue) => {
    setLevel2Headervalue(newValue);
    props.setLevel2HeaderValue(newValue)
  };

  // const handleScroll = (event) => {
  //   setIsScrolled(window.scrollY !== 0);
  // };

  useEffect(() => {
    stickyGridHeader();
  }, [status]);

  const getSelectedPage = (page, limit) => {
    setSelectedPage(page);
    setSelectedLimit(limit);
    setIsFilterSearch(false);
    callOffersListApi(
      props.dealerGroupId,
      reqStatus,
      updStatus,
      searchParam,
      sortBy,
      page,
      selectLimit
    );
  };

  const callOffersListApi = (
    dealerGroupId,
    reqStatus,
    updStatus,
    srch,
    sortOptn,
    page,
    limit
  ) => {
    fetchData(inventoryOfferListListAPI(), {
      pm_key: props.md5value,
      data: {
        dealer_grp_id: props.dealerGroupId,
        page: page,
        sort: "",
        limit: limit,
        filters: {
          search: srch,
          from_date: fromDate,
          to_date: toDate,
          request_status: reqStatus,
          updated_status: updStatus,
          sort_by: sortOptn,
        },
      },
    });

    fetchFilterData(inventoryFilterListListAPI(), {
      pm_key: props.md5value,
      data: {
        dealer_grp_id: props.dealerGroupId,
        page: page,
        sort: "",
        limit: limit,
        filters: {
          search: srch,
          from_date: "",
          to_date: "",
          request_status: reqStatus,
          updated_status: updStatus,
          sort_by: sortOptn,
        },
      },
    });
  };

  const callFiltersData = (req, update, sort, from_date, to_date) => {
    setSortBy(sort);
    setIsFilterSearch(true);
    fetchData(inventoryOfferListListAPI(), {
      pm_key: props.md5value,
      data: {
        dealer_grp_id: props.dealerGroupId,
        page: 1,
        sort: "",
        limit: 10,
        filters: {
          search: "",
          from_date: from_date,
          to_date: to_date,
          request_status: req,
          updated_status: update,
          sort_by: sort,
        },
      },
    });
  };

  const callFilter = (event, label) => {
    if (label === "Request Status") {
      setRequestStatus(event);
    } else if (label === "Update Status") {
      setUpdatedStatus(event);
    }
  };

  const selectedlimit = (limit, pageNo) => {
    setSelectedLimit(limit);
    callOffersListApi(
      props.dealerGroupId,
      reqStatus,
      updStatus,
      searchParam,
      sortBy,
      pageNo,
      selectLimit
    );
  };

  return (
    <div className="mainInventorydiv">
      <div id="stickyMainHeader" className="stickyMainHeader">
        <HeaderIR
          supplierName={props.supplierName}
          dealer={props.dealer}
          dealerid={props.dealerId}
          md5value={props.md5value}
          callSearch={callSearch}
          getSearchVal={getSearchVal}
          resetSearch={resetSearch}
        ></HeaderIR>
        <Level2HeaderIR
          value={level2Headervalue}
          onChange={tabChange}
        ></Level2HeaderIR>
      </div>
      <Filters
        callFilter={callFilter}
        callFiltersData={callFiltersData}
        inventoryData={inventoryData}
        filterData={fetchedData}
        fromDate ={fromDate}
        toDate = {toDate}
        setFromDate ={setFromDate}
        setToDate = {setToDate}
      ></Filters>
      <Grid
        dealerId={props.dealerId}
        md5value={props.md5value}
        inventoryData={inventoryData}
        pageNo={pageNo}
        totalItems={totalItems}
        totalRecords={totalRecords}
        getSelectedPage={getSelectedPage}
        isFilterSearch={isFilterSearch}
        selectedlimit={selectedlimit}
      ></Grid>
    </div>
  );
};
export default Dashboard;
