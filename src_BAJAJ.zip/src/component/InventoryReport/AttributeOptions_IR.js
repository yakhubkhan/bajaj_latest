import React from "react";

const AttributeOptions = (props) => {
  return (
    <div className="searchContent-IR">
      <div className="multicheckbox-list">
        {props.renderSearchOption.map((searchOption, index) => (
          <div className="search-option-container" key={index}>
            <label
              role="checkbox"
              aria-checked="false"
              className="multicheckbox-list-item-label"
              htmlFor={props.searchInputClass + index}
            >
              <input
                value={searchOption.label}
                onChange={props.setValues}
                className="multi-list-item-checkbox"
                type="checkbox"
                id={props.searchInputClass + index}
                checked={props.isChecked(searchOption.label)}
              />
              <span className="input-span-checkbox-IR">
                {searchOption.label}
              </span>
            </label>
          </div>
        ))}
      </div>
      <button
        className={
          props?.checkedValues?.length == 0 ? "initalSearch" : "serach-apply-IR"
        }
        // disabled={!props.checkedValues}
        onClick={props.handleApply}
      >
        Apply
      </button>
    </div>
  );
};

export default AttributeOptions;
