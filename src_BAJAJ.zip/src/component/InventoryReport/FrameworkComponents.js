import SaveAction from "./SaveAction";
import CustomTooltip from "./CustomTooltip";
import DateTime from "./inventorDateTime";
import NoReports from './NoReports'

export const frameworkComponents = {
  saveaction: SaveAction,
  DateTime: DateTime,
  customTooltip: CustomTooltip,
  noReports:NoReports
};
