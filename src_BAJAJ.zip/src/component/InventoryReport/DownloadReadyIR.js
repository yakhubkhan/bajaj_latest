import React, { useState, useRef, useEffect } from "react";
import "./DownloadIR.css";
// import orangeCtaDone from "../../images/orangeCtaDone.png";
// import orangeCtaLoader from "../../images/orangeCtaLoader.png";
import loaderProgressFile from "../../images/loaderProgressFile.png";
import orangeProgress from "../../images/orangeProgress.png";
import orangeTick from "../../images/orangeTick.svg";
import doNotDisturb from "../../images/doNotDisturb.svg";
import useFetch from "../../api/useFetch";
import moment from "moment";
import { getcsvdownloadsApiURL } from "../../utils/apiURLs";
import arrowDown from "../../images/down-arrow-3x.png";
import arrowUp from "../../images/arrow-up-3x.png";
import bell from "../../component/DownloadReady/Images/bell.png";
import { onDownloadCSV } from "../../gtm";

const DownloadReady = (props) => {
  // console.log(props);
  let container = useRef(null);

  const [showDropdown, setDropdown] = useState(false);
  const [isTimeOut, setIsTimeOut] = useState(false);

  const [showBell, setShowBell] = useState(false);
  const [localData, setLocalData] = useState(localStorage.getItem("flag"));
  const [{ data }, getcsvdownload] = useFetch("POST", "/getcsvdownloads", null);
  var listItems = data?.data?.data;

  useEffect(() => {
    window.addEventListener("mousedown", handleClickOutside);
    return () => {
      window.removeEventListener("mousedown", handleClickOutside);
    };
    //eslint-disable-next-line
  }, []);

  const handleClickOutside = (event) => {
    if (container.current && !container.current.contains(event.target)) {
      setDropdown(false);
    }
  };

  const getFormatedDate = (dateString) => {
    let timeString = moment(new Date(dateString))
      .fromNow()
      .replace("minutes", "min");
    timeString = timeString === "an hour ago" ? "1 hour ago" : timeString;
    return timeString;
  };

  const downloadFile = (fileName, urlData) => {
    var aLink = document.createElement("a");
    // var evt = document.createEvent("HTMLEvents");
    var evt = new MouseEvent("click");

    // evt.initEvent("click");
    aLink.download = fileName;
    aLink.href = urlData;
    aLink.dispatchEvent(evt);
    // aLink.click(evt);
  };

  const onClickDownload = (option) => {
    const { filename } = option;

    let csvContent = window.atob(filename);

    downloadFile("OffersCSV.csv", csvContent);
  };

  const isNotEmptyObject = () => {
    // debugger
    return listItems && listItems[0].created_at;
  };

  const dropdownItem = (item) => {
    const { created_at, filename, file_name } = item;
    const isdownloading = filename === "";
    // const isdownloading = false;
    // const name = `${file_name.substring(0, 40)}...`;

    // if (isAnyOptionDownloading() && isTimeOut) {
    //   return <div className="tryAgain">Download in progress, please check in 30 min.</div>;
    // }
    return (
      <div className="d-flex dropdownItem">
        <div className="d-flex alignCenter">
          {/* <i class="fa fa-check-circle icon_right" aria-hidden="true"></i> */}
          <img className="itemIcon" src={orangeTick} alt="cta" />
          <div className="fileName">
            {isdownloading ? "Download file" : file_name}
          </div>
        </div>

        <div className="d-flex">
          <div className="downloadBtn" onClick={() => onClickDownload(item)}>
            Download
          </div>
          <div className="time">{getFormatedDate(created_at)}</div>
        </div>
      </div>
    );
  };

  return (
    <div className="filterdropdowninventory" ref={container}>
      <span className="labelInventory">Download Ready</span>
      <img
        height="16px"
        alt="arrow"
        src={!showDropdown ? arrowDown : arrowUp}
        className="download_icon img_pre"
      />
      {showDropdown && (
        <div className="downloadReadydropdownPanel">
          <div
            className={
              "dropdownContainer" +
              (isNotEmptyObject() && !isTimeOut ? "" : " minLength")
            }
            // ref={container}
          >
            {isNotEmptyObject() ? (
              listItems?.map((item) => {
                return dropdownItem(item);
              })
            ) : (
              <div className="noRecordes">
                <img
                  className="doNotDistrubIcon"
                  src={doNotDisturb}
                  alt="doNotDisturb"
                />
                No Records Found
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default DownloadReady;
