import React from "react";
import ReactDOM from "react-dom";
import userLogo1 from "../../images/empty-folder.svg";
import "../../Pages/Level2Header.css";

const NoReports = () => {
  return (
    <div>
      <div className="NoReportsIcon">
        <img src={userLogo1} alt="user_logo"></img>
        <div>Oops! No reports available</div>
      </div>
    </div>
  );
};
export default NoReports;
