import React, { useState, useEffect } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";
import Pagination from "./Pagination";
import { frameworkComponents } from "./FrameworkComponents";
import GridColumns_IR, { cellbg } from "./GridColumns_IR";

const Grid = (props) => {
  let defaultColDef = {
    sortable: true,
    resizable: true,
    tooltipComponent: "customTooltip",
  };
  const [gridcols, SetGridCols] = useState(GridColumns_IR());
  const [gridApi, setGridApi] = useState();
  const [gridColumnApi, setGridColumnApi] = useState();

  const getRowHeight = (params) => {
    return 90;
  };

  const onGridReady = (params) => {
    const { api, columnApi } = params;
    setGridApi(api);
    setGridColumnApi(columnApi);
    // params.api.sizeColumnsToFit();
    params.api.setDomLayout("autoHeight");
    // params.columnApi.autoSizeAllColumns();
    if (document.querySelector("#myGrid")) {
      document.querySelector("#myGrid").style.height = "";
    }
  };

  const onSelectionChanged = () => {
    var selectedRows = gridApi.getSelectedRows();
  };

  const getRowStyle = (params) => {
    if (params.node.selected) {
      return { backgroundColor: "#EBF3FF !important" };
    } else {
      return { backgroundColor: "#fff !important" };
    }
  };

  return (
    <div className="contleft">
      <div className="sectndiv">
        <section>
          <div className="mainGridListContainerIR">
            <div
              id="myGrid"
              className={
                "ag-theme-alpine mainGrid gridIR" +
                (props.isGetOffersListLoading ? "hideList" : "")
              }
              style={{
                width: "100%",
              }}
            >
              <AgGridReact
                singleClickEdit={true}
                noRowsOverlayComponent={"noReports"}
                columnDefs={gridcols}
                rowData={props.inventoryData}
                defaultColDef={defaultColDef}
                onGridReady={onGridReady}
                suppressPaginationPanel={true}
                pagination={true}
                undoRedoCellEditing={true}
                onGridColumnsChanged={() =>
                  gridColumnApi && gridColumnApi.autoSizeAllColumns()
                }
                props={props}
                // state={{ actnMsg, selectedsku, actnresp, actnStatus }}
                paginationPageSize={props?.inventoryData?.length}
                onSelectionChanged={onSelectionChanged}
                suppressRowClickSelection={true}
                getRowHeight={getRowHeight}
                getRowStyle={getRowStyle}
                suppressDragLeaveHidesColumns={true}
                frameworkComponents={frameworkComponents}
                tooltipShowDelay={0}
                tooltipHideDelay={5000}
              ></AgGridReact>
              <Pagination
                totalRecords={props.totalRecords}
                totalItems={props.totalItems}
                isFilterSearch={props.isFilterSearch}
                getSelectedPage={props.getSelectedPage}
                paginationPageSize={10}
                pageNo={props.pageNo}
                gridApi={gridApi}
                selectedlimit={props.selectedlimit}
              ></Pagination>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Grid;
