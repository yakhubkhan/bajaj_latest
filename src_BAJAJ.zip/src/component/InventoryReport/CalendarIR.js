import React, { useState, useRef, useEffect } from "react";
import Calendar from "react-calendar";
import moment from "moment";
import arrowDown from "../../images/blueArrow.svg";

const CalendarIR = (props) => {
  const [isOpen, setIsOpen] = useState(false);
  const [fromDate, setFromDates] = useState();
  const [toDate, setToDates] = useState();
  const [status, setStatus] = useState(false);
  const dates = new Date();
  const daysAgo = new Date(dates.getTime());

  daysAgo.setDate(dates.getDate() - 7);
  const wrapperRef = useRef(null);

  const loadDropDown = (event) => {
    setIsOpen(!isOpen);
  };

  const handleClickOutside = (event) => {
    if (wrapperRef && !wrapperRef?.current?.contains(event.target)) {
      if (isOpen) {
        setIsOpen(false);
      }
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  });

  const callFromDateFilter = (val) => {
    setStatus(true);
    setFromDates(val);
    if(!toDate) {
      setToDates(new Date())
    }
    props.callCalendarFilter(moment(val).format("yyyy-MM-DD"), moment(toDate).format("yyyy-MM-DD"));
    setIsOpen(false);
  };

  const callToDateFilter = (val) => {
    setStatus(true);
    setToDates(val);
    if(!fromDate) {
      setFromDates(new Date())
    }
    props.callCalendarFilter(moment(fromDate).format("yyyy-MM-DD"), moment(val).format("yyyy-MM-DD"));
    setIsOpen(false);
  };

  const handleReset = () => {
    setStatus(false);
    setFromDates();
    setToDates();
    setIsOpen(false);
    props.callCalendarFilter("", "");
  };

  return (
    <div class="main-select-wrapper" ref={wrapperRef}>
      <div
        className={
          props?.inventoryData === null && props.status === false
            ? "filterdropdowninventorydisable filterdropdowninventory"
            : "filterdropdowninventory"
        }
        onClick={loadDropDown}
      >
        <div style={{ display: "flex" }}>
          {!status && <span className="labelInventory">Date Range</span>}
          {status && (
            <span
              className={status ? "div_row labelInventory" : "labelInventory"}
            >
              { moment(fromDate).format("DD-MMM-YYYY") + " - " + moment(toDate).format("DD-MMM-YYYY")}
            </span>
          )}
          {status && (
            <span className="icon-cross">
              <i
                class="fa fa-times"
                aria-hidden="true"
                onClick={handleReset}
              ></i>
            </span>
          )}
          <span>
            <img
              src={arrowDown}
              height="15px"
              className={isOpen ? " rotateIcon mar-left" : "mar-left"}
            />
          </span>
        </div>
      </div>
      {isOpen && (
        <div className="app">
          <p className="from-to-date">
            {moment(fromDate ? fromDate : daysAgo).format("DD MMM YYYY")}
            <span className="bold"> - </span>{" "}
            {moment(toDate).format("DD MMM YYYY")}
          </p>
          <div className="calendar-container">
            <h1 className="from-to-calendar">From</h1>

            <Calendar
              onChange={callFromDateFilter}
              value={(fromDate && toDate) ? [fromDate, toDate] : [new Date(), new Date()]}
              calendarType="US"
              formatMonthYear={(locale, date) =>
                moment(date).format("MMM YYYY")
              }
              maxDate={new Date()}
              minDate={daysAgo}
            />
          </div>
          <div className="calendar-container">
            <h1 className="from-to-calendar">To</h1>
            <Calendar
              onChange={callToDateFilter}
              calendarType="US"
              formatMonthYear={(locale, date) =>
                moment(date).format("MMM YYYY")
              }
              value={(fromDate && toDate) ? [fromDate, toDate] : [new Date(), new Date()]}
              maxDate={new Date()}
              minDate={daysAgo}
            />
          </div>
        </div>
      )}
    </div>
  );
};
export default CalendarIR;
