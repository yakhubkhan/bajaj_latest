/* eslint-disable no-use-before-define */
import React, { useEffect, useState } from "react";
import TextField from "@material-ui/core/TextField";
import Autocomplete from "@material-ui/lab/Autocomplete";
import { makeStyles } from "@material-ui/core/styles";
import PropTypes from "prop-types";
import * as Constants from "../../utils/Constant";
import arrowDown from "../../images/arrowDown.png";
import cancel from "../../images/cancel.png";
import "./SortOption_IR.css";
const useStyles = makeStyles({
  option: {
    fontSize: 11,
    "& > span": {
      marginRight: 4,
      fontSize: 10,
    },
  },
  container: {
    display: "flex",
    flexWrap: "wrap",
  },
  //style for font size
  resize: {
    fontSize: 11,
    padding: 3,
  },
});

const SortOption = (props) => {
  const sortOptions = [
    { label: "Date & Time - Asc", value: "datetime_asc" },
    { label: "Date & Time - Desc", value: "datetime_desc" },
  ];
  const [sortOptionValue, setSortOption] = useState(sortOptions);
  const [selectedSortBy, setSelectedSortBy] = useState("");

  const onClickOptions = (opt) => {
    if (opt) {
      setSelectedSortBy(opt.label);
      props.onClickOption(opt.value);
    } else {
      setSelectedSortBy("");
      props.onClickOption("");
    }
  };

  const handleReset = () => {
    setSelectedSortBy("");
    props.onClickOption("");
  };

  const multiCheckBox = (data, index) => {
    const hoverMsg =
      index == 0
        ? "Click to sort in ascending order."
        : "Click to sort in descending order.";
    return (
      <div
        data-hover={hoverMsg}
        className="sortByIROption"
        key={"multiCheckBox" + index}
      >
        <div className="form-check-custom">
          <span
            className="form-check-label-custom"
            htmlFor={"flexCheckCheckedMain" + data.title}
            onClick={() => onClickOptions(data)}
          >
            {data.label}
          </span>
        </div>
      </div>
    );
  };

  const classes = useStyles();

  return (
    <div
      className={
        props?.inventoryData == null
          ? "sortDrpdwnBtn sortdisable"
          : "dropdown sortDrpdwnBtn"
      }
    >
      <div className="sortbyToggle">
        <div
          className={selectedSortBy.length > 0 ? "columnPrefContainerIR" : ""}
        >
          <div className="clmPrefTitle1">
            {selectedSortBy.length > 0 ? selectedSortBy : "Sort by"}
          </div>
          {selectedSortBy.length > 0 && (
            // <img
            //   className="columnPrefcloseImg"
            //   src={cancel}
            //   onClick={handleReset}
            // />
            <span className="icon-crossSort">
              <i
                class="fa fa-times"
                aria-hidden="true"
                onClick={handleReset}
              ></i>
            </span>
          )}
        </div>
      </div>
      <div
        className="dropdown-toggle dropdown-toggle-split sortbyToggle removeHardDrpdwnIcon tgldrpdwn"
        data-toggle="dropdown"
        aria-haspopup="true"
        aria-expanded="true"
        title="Sort By"
      ></div>
      <div
        className="dropdown-menu dropdown-menu-sort drpdwnMenu"
        aria-labelledby="dropdownMenuButton"
      >
        <div className="clmPrefDrpDwnItm sort-dropdwn">
          {sortOptionValue &&
            sortOptionValue.map((mainItem, index) => {
              return multiCheckBox(mainItem, index);
            })}
        </div>
      </div>
      <img
        alt="arrowDown"
        src={arrowDown}
        height="16px"
        object-fit="contain"
        className="download_icon rotateIconArrow"
      />
    </div>
  );
};
SortOption.propTypes = {
  options: PropTypes.array,
  onClickOption: PropTypes.func,
};

export default SortOption;
