/* eslint-disable */
import React, { useState, useRef, useEffect } from "react";
import MultiCheckboxSearch from "./MultiCheckbox_IR";
import CalendarIR from "./CalendarIR";
import "./Calendar.css";
import DownloadReady from "./DownloadReadyIR";
import SortOptionJs from "./SortIR";

const Filters = (props) => {
  const [requestStatus, setRequestStatus] = useState([]);
  const [updateStatus, setUpdateStatus] = useState([]);
  const [requestStatusData, setRequestStatusData] = useState([]);
  const [updateStatusData, setUpdateStatusData] = useState([]);
  const [sortBy, setSortBy] = useState();
  // const [fromDate, setFromDate] = useState();
  // const [toDate, setToDate] = useState();
  const [requestState, setRequestState] = useState(false);
  const [updateState, setUpdateState] = useState(false);

  const RequestData = [
    {
      label: "Accepted",
      value: 1,
    },
    {
      label: "Rejected",
      value: 2,
    },
  ];

  useEffect(() => {
    if (props?.filterData) {
      const request = [];
      props?.filterData?.request_status?.map((item) => {
        RequestData.map((items) => {
          if (item === items.value) {
            request.push(items);
          }
        });
      });

      const update = props?.filterData?.updated_status?.map((item) => {
        return { label: item };
      });
      setRequestStatusData(request);
      setUpdateStatusData(update);
    }
  }, [props?.filterData]);

  const changeFilter = (data) => {
    if (
      data &&
      data.label &&
      data?.label === "Request Status" &&
      data?.value?.length > 0
    ) {
      setRequestState(true);
    } else if (
      data &&
      data.label &&
      data.label === "Request Status" &&
      data.value.length === 0
    )
      setRequestState(false);
    else if (
      data &&
      data.label &&
      data.label === "Update Status" &&
      data.value.length > 0
    )
      setUpdateState(true);
    else if (
      data &&
      data.label &&
      data.label === "Update Status" &&
      data.value.length === 0
    )
      setUpdateState(false);
  };

  const handleApply = (optionValues, label) => {
    var requestValue = requestStatus;
    var updateValue = updateStatus;
    if (label === "Request Status") {
      setRequestStatus(optionValues);
      requestValue = optionValues;
      props.callFilter(optionValues, label);
    } else if (label === "Update Status") {
      setUpdateStatus(optionValues);
      updateValue = optionValues;
      props.callFilter(optionValues, label);
    }
    props.callFiltersData(requestValue, updateValue, sortBy, props.fromDate, props.toDate);
  };

  const onClickOption = (data) => {
    setSortBy(data);
    props.callFiltersData(requestStatus, updateStatus, data, props.fromDate, props.toDate);
  };

  const callCalendarFilter = (fromDate, toDate) => {
    // if (label === "fromDate") {
      props.setFromDate(fromDate);
    // } else {
      props.setToDate(toDate);
    // }
    props.callFiltersData(requestStatus, updateStatus, sortBy, fromDate, toDate);
  };

  return (
    <div className="FilterTab">
      <div className="disp_flex flexColumn">
        <div className="Product-label-IR">Filters</div>
        <div className="filter-date">
          <div className="fltrminwdth">
            <CalendarIR
              inventoryData={props.inventoryData}
              status={requestState}
              callCalendarFilter={callCalendarFilter}
              setFromDate = {props.setFromDate}
              setToDate = {props.setToDate}
            />
          </div>

          <div className="fltrminwdth">
            <MultiCheckboxSearch
              label="Request Status"
              options={requestStatusData}
              onApply={handleApply}
              onReset={handleApply}
              changeFilter={changeFilter}
              status={requestState}
              inventoryData={props.inventoryData}
            />
          </div>

          <div className="fltrminwdth">
            <MultiCheckboxSearch
              label="Update Status"
              options={updateStatusData}
              onApply={handleApply}
              onReset={handleApply}
              changeFilter={changeFilter}
              status={updateState}
              inventoryData={props.inventoryData}
            />
          </div>
          <div className="fltrminwdth">
            <SortOptionJs
              onClickOption={onClickOption}
              inventoryData={props.inventoryData}
            />
          </div>
          {/* <div className="fltrminwdth">
            <DownloadReady />
          </div> */}
        </div>
      </div>
    </div>
  );
};

export default Filters;
