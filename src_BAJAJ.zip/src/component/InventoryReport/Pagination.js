/* eslint-disable */
import React, { useState } from "react";
import Pagination from "@material-ui/lab/Pagination";

const Pagination1 = (props) => {
  const [pageNo, SetPageNo] = useState(1);
  const [paginationPageSize, SetPaginationPageSize] = useState(10);

  const nextBt = (p) => {
    if (pageNo !== props.totalRecords && props.gridApi !== undefined) {
      document.getElementById("pageNumInputID").value = p;
      // SetPageNo(pageNo + 1);
      let limit = paginationPageSize;
      props.gridApi.paginationGoToNextPage();
      props.getSelectedPage(p, limit);
    }
  };

  const handleClick = (limit) => {
    let records = Math.ceil(props.totalItems / limit);
    let pageNumber = Math.ceil((paginationPageSize * pageNo) / limit);
    SetPaginationPageSize(limit);
    if (pageNumber >= records) {
      pageNumber = records;
    }
    SetPageNo(pageNumber);
    props.selectedlimit(limit, pageNo);
    document.getElementById("pageNumInputID").value = pageNumber;
  };

  const handleChange = (e, p) => {
    SetPageNo(p);
    nextBt(p);
    // props.selectedlimit(limit, p);
  };

  let pageNumber = props.isFilterSearch ? 1 : pageNo;
  let records = Math.ceil(props.totalItems / paginationPageSize);
  if (props.totalItems == 0) {
    records = 1;
  }

  return (
    <div className="example-header">
      <div class="dropdown itemsPerPageDropdown">
        <span className="paginationstyle itemsPerPageTxt">Items Per Page</span>

        <button
          class="btn btn-secondary dropdown-toggle itemsPerPageDropdownBtn"
          type="button"
          id="dropdownMenuButton"
          data-toggle="dropdown"
          aria-haspopup="true"
          aria-expanded="false"
        >
          {paginationPageSize}
        </button>
        <div
          class="dropdown-menu drpdwnMenu"
          aria-labelledby="dropdownMenuButton"
        >
          {[10, 20, 50, 100].map((item) => (
            <a class="dropdown-item" onClick={() => handleClick(item)} href="#">
              {item}
            </a>
          ))}
        </div>
      </div>
      <Pagination
        count={records}
        size="large"
        page={pageNo}
        variant="outlined"
        shape="rounded"
        onChange={handleChange}
      />
      <span className="pad-left-25">Go To Page</span>
      <input
        id="pageNumInputID"
        className="pageNumInput"
        disabled={props.totalRecords == 0 ? true : false}
        defaultValue={pageNumber}
        onKeyPress={(event) => {
          if (!/[0-9]/.test(event.key)) {
            if (event.key === "Enter") {
              if (event.target.value > records || event.target.value == 0) {
                event.target.classList.add("pageNumInputRed");
              } else {
                window.scrollTo(0, 0);
                event.target.classList.remove("pageNumInputRed");
                props.getSelectedPage(event.target.value, paginationPageSize);
              }
              if (event.target.value == "") {
                SetPageNo(parseInt(1));
                document.getElementById("pageNumInputID").value = 1;
              } else {
                SetPageNo(parseInt(event.target.value));
              }
            }
            event.preventDefault();
          }
        }}
      />
      {(pageNumber > records || pageNumber == 0) && (
        <div className="maxError">
          Incorrect Page number. Please enter page number between the range
        </div>
      )}
      <div className="marginBtm"></div>
    </div>
  );
};

export default Pagination1;
