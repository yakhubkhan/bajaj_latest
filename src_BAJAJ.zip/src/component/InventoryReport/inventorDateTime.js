/* eslint-disable */
import React from "react";

const DateTime = (props) => {
  return (
    <>
      <div style={{ display: "grid" }}>
        <span>{props.value.split(" ")[0]}</span>
        <span>{props.value.split(" ")[1]}</span>
      </div>
    </>
  );
};
export default DateTime;
