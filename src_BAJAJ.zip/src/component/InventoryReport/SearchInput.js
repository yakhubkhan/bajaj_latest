/* eslint-disable */
import React, { useState } from "react";
import crossCircle from "../../images/crossCircle.png";
import icon_search from "../../images/icon_search.png";
import "./SearchInputs.css";

const SearchInput = (props) => {
  const [searchValue, setsearchValue] = useState("");

  const callSearch = (e) => {
    const re = /^[0-9\b]+$/;
    if (e.target.value === "" || re.test(e.target.value)) {
      setsearchValue(e.target.value);
    }
  };

  return (
    <div
      className={`disp_flex alignitemsCenter ${
        window.isLogistic ? "srch-logistic" : "srch"
      }`}
    >
      <img className="srchbtn" src={icon_search} />
      <input
        id="searchinput"
        type="text"
        className="srchinput"
        pattern="[0-9]"
        value={searchValue}
        onChange={(e) => callSearch(e)}
        placeholder={
          props.placeholder
            ? props.placeholder
            : "Search by SKU ID, Brand or Product name"
        }
        name="search"
        onKeyPress={(event) => {
          if (event.key === "Enter") {
            props.getSearchVal(event);
            props.callSearch(event.target.value);
          }
        }}
      />
      <span
        className="srchCrossBtn"
        onClick={() => {
          document.getElementById("searchinput").value = "";
          setsearchValue("");
          props.resetSearch();
        }}
      >
        {searchValue ? <img height="15px" src={crossCircle} alt="" /> : ""}
      </span>
      {/* <button className="srchbtn" onClick={props.callSearch} type="submit">
        <i className="fa fa-search srchicn"></i>
      </button> */}
    </div>
  );
};

export default SearchInput;
