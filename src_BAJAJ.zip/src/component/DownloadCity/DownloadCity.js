import React from "react";
import { ExportToCsv } from "export-to-csv";
import uploadedOfferHeader from "../../utils/CommonServices";
import { axiospricemgmt } from "../../api/axios";
import * as Constants from "../../utils/Constant";
import { onDownloadCSV, uploadOffer } from "../../gtm";
const DownloadCity = (props) => {
  const getDealerIds = () => {
    var dealerIds = [];
    if (props.dlerid.length > 0) {
      dealerIds = props.dlerid;
    } else if (props.dealerOpts.length > 0) {
      props.dealerOpts.map((val, ind) => {
        dealerIds.push(val.label);
        return true;
      });
    }
    return dealerIds;
  };

  const callCityApi = () => {
    var dealerIds = getDealerIds().toString();
    var data;
    document.getElementsByTagName("body")[0].classList.add("loading");
    if (props.dlerid.length === 0) {
      data = { parentDealerId: props.dealerid };
    } else {
      data = { dealerId: dealerIds };
    }
    axiospricemgmt({
      method: "post",
      url: "/getcitydownload",
      data: {
        pm_key: props.md5value,
        data: data,
      },
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then(function (resp) {
        var arrangeData = [];
        var fileName = "city";
        const options = {
          filename: fileName,
          fieldSeparator: ",",
          quoteStrings: '"',
          decimalSeparator: ".",
          showLabels: true,
          showTitle: false,
          useTextFile: false,
          useBom: false,
          headers: Constants.downloadCityCsvHeader,
        };
        const csvExporter = new ExportToCsv(options);
        arrangeData = resp.data.data.map((item, index) => {
          return [
            item.Parent_Dealer_Id,
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            item.CITYID,
            item.CITY,
            item.STATENAME,
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
          ];
        });
        var ofs = uploadedOfferHeader(props.offer_header_sample, true);
        var ofd = uploadedOfferHeader(props.offer_header_description, true);
        arrangeData.unshift(ofs);
        arrangeData.unshift(ofd);
        csvExporter.generateCsv(arrangeData);
        document.getElementsByTagName("body")[0].classList.remove("loading");
      })
      .catch(function (err) {
        document.getElementsByTagName("body")[0].classList.remove("loading");
      });
      const { dealerName, dealerid, uploadType  } = props;
        let obj = {
            ListingName: props.selectedTab,
            dealerName: dealerName,
            dealerId: dealerid,
            eventName: "City Download"
        }
        uploadOffer(obj)
        onDownloadCSV({
            ListingName: props.selectedTab,
            dealerId: dealerid,
            dealerName: dealerName,
            upload: uploadType
        })
  };

  const downloadCityCsvData = (downloadType, downloadMethod) => {
    callCityApi();
  };
  return (
    <span className="btn-download-offer">
      <button
        className="cityDownloadBtn upldbtn download-offers "
        onClick={() => downloadCityCsvData("city")}
      >
        <i className="fa fa-download" aria-hidden="true"></i>City Download
      </button>
    </span>
  );
};

export default DownloadCity;
