/* eslint-disable */
import React, { useState, useRef, useEffect } from "react";
import { onDownloadCSV, uploadOffer } from "../../gtm";
import DownloadReady from "../DownloadReady/DownloadReady";
import useFetch from "../../api/useFetch";
import Modal from "react-bootstrap/Modal";
import "./DownloadOffers.css";
import downloadError from "../../images/downloadError.svg";
import xcircle from "../../images/x-circle.svg";
import { requestDownloadApiURL } from "../../utils/apiURLs";
import UploadOffers from "./UploadOffers";
import arrowDown from "../../images/blueArrow.svg";
import arrowDownGray from "../../images/greyArrow.svg";
import moment from "moment";

const DownloadOffers = (props) => {
  let container = useRef(null);
  const [showDropdown, setDropdown] = useState(false);
  const [dropdown, isDropdown] = useState(false);
  const [status, setStatus] = useState(false);
  const [displayPopup, setDisplayPopup] = useState(false);
  const [requestDownloadResponse, setRequestDownloadResponse] = useState([]);
  const [isOpenError, setIsOpenError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const [isGetCSVDownloadApiLoading, setGetCSVDownloadApiLoading] = useState(false);

  const [getFiltersDataResp, fetchRequestdownloadoffers] = useFetch(
    "POST",
    "/requestdownloadoffers",
    null
  );

  useEffect(() => {
    window.addEventListener("mousedown", handleClickOutside);
    return () => {
      window.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    setGetCSVDownloadApiLoading(false)
  }, [getFiltersDataResp.error]);

  useEffect(() => {
    if (
      props.selectedTab === "new" &&
      (props.brand.length || props.category.length)
    ) {
      setStatus(false);
    } else if (
      props.selectedTab === "new" &&
      (props.brand.length === 0 || props.category.length === 0)
    ) {
      setStatus(true);
    } else {
      setStatus(false);
    }
  }, [props]);

  /*Displays popup after Download request started */
  useEffect(() => {
    if (
      getFiltersDataResp.data?.errorBean &&
      getFiltersDataResp.data?.errorBean[0]
    ) {
      if (getFiltersDataResp.data?.errorBean[0].errorCode == 1) {
        setErrorMessage(getFiltersDataResp.data?.errorBean[0].errorMessage);
        setIsOpenError(true);
      }
    }
  }, [getFiltersDataResp.data]);
  const enablePopup = () => {
    setDisplayPopup(true);
    setInterval(() => {
      setDisplayPopup(false);
    }, 3000);
  };

  /*While click on outside of dropdown this will close dropdown */
  const handleClickOutside = (event) => {
    if (container.current && !container.current.contains(event.target)) {
      isDropdown(true);
      setDropdown(false);
    } else {
      isDropdown(false);
    }
  };

  /*It open/close dropdown and send gtm */
  const displayDownloadOptions = (displayDropdownBool) => {
    if (isAnyOptionloading()) {
      return;
    }
    if (!dropdown) setDropdown(displayDropdownBool);
    const { dealerName, dealerid } = props;
    let obj = {
      ListingName: props.selectedTab,
      dealerName: dealerName,
      dealerId: dealerid,
      eventName: "Download Offers",
    };
    uploadOffer(obj);
  };

  /*if sku's are not selected in list then it hits requestDownload api based on selected cta with respective payload
  if sku's selected in list it will direclty download csv without api call
  sends onDownloadCSV gtm  */
  const downloadData = (downloadMethod, subSection) => {
    setDropdown(false);
    if (props.selectedRow.length > 0) {
      props.downloadHanlder(props.selectedRow, downloadMethod, subSection.key);
    } else {
      const offersdashboardResp = props.offersdashboardResp;
      let count = 0;

      switch (downloadMethod) {
        case "active":
          if (subSection == "expiredSKU") {
            count = offersdashboardResp.payload.active_expired_sku;
            break;
          }
          count = !props.isFilter
            ? offersdashboardResp.payload.active
            : props.getFiltersDataResp.searchActiveRecordsCount;
          break;
        case "inactive":
          if (subSection == "expiredSKU") {
            count = offersdashboardResp.payload.inactive_expired_sku;
            break;
          }
          count = !props.isFilter
            ? offersdashboardResp.payload.inactive
            : props.getFiltersDataResp.searchInActiveRecordsCount;
          break;
        case "active-inactive":
          count = !props.isFilter
            ? offersdashboardResp.payload.active +
              offersdashboardResp.payload.inactive
            : props.getFiltersDataResp.searchActiveRecordsCount +
              props.getFiltersDataResp.searchInActiveRecordsCount;
          break;
        case "lowstock":
          count = !props.isFilter
            ? offersdashboardResp.payload.lowstock
            : props.getFiltersDataResp.lowStockSearchRecordsCount;
          break;
        case "outofstock":
          count = !props.isFilter
            ? offersdashboardResp.payload.outofstock
            : props.getFiltersDataResp.outofStockSearchRecordsCount;
          break;
        default:
          break;
      }
      if (count >= 300000) {
        setErrorMessage(
          "Offers cannot be downloaded as the file exceeds 3,00,000 rows"
        );
        setIsOpenError(true);
        return;
      } else {
        setIsOpenError(false);
      }

      const payload = {
        pm_key: props.md5value,
        data: [
          {
            dealerId: props.dealerid,
            request_data: [
              {
                parentDealerId: props.parentDealerId,
                sort: props.sortopt || "",
                page: props.selectedPage,
                section:
                  subSection.key == "new_listing"
                    ? subSection.key
                    : downloadMethod,
                subSection: subSection.key,
                search: props.searchParam,
                category: props.cat,
                cic: props.cic,
                childDealerId: props.dlerid,
                brand: props.brandFilter,
                city: props.cityFilter,
                state: props.stateFilter,
              },
            ],
            priority: count > 60000 ? 2 : 1,
          },
        ],
      };
      enablePopup();
      localStorage.setItem("flag", "false");
      fetchRequestdownloadoffers(requestDownloadApiURL(), payload);
      setGetCSVDownloadApiLoading(true)
    }
    onDownloadCSV({
      ListingName: props.selectedTab,
      dealerId: props.dealerid,
      dealerName: props.dealerName,
      section: subSection.name,
      eventName: "Request Download",
      dealerType: window.dealer_type,
      pageType: "Price Management",
    });
  };

  const isOptionloading = (downloadMethod) => {
    const index = requestDownloadResponse.findIndex(
      (item) => item.section == downloadMethod && item.filename == ""
    );
    return index >= 0;
  };

  /*Checks and return bool value if any request is on progress and consider the request created time too. */
  const isAnyOptionloading = () => {

    if(getFiltersDataResp.isLoading || isGetCSVDownloadApiLoading) {
      return true
    }

    const index = requestDownloadResponse.findIndex((item) => {
      const created_at = moment(new Date(item.created_at));
      const current = moment(new Date());
      const minDiff = current.diff(created_at, "minutes");
      const waitingTime = item.section == "new_listing" ? 120 : 5;
      return item.filename == "" && minDiff < waitingTime;
    });
    return index >= 0;
  };

  /*Checks and return bool value if all request is on progress */
  const isAllOptionsLoading = (downloadMethod) => {
    //Need to implement logic to check from server
    return false;
  };

  /*Close the error popup if 3L error popup is open  */
  const closeError = () => {
    setIsOpenError(false);
  };

  let selectedTab = props.selectedTab;
  const isActiveInactiveTab =
    selectedTab == "active" || selectedTab == "inactive";

  /*Created and returns each item in dropdown to render  */
  const menuItem = (title, section, options) => {
    return (
      <div className="requestOptionContainer">
        {title && <div className="requestOptionTitle">{title}</div>}
        <div className="disp_flex">
          {options.map((item) => {
            return (
              <div
                key={item.key}
                className={
                  "requestOption" +
                  (item.isDisable ? " disabledDownloadOption" : "")
                  // +
                  // (isOptionloading(item.name) ? "disableBtn" : "")
                }
                onClick={() => downloadData(section, item)}
              >
                {item.name}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="btn-download-offer disp_flex">
      {props.selectedTab == "new" &&
        !status &&
        props.filterApplied == false && (
          <span className="error_text">
            <span className="noproduct-download-error">
              Please choose any one of the filters available
            </span>
          </span>
        )}
      {
        <div>
          <button
            className={`btnwdth download-offers ${
              isAnyOptionloading() ? "disableRequestDownloadBtn" : ""
            }`}
            onClick={() => displayDownloadOptions(!showDropdown ? true : false)}
          >
            <div className="requestDownloadText">Request Download</div>
            {!isAllOptionsLoading() ? (
              <img
                height="16px"
                src={isAnyOptionloading() ? arrowDownGray : arrowDown}
                className={
                  "download_icon img_pre" + (showDropdown ? " rotateIcon" : "")
                }
              />
            ) : (
              ""
            )}
          </button>
        </div>
      }
      {showDropdown == true && !window.isLogistic && (
        <div className="download_dropdown" ref={container}>
          {isActiveInactiveTab &&
            selectedTab !== "new" &&
            menuItem("Active Listings", "active", [
              { name: "All", key: "all" },
              { name: "Price", key: "price" },
              { name: "Status & Inventory", key: "status_inventory" },
              { name: "Installation Charges", key: "installation_charges" },
              ,
            ])}
          {isActiveInactiveTab &&
            selectedTab !== "new" &&
            menuItem("Inactive Listings", "inactive", [
              { name: "All", key: "all" },
              { name: "Status & Inventory", key: "status_inventory" },
              ,
            ])}
          {selectedTab !== "new" &&
            menuItem("Low Stock", "lowstock", [
              { name: "All", key: "all" },
              { name: "Status & Inventory", key: "status_inventory" },
            ])}
          {selectedTab !== "new" &&
            menuItem("Out Of Stock", "outofstock", [
              { name: "All", key: "all" },
              { name: "Status & Inventory", key: "status_inventory" },
            ])}
          {selectedTab !== "new" &&
            menuItem("Price Alert", "pricealert", [
              { name: "All", key: "all" },
              { name: "Price", key: "price" },
            ])}
            {selectedTab !== "new" &&
              menuItem("Hot Selling", "hotselling", [
                { name: "New", key: "new" },
                { name: "Active", key: "active" },
                { name: "Inactive", key: "inactive" },
                { name: "Price Alert", key: "pricealert" }
              ])}
          {selectedTab !== "new" &&
            selectedTab !== "pricealert" &&
            !props.isParentDealer &&
            menuItem("", props.selectedTab, [
              //{ name: "New Listing", key: "new_listing" },
              { name: "Expired SKU", key: "expiredSKU" },
            ])}
          {selectedTab !== "new" &&
            selectedTab !== "pricealert" &&
            props.isParentDealer &&
            menuItem("", props.selectedTab, [
              //{ name: "New Listing", key: "new_listing" },
              { name: "Expired SKU", key: "expiredSKU" },
              { name: "City Download", key: "cityDownload" },
              //Please uncomment below code to add "Active & Inactive" code.
              // {
              //   name: "Active & Inactive",
              //   key: "active-inactive",
              //   isDisable: props.selectedRow.length > 0,
              // },
            ])}
            {selectedTab !== "new" &&
              selectedTab !== "pricealert" &&
              menuItem("", props.selectedTab, [
                { name: "Deactivated", key: "sku-deactivated" },
                { name: "Auto Scaled", key: "sku-autoscaled" },
              ])}
          {selectedTab !== "new" &&
            selectedTab == "pricealert" &&
            props.isParentDealer &&
            menuItem("", props.selectedTab, [
              //{ name: "New Listing", key: "new_listing" },
              { name: "City Download", key: "cityDownload" },
            ])}
          {selectedTab === "new" &&
            menuItem("New Listings", "new_listing", [
              { name: "All", key: "all" },
              {
                name: "New Catalogue",
                key: "new-product",
                isDisable: props.dashBoardResp?.payload.new_catalog == 0,
              },
            ])}
        </div>
      )}

      {showDropdown == true && window.isLogistic && (
        <div className="download_dropdown" ref={container}>
          {menuItem("", "logistic-management", [
            { name: "Active Listing", key: "all" },
          ])}
          {menuItem("", "logistic-management", [
            { name: "City Download", key: "cityDownload" },
          ])}
        </div>
      )}
      <Modal className="error-dialog" centered show={isOpenError}>
        <Modal.Body dialogClassName="error-popups">
          <div className="error-close">
            <div className="offer-download-close" onClick={() => closeError()}>
              <img height="32px" src={xcircle} />
            </div>
            <div className="gfg_text">
              <div className="tabImageContainer-error">
                <img height="85px" src={downloadError} />
              </div>

              <div className="offer-download-required">
                <span>{errorMessage}</span>
              </div>
            </div>
          </div>
        </Modal.Body>
      </Modal>
      {displayPopup && (
        <div className="downloadReadyPopup">Download Started...</div>
      )}

      <DownloadReady
        pm_key={props.md5value}
        selectedTab={selectedTab}
        dealerId={props.dealerid}
        dealerid={props.dealerid}
        dealerName={props.dealerName}
        getFiltersDataResp={getFiltersDataResp.data}
        setRequestDownloadResponse={(responseArray) =>{
          setRequestDownloadResponse(responseArray)
          setGetCSVDownloadApiLoading(false)
        }
        }
      />
      <UploadOffers
        {...props}
        title="Dealer Wise Upload"
        uploadType=""
        typeUpload="upload offers"
      />
      {props.isParentDealer && !props.isIndividualDealer && (
        <UploadOffers
          {...props}
          isParentUpload={true}
          title="City Wise Upload"
          uploadType="parent_price"
          typeUpload="parent price upload"
        />
      )}
    </div>
  );
};
export default DownloadOffers;
