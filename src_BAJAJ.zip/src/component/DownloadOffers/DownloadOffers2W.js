/* eslint-disable */
import React, { useState, useRef, useEffect } from "react";
import { onDownloadCSV, uploadOffer } from "../../gtm";
import DownloadReady from "../DownloadReady/DownloadReady";
import useFetch from "../../api/useFetch";
import FileUpload from "../FileUpload/FileUpload";
import arrowDown from "../../images/down-arrow-3x.png";
import arrowUp from "../../images/arrow-up-3x.png";
import arrowDownGray from "../../images/arrowDownGray.png";
import UploadOffers from "./UploadOffers";
import Modal from "react-bootstrap/Modal";
import moment from "moment";
import xcircle from "../../images/x-circle.svg";
import downloadError from "../../images/downloadError.svg";
const DownloadOffers2W = (props) => {
  let container = useRef(null);
  const [upload_type, setUploadType] = useState("");
  const [typeUpload, setTypeUpload] = useState("");
  const [modalOpen, isOpen] = useState(false);
  const [showDropdown, setDropdown] = useState(false);
  const [status, setStatus] = useState(false);
  const [displayPopup, setDisplayPopup] = useState(false);
  const [requestDownloadResponse, setRequestDownloadResponse] = useState([]);
  const [isOpenError, setIsOpenError] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const [getFiltersDataResp, fetchRequestdownloadoffers, filtersDataExtraObj] =
    useFetch("POST", "/requestdownloadoffers2w", null);

  useEffect(() => {
    window.addEventListener("mousedown", handleClickOutside);
    return () => {
      window.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (
      props.selectedTab === "new" &&
      (props.brand.length || props.category.length)
    ) {
      setStatus(false);
    } else if (
      props.selectedTab === "new" &&
      (props.brand.length === 0 || props.category.length === 0)
    ) {
      setStatus(true);
    } else {
      setStatus(false);
    }
  }, [props]);

  /*Displays popup after Download request started */
  useEffect(() => {
    if (
      getFiltersDataResp.data?.errorBean &&
      getFiltersDataResp.data?.errorBean[0]
    ) {
      if (getFiltersDataResp.data?.errorBean[0].errorCode == 1) {
        setErrorMessage(getFiltersDataResp.data?.errorBean[0].errorMessage);
        setIsOpenError(true);
      }
    }
  }, [getFiltersDataResp.data]);

  const handleClickOutside = (event) => {
    if (container.current && !container.current.contains(event.target)) {
      setDropdown(false);
    }
  };
  const enablePopup = () => {
    setDisplayPopup(true);
    setInterval(() => {
      setDisplayPopup(false);
    }, 3000);
  };

  const displayDownloadOptions = () => {
    if (isAnyOptionloading()) {
      return;
    }
    setDropdown(!showDropdown);
    const { dealerName, dealerid } = props;
    let obj = {
      ListingName: props.selectedTab,
      dealerName: dealerName,
      dealerId: dealerid,
      eventName: "Download Offers",
    };
    uploadOffer(obj);
  };

  const downloadData = (downloadMethod, subSection) => {
    debugger
    setDropdown(false);
    if (props.selectedRow.length > 0) {
      props.downloadHanlder(props.selectedRow, downloadMethod, subSection);
    } else {
      const offersdashboardResp = props.offersdashboardResp;
      let count = 0;

      switch (subSection) {
        case "active":
          count = !props.isFilter
            ? offersdashboardResp.payload.active
            : props.getFiltersDataResp.searchActiveRecordsCount;
          break;
        case "inactive":
          count = !props.isFilter
            ? offersdashboardResp.payload.inactive
            : props.getFiltersDataResp.searchInActiveRecordsCount;
          break;
        // case "active-inactive":
        //   count = !props.isFilter
        //     ? offersdashboardResp.payload.active +
        //       offersdashboardResp.payload.inactive
        //     : props.getFiltersDataResp.searchActiveRecordsCount +
        //       props.getFiltersDataResp.searchInActiveRecordsCount;
        //   break;
        case "lowstock":
          count = !props.isFilter
            ? offersdashboardResp.payload.lowstock
            : props.getFiltersDataResp.lowStockSearchRecordsCount;
          break;
        case "outofstock":
          count = !props.isFilter
            ? offersdashboardResp.payload.outofstock
            : props.getFiltersDataResp.outofStockSearchRecordsCount;
          break;
        default:
          break;
      }
      if (count >= 100000) {
        setErrorMessage("Offers cannot be downloaded as the file exceeds 1,00,000 rows")
        setIsOpenError(true);
        return;
      } else {
        setIsOpenError(false);
      }

      const payload = {
        pm_key: props.md5value,
        data: [
          {
            dealerId: props.dealerid,
            request_data: [
              {
                parentDealerId: props.parentDealerId,
                sort: props.sortopt || "",
                page: props.selectedPage,
                // section:
                //   subSection == "new_listing" ? subSection : downloadMethod,
                section: subSection,
                search: props.searchParam,
                category: props.cat,
                cic: props.cic,
                childDealerId: props.dlerid,
                brand: props.brandFilter,
                city: props.cityFilter,
                state: props.stateFilter,
              },
            ],
            priority: count > 60000 ? 2 : 1,
          },
        ],
      };
      enablePopup();
      localStorage.setItem("flag", "false");
      fetchRequestdownloadoffers(null, payload);
    }
    onDownloadCSV({
      ListingName: props.selectedTab,
      dealerId: props.dealerid,
      dealerName: props.dealerName,
      eventName: "Download Offers",
    });
  };

  const isOptionloading = (downloadMethod) => {
    const index = requestDownloadResponse.findIndex(
      (item) => item.section == downloadMethod && item.filename == ""
    );
    return index >= 0;
  };

  const isAnyOptionloading = () => {
    const index = requestDownloadResponse.findIndex((item) => {
      const created_at = moment(new Date(item.created_at));
      // const created_at = moment(new Date("2022-07-26 21:00:11"))
      const current = moment(new Date());
      const minDiff = current.diff(created_at, "minutes");
      const waitingTime = item.section == "new_listing" ? 120 : 5;
      // return item.filename == "" && minDiff < waitingTime;
      return item.filename == "";
    });
    return index >= 0;
  };

  const isAllOptionsLoading = (downloadMethod) => {
    //Need to implement logic to check from server
    return false;
  };

  const openUpload = (name) => {
    isOpen(!modalOpen);
    setTypeUpload("upload offers");
  };

  const closeModal = () => {
    isOpen(false);
  };
  const closeError = () => {
    setIsOpenError(false);
  };

  let selectedTab = props.selectedTab;
  const isActiveInactiveTab =
    selectedTab == "active" || selectedTab == "inactive";

  const menuItem = (title, section, options) => {
    return (
      <div className="requestOptionContainer">
        {title && <div className="requestOptionTitle">{title}</div>}
        <div className="disp_flex">
          {options.map((item) => {
            return (
              <div
                key={item.key}
                className={
                  "requestOption" +
                  (item.isDisable ? " disabledDownloadOption2w" : "")
                  // +
                  // (isOptionloading(item.name) ? "disableBtn" : "")
                }
                onClick={() => downloadData(section, item.key)}
              >
                {item.name}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="btn-download-offer disp_flex">
      {props.selectedTab == "new" &&
        !status &&
        props.filterApplied == false && (
          <span className="error_text">
            <span className="noproduct-download-error">
              Please choose any one of the filters available
            </span>
          </span>
        )}
      {
        <div>
          <button
            className={`btnwdth download-offers ${
              isAnyOptionloading() ? "disableRequestDownloadBtn" : ""
            }`}
            onClick={() => displayDownloadOptions()}
          >
            <div className="requestDownloadText">Request Download</div>
            {!isAllOptionsLoading() ? (
              <img
                height="16px"
                src={isAnyOptionloading() ? arrowDownGray : arrowDown}
                className={
                  "download_icon img_pre" + (showDropdown ? " rotateIcon" : "")
                }
              />
            ) : (
              ""
            )}
          </button>
        </div>
      }
      {/* {selectedTab == "new" ? (
        <button
          className={`download-offers
          ${status ? "btnwdth_new" : "btnwdth"}`}
          onClick={() => downloadData("normal_download")}
          // title={
          //   !status
          //     ? ""
          //     : "Please select SKUs using Category or Brand filter first"
          // }
          disabled={
            props.filterApplied == false || props.startRecords == 0
              ? "disabled"
              : ""
          }
        >
          Request Download
        </button>
      ) : (
        <button
          className={`btnwdth download-offers ${
            props.startRecords == 0 ? "disabled" : ""
          } ${isAllOptionsLoading() ? "disableRequestDownloadBtn" : ""}`}
          onClick={displayDownloadOptions}
        >
          <div>Request Download</div>
          {!isAllOptionsLoading() ? (
            <img
              height="16px"
              src={!showDropdown ? arrowDown : arrowUp}
              className="download_icon img_pre"
            />
          ) : (
            ""
          )}
        </button>
      )} */}
      {showDropdown === true && props.startRecords != 0 && (
        <div className="download_dropdown" ref={container}>
          {selectedTab === "new"
            ? menuItem("New Listings", "new_listing", [
                { name: "All", key: "newlisting-all" },
                {
                  name: "New Catalogue",
                  key: "new-product",
                  isDisable:
                    props.dashBoardResp.payload?.new_catalog == 0 ||
                    props.selectedRow != "",
                },
              ])
            : menuItem("", "active", [
                {
                  name: "Active",
                  key: "active",
                  isDisable:
                    props.selectedRow != "" && props.selectedTab != "active",
                },
                {
                  name: "Inactive",
                  key: "inactive",
                  isDisable:
                    props.selectedRow != "" && props.selectedTab != "inactive",
                },
                {
                  name: "Low Stock",
                  key: "lowstock",
                  isDisable: props.selectedRow != "",
                },
                {
                  name: "Out of Stock",
                  key: "outofstock",
                  isDisable: props.selectedRow != "",
                },
                ,
              ])}
        </div>
      )}
      <Modal className="error-dialog" centered show={isOpenError}>
        <Modal.Body dialogClassName="error-popups">
          <div className="error-close">
            <div className="offer-download-close" onClick={() => closeError()}>
              <img height="32px" src={xcircle} />
            </div>
            <div className="gfg_text">
              <div className="tabImageContainer-error">
                <img height="85px" src={downloadError} />
              </div>

              <div className="offer-download-required">
                <span>{errorMessage}</span>
              </div>
            </div>
          </div>
        </Modal.Body>
      </Modal>
      {props.downloadThreholdError && (
        <span className="gfg_text">
          <span
            className="offer-download-close"
            onClick={() => props.closeDToolTip()}
          >
            X
          </span>
          <span className="offer-download-error">
            Offers cannot be downloaded due to the following error
          </span>
          <span className="offer-download-title">
            The file has crossed the limit of 60000 products
          </span>
          <span className="offer-download-required">
            Please apply required filters in order to download
          </span>
        </span>
      )}
      {displayPopup && (
        <div className="downloadReadyPopup">Download Started...</div>
      )}
      <DownloadReady
        pm_key={props.md5value}
        dealerId={props.dealerid}
        getFiltersDataResp={getFiltersDataResp.data}
        setRequestDownloadResponse={(responseArray) =>
          setRequestDownloadResponse(responseArray)
        }
      />
      <FileUpload
        selectedTab={selectedTab}
        closeModal={closeModal}
        open={modalOpen}
        uploadType={upload_type}
        typeUpload={typeUpload}
        parentDealerId={props.parentDealerId}
        dealerid={props.dealerid}
        dealerName={props.dealerName}
        fltersdata={props.fltersdata}
        offer_header_description={props.offer_header_description}
        offer_header_resp={props.offer_header_resp}
        offer_header_sample={props.offer_header_sample}
        sendResponse={props.sendResponse}
      ></FileUpload>
      {/* <div className="uplod">
        <button
          className="upldbtn"
          name="upload_offers"
          onClick={() => openUpload("")}
        >
          <span className="offrspc" name="upload_offers">
            Upload offers
            <img
              height="16px"
              src={arrowDown}
              alt="arrowDown"
              className="download_icon img_pre"
            />
          </span>
        </button>
      </div> */}
      <UploadOffers
        {...props}
        // options={uploadOptions()}
        // name=""
        title="Upload Offers"
        uploadType=""
        typeUpload="upload offers"
      />
    </div>
  );
};
export default DownloadOffers2W;
