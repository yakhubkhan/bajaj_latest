/* eslint-disable */
import React, { useState, useEffect } from "react";
import FileUpload from "../FileUpload/FileUpload";
import "./uploadOffers.css";
import arrowDown from "../../images/blueArrow.svg";
import {
  uploadOptions,
  parentUploadOptions,
  logisticUploadOption,
  logisticParentUploadOption,
  uploadOption2w,
  uploadOptionForNew,
  parentUploadOptionforNew,
} from "../../utils/Constant";

import { uploadOffer } from "../../gtm";

const UploadOffers = (props) => {
  const [modalOpen, isOpen] = useState(false);
  const [progressValue, setProgressValue] = useState(0);
  const [currentUploadingTypeTitle, setCurrentUploadingTypeTitle] =
    useState(null);
  const [currentUploadingOption, setCurrentUploadingOption] = useState(null);
  const [selectedOption, setSelectedOption] = useState(null);

  useEffect(() => {
    if (
      props.selectedTab === "new" &&
      (props.brand.length || props.category.length)
    ) {
    } else if (
      props.selectedTab === "new" &&
      (props.brand.length === 0 || props.category.length === 0)
    ) {
    } else {
    }
  }, [props]);

  /* To check is any csv uploading and return bool */
  const isOptionUploading = (option) => {
    return (
      currentUploadingTypeTitle == props.title &&
      option.name == currentUploadingOption?.name &&
      progressValue > 0 &&
      progressValue < 100
    );
  };
  /* To check is any csv uploading and return bool */
  const isAnyOptionUploading = () => {
    return (
      currentUploadingTypeTitle == props.title &&
      progressValue > 0 &&
      progressValue < 100
    );
  };

  /* To open upload view popup */
  const openUpload = (option) => {
    isOpen(!modalOpen);
    setSelectedOption(option);
  };

  /*get call on Click on Upload cta */
  const onClickUpload = () => {
    setCurrentUploadingTypeTitle(props.title);
    setCurrentUploadingOption(selectedOption);
  };

  /* To close upload view popup */
  const closeModal = () => {
    isOpen(false);
  };

  /* To check and open upload view   */
  const onClickOption = (option) => {
    if (!isAnyOptionUploading()) {
      openUpload(option);
      callDataLayer(option.name)

    }
  };

  /* To hit gtm */
  const callDataLayer = (label) => {
    const { dealerName, dealerid, fltersdata, typeUpload } = props;
    let obj = {
      ListingName: props.selectedTab,
      dealerName: dealerName,
      dealerId: dealerid,
      dealerType: window.dealer_type,
      eventName: typeUpload,
      label : label,
    };
    uploadOffer(obj);
  };

  /* progress value setting to state */
  const onProgress = (progress) => {
    setProgressValue(progress);
    if (progress == 100) {
      setCurrentUploadingTypeTitle(null);
      setCurrentUploadingOption(null);
    }
  };

  let selectedTab = props.selectedTab;

  /* To get options to disaply in dropdown */
  const getOptions = () => {
    if (props.isParentUpload) {
      if (window.isLogistic) {
        return logisticParentUploadOption();
      } else {
        if (selectedTab == "new") {
          return parentUploadOptionforNew();
        }
        return parentUploadOptions();
      }
    } else {
      if (window.isLogistic) {
        return logisticUploadOption();
      } else if(window.is2wDealer){
        return uploadOption2w()

      } else {
        if (selectedTab == "new") {
          return uploadOptionForNew();
        }
        return uploadOptions();
      }
    }
  };


  return (
    <div className="uplod">
      <FileUpload
        selectedTab={selectedTab}
        selectedOption={selectedOption}
        closeModal={closeModal}
        isParentUpload={props.isParentUpload}
        open={modalOpen}
        uploadType={props.uploadType}
        typeUpload={props.typeUpload}
        parentDealerId={props.parentDealerId}
        dealerid={props.dealerid}
        dealerName={props.dealerName}
        fltersdata={props.fltersdata}
        offer_header_description={props.offer_header_description}
        offer_header_sample={props.offer_header_sample}
        offer_header_resp={props.offer_header_resp}
        sendResponse={props.sendResponse}
        onProgress={onProgress}
        onClickUpload={onClickUpload}
      ></FileUpload>
      <div className="dropdown">
        {!Array.isArray(getOptions()) ? (
          <div>
            <div
              className="upldbtnLogistic"
              name="upload_offers"
              onClick={() => openUpload(getOptions())}
            >
              <span className="offrspc" name="upload_offers">
                {props.title}
              </span>
            </div>
          </div>
        ) : (
          <div
            id="uploadDropdownLink"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
          >
            <div
              className="upldbtn"
              name="upload_offers"
              // onClick={() => callDataLayer()}
            >
              <span className="offrspc" name="upload_offers">
                {props.title}
                <img
                  src={arrowDown}
                  height="15px"
                  className="download_icon rotateIconArrow"
                />
              </span>
            </div>
          </div>
        )}

        <div
          className="dropdown-menu uploadDropdownMenuContainer"
          aria-labelledby="uploadDropdownLink"
        >
          {Array.isArray(getOptions()) &&
            getOptions().map((option) => {
              return (
                <div
                  key={option.name}
                  className={
                    "d-flex uploadOption" +
                    (!isOptionUploading(option) && isAnyOptionUploading()
                      ? " disableUploadOption"
                      : "") +
                    (isOptionUploading(option) ? " disableAction" : "")
                  }
                  onClick={() => onClickOption(option)}
                >
                  <div className="uploadOptionName">{option.name}</div>
                  {isOptionUploading(option) && isAnyOptionUploading() && (
                    <div
                      className={
                        "d-flex uploadpregressContainer" +
                        (props.isParentUpload ? " mimumMargin" : "")
                      }
                    >
                      <div className="progress uploadProgress">
                        <div
                          className="progress-bar"
                          style={{ width: progressValue + "%" }}
                          role="progressbar"
                          aria-valuenow="25"
                          aria-valuemin="0"
                          aria-valuemax="100"
                        ></div>
                      </div>
                      <div className="uploadPercentageValue">
                        {progressValue.toFixed()}%
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
};
export default UploadOffers;
