import React, { useState, useRef, useEffect } from "react";
import { uploadOffer } from "../../gtm";
import "./DownloadOffers.css";
import * as Constant from "../../utils/Constant";
const CityDownload = (props) => {
  let container = useRef(null);
  const [showDropdown, setDropdown] = useState(false);
  const [status, setStatus] = useState(false);

  useEffect(() => {
    window.addEventListener("mousedown", handleClickOutside);
    return () => {
      window.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (
      props.selectedTab === Constant.priceManagement.new &&
      (props.brand.length || props.category.length)
    ) {
      setStatus(false);
    } else if (
      props.selectedTab === Constant.priceManagement.new &&
      (props.brand.length === 0 || props.category.length === 0)
    ) {
      setStatus(true);
    } else {
      setStatus(false);
    }
  }, [props]);

  const handleClickOutside = (event) => {
    if (container.current && !container.current.contains(event.target)) {
      setDropdown(false);
    }
  };

  const displayDownloadOptions = () => {
    if (window.isLogistic) {
      //need to implement logic for logistic domain
      return;
    }
    setDropdown(!showDropdown);
    const { dealerName, dealerid } = props;
    let obj = {
      ListingName: props.selectedTab,
      dealerName: dealerName,
      dealerId: dealerid,
      eventName: "Download Offers",
    };
    uploadOffer(obj);
  };

  const isAllOptionsLoading = (downloadMethod) => {
    //Need to implement logic to check from server
    return false;
  };

  return (
    <div className="btn-download-offer disp_flex">
      {props.startRecords == 0 && props.seconds > 0 && (
        <span className="error_text">
          <span className="noproduct-download-error">
            !Offer sheet cannot be downloaded as there are no products listed.
          </span>
        </span>
      )}
      {props.selectedTab == "new" && !status && props.filterApplied == false && (
        <span className="error_text">
          <span className="noproduct-download-error">
            Please choose any one of the filters available
          </span>
        </span>
      )}
      <button
        className={`btnwdth download-offers ${
          props.startRecords == 0 ? "disabled" : ""
        } ${isAllOptionsLoading() ? "disableRequestDownloadBtn" : ""}`}
        onClick={displayDownloadOptions}
      >
        <div>{Constant.priceManagement.cityDownload}</div>
      </button>
    </div>
  );
};
export default CityDownload;
