/* eslint-disable */
import React, { useEffect, useState } from "react";
import { axiospricemgmt } from "../../api/axios";
import { saveActionReplacement } from "../../utils/apiURLs";

const SaveAction = (props) => {
  let selectedrowData = props.data;

  const enableBtn = () => {
    const { service_type, tat } = selectedrowData;
    if (service_type == null || tat == null) {
      return false;
    } else if (
      (service_type == 2 || service_type == 3 || service_type == 4) &&
      tat == ""
    ) {
      return false;
    } else {
      return true;
    }
  };

  const isValidData = () => {
    return (
      (selectedrowData.service_type == 2 ||
        selectedrowData.service_type == 3 ||
        selectedrowData.service_type == 4) &&
      selectedrowData.tat >= 7 &&
      selectedrowData.tat <= 365
    );
  };

  const saveRow = () => {
    if (!isValidData() && selectedrowData.tat !== "") {
      props.agGridReact.props.open(
        "TAT value can’t be less than 7 days or more than 365 days"
      );
      return;
    }
    let md5value = props.agGridReact.props.props.md5value;
    let dealerId = props.agGridReact.props.props.dealerid;

    let payload = {
      pm_key: md5value,
      data: {
        dealerId: dealerId,
        tat: props?.data?.tat,
        sku: props?.data?.sku,
        service_type: props?.data?.service_type,
      },
    };
    document.getElementsByTagName("body")[0].classList.add("loading");
    axiospricemgmt({
      method: "post",
      url: saveActionReplacement(),
      data: payload,
      headers: {
        "Content-Type": "application/json",
      },
    }).then(function (resp) {
      document.getElementsByTagName("body")[0].classList.remove("loading");
      if (resp.data.status) {
        props.agGridReact.props.open();
        // props.agGridReact.props.props.getUpdateddata(
        //   "success",
        //   resp?.errorBean[0]?.errorMessage
        // );
      } else props.agGridReact.props.open(resp?.data?.errorBean[0].errorMessage);
    });
  };

  return (
    <>
      <button
        type="button"
        id={"replacementSavebtn"}
        className={
          !enableBtn()
            ? "replacementSavebtn replacementSavebtnDisable"
            : "replacementSavebtn"
        }
        onClick={saveRow}
      >
        Save
      </button>
    </>
  );
};
export default SaveAction;
