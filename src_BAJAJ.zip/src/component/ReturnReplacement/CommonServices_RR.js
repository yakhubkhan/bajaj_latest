import { ExportToCsv } from "export-to-csv";
import * as Constants from "./Constants_RR";
import CryptoJS from "crypto-js";



export const uploadedOfferHeaderRR = (ofd) => {
  var dealerId = typeof ofd?.DEALERID !== "undefined" ? ofd?.DEALERID : "";
  var sku = typeof ofd?.SKU !== "undefined" ? ofd?.SKU : "";
  var modelId = typeof ofd?.MODELID !== "undefined" ? ofd?.MODELID : "";
  var sellerSkuId =
    typeof ofd?.SELLER_SKU_ID !== "undefined" ? ofd?.SELLER_SKU_ID : "";
  var cityId = typeof ofd?.CITYID !== "undefined" ? ofd?.CITYID : "";
  var cityName = typeof ofd?.CITY !== "undefined" ? ofd?.CITY : "";
  var serviceType =
    typeof ofd?.SERVICETYPE !== "undefined" ? ofd?.SERVICETYPE : "";
  let tat = typeof ofd?.TAT !== "undefined" ? ofd?.TAT : "";

  return [dealerId, sku, sellerSkuId,modelId, cityId, cityName, serviceType, tat];
};

export const getmd5fromrow = (row, key) => {

  const serviceType = row["SERVICETYPE"]  == "null" ? "" : row["SERVICETYPE"];
  const tat = row["TAT"] == "null" ? "" : row["TAT"];


      const checksum_modify =
      serviceType +
      tat;
  return checksum_modify ? CryptoJS.MD5(String(checksum_modify)).toString() : ""
};


export const getmd5fromrowArray = (row) => {
  const checksum_modify = `${row[6] == null ? "" : row[6]}${
        row[7] == null ? "" : row[7]
      }`;

  return checksum_modify ? CryptoJS.MD5(String(checksum_modify)).toString() : "";
};

export const getArrangedDataRR = (offersData) => {
  return offersData.map((item, index) => {
    let cityId = typeof item.city_id !== "undefined" ? item.city_id : "";
    let cityName = typeof item.city_name !== "undefined" ? item.city_name : "";
    let modelId = typeof item.model_id !== "undefined" ? item.model_id : "";
    let sellerSkuId =
      typeof item.seller_sku_id !== "undefined" ? item.seller_sku_id : 0;
    let dealerId = window.dealerId;
    let sku = typeof item.sku !== "undefined" ? item.sku : "";
    let serviceType =
      (typeof item.service_type !== "undefined" && item.service_type != null)  ? item.service_type : "";
    let tat = (typeof item.tat !== "undefined"  && item.tat != null) ? item.tat : "";

    const row = [
      dealerId,
      sku,
      sellerSkuId,
      modelId,
      cityId,
      cityName,
      serviceType,
      tat,
    ];
    return [...row, ...[getmd5fromrowArray(row)]];
  });
};

export const downloadCallbackRR = (
  downloadOffersData,
) => {

  const headers = [...Constants.downloadCsvHeaderRR, ...["CHECKSUM"]]
  const fullData = [headers, ...downloadOffersData];

  const csvString = fullData.map(row =>
    row
    .map(String)  // convert every value to String
    .map(v => v.replaceAll('"', '""'))  // escape double colons
    .join(',')  // comma-separated
  ).join('\r\n');

  var blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
  var url = URL.createObjectURL(blob);

  // Create a link to download it
  var pom = document.createElement('a');
  pom.href = url;
  pom.setAttribute('download', "Offers");
  pom.click();
};
