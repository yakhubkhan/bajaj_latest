/* eslint-disable */
import React, { useEffect, useRef, useState } from "react";
import "@fortawesome/react-fontawesome";
import { faCaretDown } from "@fortawesome/free-solid-svg-icons";
import { library } from "@fortawesome/fontawesome-svg-core";
import AttributeOptions from "./AttributeOptions";
import NoOptions from "./NoOptions";
import { selectAllGtm } from "../../gtm";
import arrowDown from '../../images/arrowDown.png'

library.add(faCaretDown);

const MultiCheckboxSearch = (props) => {
  const [selectAll, setSelectAll] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [listItems, setListItems] = useState([]);
  const [userInput, setUserInput] = useState("");
  const [checkedValues, setCheckedValues] = useState([]);
  const [checkboxLabel, setCheckboxLabel] = useState(props.label);
  const [status, setStatus] = useState(false);

  const wrapperRef = useRef(null);

  const searchOptions = (event) => {
    setUserInput(event.target.value);
  };

  useEffect(() => {
    if (
      props.selectedTab === "new" &&
      (props.brand.length || props.category.length) &&
      (props.label === "Variants" || props.label === "Dealer Id")
    ) {
      setStatus(false);
    } else if (
      (props.label === "Variants" || props.label === "Dealer Id") &&
      props.selectedTab === "new"
    ) {
      setStatus(true);
    } else {
      setStatus(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  });

  /**
   * Hide Component Dropdown if clicked on outside of element
   */
  const handleClickOutside = (event) => {
    if (wrapperRef && !wrapperRef?.current?.contains(event.target)) {
      if (isOpen) {
        setIsOpen(false);
        setUserInput("");
      }
    }
  };

  const selectAlls = (e) => {
    if (userInput) {
      var renderSearchOption = props.options ? props.options : [];
      if (userInput) {
        renderSearchOption = props.options.filter((item) =>
          item.label
            .toString()
            .toLocaleLowerCase()
            .includes(userInput.toLocaleLowerCase())
        );
      }
      let checkedValues = renderSearchOption.map((item) =>
        item.label.toString()
      );
      let joinListItems = [...listItems, ...renderSearchOption];
      let joinCheckedValues = [...checkedValues, ...checkedValues];
      const uniqueArray = joinListItems.filter(
        (item, index) => joinListItems.indexOf(item) === index
      );
      const uniqueCheckedValues = joinCheckedValues.filter(
        (item, index) => joinCheckedValues.indexOf(item) === index
      );
      if (
        typeof props.selectedTab !== "undefined" &&
        props.selectedTab === "new" &&
        uniqueCheckedValues.length > 10
      ) {
        return false;
      }
      setListItems(uniqueArray);
      setCheckedValues(uniqueCheckedValues);
    } else {
      const checked = e.target.checked;

      if (checked) {
        let checkedValues = props.options.map((item) => item.label.toString());
        setListItems(props.options);
        setUserInput("");
        setCheckedValues(checkedValues);
        setSelectAll(true);
      } else {
        setListItems("");
        setUserInput("");
        setCheckedValues([]);
        setSelectAll(false);
      }
    }
    selectAllGtm({
      label: props.label,
      dealerId: props.dealerId,
      dealerName: props.dealerName,
    });
  };

  const loadDropDown = (event) => {
    if (props.resetFilter) {
      props.resetFilters(true);
    }
    setListItems(props.options);
    if (
      (props.label === "Variants" || props.label === "Dealer Id") &&
      props.selectedTab === "new"
    ) {
        setIsOpen(true);
    } else {
      setIsOpen(!isOpen);
    }
  };

  const filterSearchOption = () => {
    var renderSearchOption = props.options ? props.options : [];
    if (userInput) {
      renderSearchOption = props.options.filter((item) =>
        item.label
          .toString()
          .toLocaleLowerCase()
          .includes(userInput.toString().toLocaleLowerCase())
      );
    }
    return renderSearchOption;
  };

  const setValues = (event) => {
    if (event.target.checked) {
      let value = event.target.value;
      if (
        typeof props.selectedTab !== "undefined" &&
        props.selectedTab === "new" &&
        checkedValues.length + 1 > 10
      ) {
        return false;
      }
      const selectedItems = [...checkedValues, value];
      setCheckedValues(selectedItems);
      setSelectAll(selectedItems.length === renderSearchOption.length);
    } else {
      setSelectAll(false);
      removeOptions(event);
    }
  };

  const removeOptions = (e) => {
    var array = [...checkedValues]; // make a separate copy of the array
    var index = array.indexOf(e.target.value);
    if (index !== -1) {
      array.splice(index, 1);
      setCheckedValues(array);
    }
  };

  const isChecked = (value) => {
    var array = [...checkedValues]; // make a separate copy of the array
    var index = array.indexOf(value.toString());
    return index !== -1 ? true : false;
  };

  const handleApply = () => {
    setCheckboxLable();
    let json = {
      label: props.label,
      value: checkedValues,
    };
    props.changeFilter(json);
    props.onApply(checkedValues, props.label);
  };

  useEffect(() => {
    if (props.resetFilter && checkedValues.length > 0) {
      setCheckedValues([]);
      setCheckboxLabel(props.label);
    }
  }, [props, checkedValues]);

  const setCheckboxLable = () => {
    setIsOpen(false);
    if (checkedValues.length > 1) {
      setCheckboxLabel(checkedValues.length + " selected");
    } else if (checkedValues.length === 1) {
      let label =
        checkedValues[0].length <= 6
          ? checkedValues[0]
          : checkedValues[0].substring(0, 6) + "...";
      setCheckboxLabel(label);
    } else {
      setCheckboxLabel(props.label);
    }
  };

  const handleReset = () => {
    setCheckedValues([]);
    setUserInput("");
    setCheckboxLabel(props.label);
    setIsOpen(false);
    props.onReset([], props.label);
    let json = {
      label: props.label,
      value: [],
    };
    props.changeFilter(json);
  };

  let searchInputClass = "search-option";
  let renderSearchOption = filterSearchOption();

  return (
    <div
      ref={wrapperRef}
      className={`${
        window.isLogistic && checkboxLabel === "Dealer ID"
          ? "dealerId-label"
          : ""
      } main-select-wrapper`}
    >
      <button
        type="button"
        className={`${
          window.isLogistic && checkboxLabel === "Variants"
            ? "variant-field"
            : ""
        } ${status ? "aaa checkboxLabel" : "bbb checkboxLabel"}`}
        title={
          status
            ? "Please select SKUs using Category or Brand filter first"
            : ""
        }
        onClick={loadDropDown}
      >
        <span className={props.status ? "div_row filterLabel" : "filterLabel"}>
          {checkboxLabel}
        </span>
        {props.status && (
          <span className="icon-cross">
            <i
              className="fa fa-times"
              aria-hidden="true"
              onClick={handleReset}
            ></i>
          </span>
        )}
        <span
          className={`${!status ? "dropdown-carat" : ""} filterdropdownicon`}
        >
          <img src ={arrowDown} height = '16px' className={isOpen ? " rotateIcon" : ""} />
        </span>
      </button>
      {props.downloadError && (
        <div className="select-option">
          Max 50 dealers allowed to download at once
        </div>
      )}
      {isOpen &&
        (renderSearchOption.length > 0 ? (
          <AttributeOptions
            searchOptions={searchOptions}
            userInput={userInput}
            setValues={setValues}
            selectAll={selectAll}
            selectAllFunction={selectAlls}
            handleReset={handleReset}
            handleApply={handleApply}
            renderSearchOption={renderSearchOption}
            searchInputClass={searchInputClass}
            isChecked={isChecked}
            checkedValues={checkedValues}
          />
        ) : (
          <NoOptions
            searchOptions={searchOptions}
            userInput={userInput}
            selectAll={selectAlls}
            handleReset={handleReset}
          />
        ))}
    </div>
  );
};

export default MultiCheckboxSearch;
