export const downloadCsvHeaderRR = [
    "DEALERID",
    "SKU",
    "SELLER_SKU_ID",
    "MODELID",
    "CITYID",
    "CITY",
    "SERVICETYPE",
    "TAT",
  ];