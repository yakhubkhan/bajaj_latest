import React, { useEffect, useState } from "react";
import Grid from "./Grid_RR";
import useFetch from "../../api/useFetch";
import { returnOfferListtAPI } from "../../utils/apiURLs";
import TabItem from "./TabItem_RR";
import Header_RR from "./Header_RR";
import Level2Header from "../../Pages/Level2Header";
import "../../Pages/Level2Header.css";
import Filters from "./Filter_RR";
import ColumnPreferences from "./ColumnPreference_RR";
import MiddleSectionRR from "./MiddleSection_RR";
import ResponseMessageRR from "./ResponseMessage_RR";

const DashboardRR = (props) => {
  const [replacementData, setReturnReplacementData] = useState([]);
  const [totalItems, setTotalItems] = useState(0);
  const [pageNo, setPageNo] = useState(1);
  const [selectLimit, setSelectedLimit] = useState(10);
  const [searchParam, setSearchParam] = useState("");

  //Column Preference
  const [selevent, setSelevent] = useState([]);

  //Filters
  const [categoryOpts, setCategoryOpts] = useState([]);
  const [cicOpts, setCicOpts] = useState([]);
  const [brandOpts, setBrandOpts] = useState([]);
  const [cat, setCat] = useState([]);
  const [cic, setCic] = useState([]);
  const [brandFilter, setBrandFilter] = useState([]);
  const [resetFilter, setResetFilter] = useState(false);
  const [selectedRow, setSelectedRow] = useState([]);
  const [fileData, setFileData] = useState({});

  const [{ data, error }, fetchDashboardData, offersdashboardApiExtraObj] =
    useFetch(
      "POST",
      "/returnandreplacementoffersdashboard/" + window.dealerId,
      null
    );

  let colPrefs = [
    {
      title: "Product Details",
      items: [
        { label: "Brand", value: "brand" },
        { label: "Category", value: "attribute_set_id" },
        { label: "Model No", value: "model_no" },
      ],
    },
  ];

  const setColumnPrefernces = (value) => {
    setSelevent(value);
  };

  const [getFiltersDataResp, fetchFiltersData, filtersDataExtraObj] = useFetch(
    "POST",
    "/getreturnandreplacementfilter",
    null
  );

  const isAnyFilterApplied = () => {
    return cat.length > 0 || cic.length > 0 || brandFilter.length > 0;
  };

  const resetFilters = (isFiltered = false) => {
    if (isFiltered) {
      setResetFilter(false);
    }
  };

  const resetSearch = () => {
    if (isAnyFilterApplied()) {
      //setSearchParam("");
      setResetFilter(true);
      callFiltersData([], [], []);
    }
  };

  const callFiltersData = (cat, cic, brandFilter) => {
    setCat(cat);
    setCic(cic);
    setBrandFilter(brandFilter);
    // setIsGetOffersListLoading(true);

    filterApi(cat, cic, brandFilter);
  };

  const filterApi = (cat, cic, brandFilter) => {
    callOffersListApi(
      props.dealerId,
      cat,
      brandFilter,
      cic,
      "", //tat
      1, //page
      10, //limit
      searchParam
    );
    callFiltersApi(
      // dealerid,
      // selectedTab,
      cat,
      cic,
      brandFilter
      // searchParamValue,
      // parentDealerId
    );
  };

  const callFiltersApi = (
    category,
    cic,
    brandFilter
    //  srch,
    //  parentDlerId
  ) => {
    // "/getreturnandreplacementfilter",
    fetchFiltersData("", {
      pm_key: props.md5value,
      data: {
        dealerId: props.dealerId,
        //parentDealerId: props.dealerId, //not needed
        section: "active", //not needed
        activeFilters: {
          search: "",
          category: category,
          cic: cic,
          childDealerId: "",
          brand: brandFilter,
        },
      },
    });
  };

  const sortdropdown = (checked, unchecked) => {
    let combinedArray = [];
    checked.sort((a, b) => (a.label > b.label ? 1 : -1));
    combinedArray.push(...checked, ...unchecked);
    return combinedArray;
  };

  const mapfilter = (checked) => {
    let checkedarray = [];

    checked.map((val, ind) => {
      let brandobj = {};
      brandobj["label"] = val;
      brandobj["value"] = ind;
      checkedarray.push(brandobj);
    });
    return checkedarray;
  };
  const getDropdownOptions = (filterData, allfilters) => {
    let filtersdta = filterData;
    let catarr = [];
    let cicarr = [];
    let brandarr = [];
    catarr = mapfilter(filtersdta.category);
    cicarr = mapfilter(filtersdta.cic);
    brandarr = mapfilter(filtersdta.brand);
    if (allfilters !== undefined) {
      catarr = getfilterdata(filtersdta.category, allfilters.uncheckedCategory);
      cicarr = getfilterdata(filtersdta.cic, allfilters.uncheckedCic);
      brandarr = getfilterdata(filtersdta.brand, allfilters.uncheckedBrand);
    }
    setCategoryOpts(catarr);
    setCicOpts(cicarr);
    setBrandOpts(brandarr);
  };

  const getfilterdata = (checkedfilter, uncheckedfilter) => {
    let arr = [];
    if (uncheckedfilter != undefined) {
      let checked = mapfilter(checkedfilter);
      let unchecked = mapfilter(uncheckedfilter);
      arr = sortdropdown(checked, unchecked);
    } else {
      arr = mapfilter(checkedfilter);
    }
    return arr;
  };

  useEffect(() => {
    if (getFiltersDataResp.data?.payload) {
      getDropdownOptions(
        getFiltersDataResp.data.payload.filters,
        getFiltersDataResp.data.payload.allfilters
      );
    }
  }, [getFiltersDataResp.data]);

  const [getofferslistDataResp, fetchData] = useFetch(
    "POST",
    "/getreturnandreplacementlist",
    null
  );

  useEffect(() => {
    fetchDashboardData(null, {
      pm_key: props.md5value,
      dealerId: window.dealerId,
    });
    callOffersListApi(props.dealerId, "", "", "", "", 1, 10, "");
    callFiltersApi(cat, cic, brandFilter);
  }, []);

  useEffect(() => {
    if (data) {
      const totalrecords = data.payload.active;

      let totalPages = 0;
      setTotalItems(totalPages);
      if (totalrecords > 0 && totalrecords <= 10) {
        totalPages = 1;
        setTotalItems(totalPages);
      } else {
        let perPagerecords = totalrecords / 10; //divide by records per page,configured in OffersLIstGrid
        totalPages = Math.ceil(perPagerecords);
      }

      setTotalItems(totalrecords);
    }
  }, [data]);

  useEffect(() => {
    if (getofferslistDataResp?.data) {
      debugger;
      setReturnReplacementData(getofferslistDataResp?.data?.payload?.offers);
    }
  }, [getofferslistDataResp]);

  const callOffersListApi = (
    dealerId,
    cat,
    brand,
    cic,
    tat,
    page,
    limit,
    search
  ) => {
    fetchData(returnOfferListtAPI(), {
      pm_key: props.md5value,
      data: {
        dealerId: dealerId,
        page: page,
        limit: limit,
        filters: { search: search, category: cat, cic: cic, brand: brand },
      },
    });
  };

  const selectedlimit = (limit, pageNo) => {
    setSelectedLimit(limit);
  };
  const callSearch = (val) => {
    callOffersListApi(
      props.dealerId,
      cat,
      brandFilter,
      cic,
      "",
      1,
      selectLimit,
      val
    );
  };
  const getSearchVal = (e) => {
    setSearchParam(e.target.value);
  };

  const onClickCrossOnSearch = () => {
    setSearchParam("");
    callSearch("");
  };

  const getSelectedPage = (page, limit) => {
    setPageNo(page);
    setSelectedLimit(limit);
    callOffersListApi(
      props.dealerId,
      cat,
      brandFilter,
      cic,
      "",
      page,
      limit,
      searchParam
    );
  };

  const getSelectedRow = (row) => {
    setSelectedRow(row);
  };
  const uploadedFileResponse = (value) => {
    setFileData(value);
  };

  const {
    csvError,
    csvFileName,
    csvHeaderValue,
    csvSuccess,
    downloadCsvValue,
    downloadable,
    maxDealer,
    message,
    partial,
    progressPercentValue,
    speialCharError,
    showHeaderMessage,
  } = fileData;

  let responseMessage;
  responseMessage = (
    <ResponseMessageRR
      isCsvError={csvError}
      speialCharError={speialCharError}
      isMaxDealer={maxDealer}
      isPartial={partial}
      errorMessage={message}
      isShowHeaderMessage={showHeaderMessage}
      isDownloadable={downloadable}
      downloadCsvData={downloadCsvValue}
      csvFileName={csvFileName}
      progressPercent={progressPercentValue}
      isCsvSuccess={csvSuccess}
      csvHeader={csvHeaderValue}
    />
  );

  return (
    <div className="maindiv">
      <div id="stickyMainHeader" className="stickyMainHeader">
        <Header_RR
          supplierName={props.supplierName}
          dealer={props.dealer}
          dealerid={props.dealerId}
          md5value={props.md5value}
          callSearch={callSearch}
          getSearchVal={getSearchVal}
          resetSearch={onClickCrossOnSearch}
        ></Header_RR>
        <Level2Header
          value={props.level2HeaderValue}
          onChange={props.setLevel2HeaderValue}
          replacementFlag={props.replacementFlag}
        ></Level2Header>
      </div>
      {responseMessage}
      <TabItem
        searchActiveRecordsCount={
          getofferslistDataResp?.data?.searchActiveRecordsCount
        }
        activeRecordsCount={data?.payload?.active}
        isDisaplyXYformat={
          (isAnyFilterApplied() || searchParam.length > 0) &&
          !getofferslistDataResp.isLoading
        }
      />
      <div className="sectndiv">
        <MiddleSectionRR
          categoryOpts={categoryOpts}
          cicOpts={cicOpts}
          brandOpts={brandOpts}
          cat = {cat}
          cic = {cic}
          brandFilter = {brandFilter}
          callFiltersData={callFiltersData}
          resetSearch={resetSearch}
          resetFilter={resetFilter} //Check whether needed
          resetFilters={resetFilters}
          colPrefs={colPrefs}
          selevent={selevent}
          setColumnPrefernces={setColumnPrefernces}
          isFilter={
            (isAnyFilterApplied() || searchParam.length > 0) &&
            !getofferslistDataResp.isLoading
          }
          md5value={props.md5value}
          dashboardResp={data}
          getofferslistDataResp={getofferslistDataResp?.data}
          getFiltersDataResp={getFiltersDataResp?.data}
          selectedTab="active"
          selectedRow={selectedRow}
          // parentDealerId,
          // offer_header_resp ={}
          getResponse={uploadedFileResponse}
        />

        <Grid
          selevent={selevent}
          replacementData={replacementData}
          totalItems={getofferslistDataResp?.data?.searchActiveRecordsCount}
          totalRecords={getofferslistDataResp?.data?.searchActiveRecordsCount}
          pageNo={pageNo}
          getSelectedRow={getSelectedRow}
          selectedlimit={selectedlimit}
          getSelectedPage={getSelectedPage}
          md5value={props.md5value}
          dealerid={props.dealerId}
        ></Grid>
      </div>
    </div>
  );
};
export default DashboardRR;
