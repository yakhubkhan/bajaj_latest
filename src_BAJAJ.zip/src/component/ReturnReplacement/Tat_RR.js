/* eslint-disable */
import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
} from "react";
import "./common.css";

const TatRR = (props) => {
  const stockValue = useMemo(() => {
    return props.value;
  }, [props.value]);


  const isDisable = () => {
    return (
      props.data.service_type == 5 ||
      props.data.service_type == 1
    );
  };

  return (
    <div className={"disp_flex stockDisplayContainer "}>
      <div className={"stockDisplay" + (isDisable() ? " disableTatCell" : "")}>
        {stockValue}
      </div>
    </div>
  );
};
export default TatRR;

export const StockValueEditor = forwardRef((props, ref) => {
  const inputRef = useRef();

  useImperativeHandle(ref, () => {
    return {
      getValue: () => {
        return inputRef.current.value;
      },
    };
  });

  const handleClickOutside = (event) => {
    if (inputRef && !inputRef?.current?.contains(event.target)) {
      console.log("gemssss", props);
      props.api.redrawRows({
        rowNodes: [props.api.getDisplayedRowAtIndex(props.rowIndex)],
      });
      // props.api.stopEditing();
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div>
      <input
        id={"stockTextField" + props.rowIndex}
        defaultValue = {props.data.tat}
        autoFocus
        ref={inputRef}
        className={"stockValue"}
        onChange={(e) => {
          e.target.value = e.target.value.replace(/[^0-9]/g, "");
        }}
      />
    </div>
  );
});
