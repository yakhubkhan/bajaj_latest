import React, { useState } from "react";
import MultiCheckboxSearch from "../Select/MultiCheckbox";
import { resetFilters, applyFilter } from "../../gtm";
import { filters } from "../../utils/Constant";

const Filters = (props) => {
  const [catValues, SetCatValues] = useState([]);
  const [cicValues, SetCicValues] = useState([]);
  const [brandValues, SetBrandValues] = useState([]);
  const [categoryState, setCategoryState] = useState(false);
  const [cicState, setCicState] = useState(false);
  const [brandState, setBrandState] = useState(false);

  const callReset = () => {
    SetCatValues([]);
    SetCicValues([]);
    SetBrandValues([]);
    setCategoryState(false);
    setCicState(false);
    setBrandState(false);
    props.resetSearch();
  };

  const changeFilter = (data) => {
    if (
      data &&
      data.label &&
      data.label === "Category" &&
      data.value.length > 0
    )
      setCategoryState(true);
    else if (
      data &&
      data.label &&
      data.label === "Category" &&
      data.value.length === 0
    )
      setCategoryState(false);
    else if (
      data &&
      data.label &&
      (data.label === "CIC" || data.label === "Variants") &&
      data.value.length > 0
    )
      setCicState(true);
    else if (
      data &&
      data.label &&
      (data.label === "CIC" || data.label === "Variants") &&
      data.value.length === 0
    )
      setCicState(false);
    else if (
      data &&
      data.label &&
      data.label === "Brand" &&
      data.value.length > 0
    )
      setBrandState(true);
    else if (
      data &&
      data.label &&
      data.label === "Brand" &&
      data.value.length === 0
    )
      setBrandState(false);
  };

  const handleApplyReset = (optionValues, label) => {
    var catValue = catValues;
    var cicValue = cicValues;
    var brandValue = brandValues;
    if (label === "Category") {
      SetCatValues(optionValues);
      catValue = optionValues;
      //callDataLayer(optionValues, label);
      //props.callFilter(optionValues, label);
    } else if (label === "Variants") {
      SetCicValues(optionValues);
      cicValue = optionValues;
      //callDataLayer(optionValues, label);
    } else if (label === "Brand") {
      SetBrandValues(optionValues);
      brandValue = optionValues;
    } 
    props.callFiltersData(
      catValue,
      cicValue,
      brandValue,
    );
  };


  return (
    <div className="d-flex alignBottom">
      <div className="disp_flex flexColumn">
        <div className="Product-label">Product</div>
        <div className="disp_flex">
          <div className="fltrminwdth">
            <MultiCheckboxSearch
              label="Category"
              options={props.categoryOpts}
              onApply={handleApplyReset}
              onReset={handleApplyReset}
              changeFilter={changeFilter}
              status={categoryState}
              resetFilter={props.resetFilter}
              resetFilters={props.resetFilters}
              selectedTab={props.selectedTab}
              dealerId={props.dealerid}
              dealerName={props.dealerName}
              brand={brandValues}
              category={catValues}
            />
          </div>

          <div className="fltrminwdth">
            <MultiCheckboxSearch
              label="Variants"
              options={props.cicOpts}
              onApply={handleApplyReset}
              onReset={handleApplyReset}
              changeFilter={changeFilter}
              status={cicState}
              resetFilter={props.resetFilter}
              resetFilters={props.resetFilters}
              selectedTab={props.selectedTab}
              dealerId={props.dealerid}
              dealerName={props.dealerName}
              brand={brandValues}
              category={catValues}
            />
          </div>

          <div className="fltrminwdth">
            <MultiCheckboxSearch
              label="Brand"
              options={props.brandOpts}
              onApply={handleApplyReset}
              onReset={handleApplyReset}
              changeFilter={changeFilter}
              status={brandState}
              resetFilter={props.resetFilter}
              resetFilters={props.resetFilters}
              selectedTab={props.selectedTab}
              dealerId={props.dealerid}
              dealerName={props.dealerName}
              brand={brandValues}
              category={catValues}
            />
          </div>
        </div>
      </div>
      <div className="resetAll">
        <button
          className= "resetAllBtn resetAll"
          onClick={callReset}
        >
          {filters.resetAll}
        </button>
      </div>
    </div>
  );
};
export default Filters;
