import React, { useEffect, useState } from "react";
import Filters from "./Filter_RR";
import ColumnPreferences from "./ColumnPreference_RR";
import DownloadOffersRR from "./DownloadOffers_RR";

const MiddleSectionRR = (props) => {
  const {
    dealerName,
    selectedTab,
    selectedRow,
    cat,
    cic,
    brandFilter,
    parentDealerId,
    offer_header_description,
    offer_header_sample,
    offer_header_resp,
    getResponse,
    dashboardResp,
    getofferslistDataResp,
    md5value
   } = props;

  return (
    <div className="sectionmiddle">
      <div className="filterLabelTitle">FILTERS</div>
      <div className="disp_flex filtersection">
        <div className="Product">
          <div className="filter">
            <Filters
              categoryOpts={props.categoryOpts}
              cicOpts={props.cicOpts}
              brandOpts={props.brandOpts}
              callFiltersData={props.callFiltersData}
              resetSearch={props.resetSearch}
              resetFilter={props.resetFilter} //Check whether needed
              resetFilters={props.resetFilters} //Check whether needed
            />
          </div>
        </div>
        <div className="offersheet">
          <div className="Product-label">Offer Sheet</div>
          <DownloadOffersRR
            //need to add all required fields gggg
            // csvFileName="Offers.csv"
            selectedTab={selectedTab}
            // dlerid={dlerid}
            cat={cat}
            cic={cic}
            dealerid={window.dealerId}
            // isIndividualDealer = {isIndividualDealer}
            brandFilter={brandFilter}
            // cityFilter={cityFilter}
            // stateFilter={stateFilter}
            // searchParam={searchParam}
            parentDealerId={window.dealerId}
            md5value={md5value}
            // offer_header_description={offer_header_description}
            // offer_header_resp={dashboardResp?.header_description}
            // offer_header_sample={offer_header_sample}
            selectedRow={selectedRow}
            // selectedData={selectedData}
            // downloadHanlder={downloadHanlder}
            // filterApplied={isFilterApplied}
            // downloadData={downloadCityCsvData}
            // downloadThreholdError={props.downloadThreholdError}
            // offersdashboardResp={props.offersdashboardResp}
            // startRecords={props.startRecords}
            // seconds={props.seconds}
            // closeDToolTip={props.closeDToolTip}
            dealerName={dealerName}
            dashboardResp = {dashboardResp}
            // uploadType={upload_type}
            // sortopt={props.sortopt}
            // selectedPage={props.selectedPage}
            // selectedLimit={props.selectedLimit}
            // brand={brand}
            // isParentDealer={isParentDealer}
            // category={category}
            // fltersdata={fileData}
            sendResponse={getResponse}
            // dashBoardResp={dashBoardResp}
            isFilter={props.isFilter}
            getFiltersDataResp={props.getFiltersDataResp}
            getofferslistDataResp = {getofferslistDataResp}
          />
        </div>
      </div>
      <section className="sectiontop filter-section">
        <div className="settingLabelTitle">SETTINGS</div>
        <div className="d-flex spaceBtwn becomeBlock">
          <div className="d-flex">
            <ColumnPreferences
              colPrefs={props.colPrefs}
              selevent={props.selevent}
              sendValue={props.setColumnPrefernces}
              //brand={brand}
              //category={category}
              //dealerName={props.dealerName}
              //dealerid={props.dealerid}
            ></ColumnPreferences>
          </div>
        </div>
      </section>
    </div>
  );
};

export default MiddleSectionRR;
