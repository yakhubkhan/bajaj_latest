import React, { useState, useRef, useEffect } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";
import { frameworkComponents } from "./FrameworkComponents_RR";
import GridColumns_RR, { cellbg } from "./GridColumns_RR";
import Pagination from "./Pagination_RR";
import AlertDialog from "../../component/Grid/Alert";

const Grid = (props) => {
  const [gridcols, SetGridCols] = useState(GridColumns_RR());
  const [gridApi, setGridApi] = useState();
  const [gridColumnApi, setGridColumnApi] = useState();
  const [pageNo, SetPageNo] = useState(1);
  const [successAlertOpen, setSuccessAlertOpen] = useState(false);
  const [alertErrorMessage, setAlertErrorMessage] = useState("");

  function usePrevious(value) {
    const ref = useRef();
    useEffect(() => {
      ref.current = value;
    });
    return ref.current;
  }

  const gridRef = useRef();

  let defaultColDef = {
    sortable: true,
    resizable: true,
    tooltipComponent: "customTooltip",
  };

  const getRowHeight = (params) => {
    return 90;
  };

  const onGridReady = (params) => {
    const { api, columnApi } = params;
    setGridApi(api);
    setGridColumnApi(columnApi);
    params.api.setDomLayout("autoHeight");
    if (document.querySelector("#myGrid")) {
      document.querySelector("#myGrid").style.height = "";
    }
  };

  const prevPropsSelevent = usePrevious(props.selevent);

  useEffect(() => {
    let arry = [];
    if (prevPropsSelevent !== props.selevent) {
      const filds = props.selevent.map((eachItem) => {
        var obj = {};
        obj["headerName"] = eachItem.label;
        obj["field"] = eachItem.value;
        // obj["flex"] = 1;
        obj["cellClass"] = cellbg;
        obj["cellStyle"] = { borderBottom: "1px solid #e8e7e6 !important" };

        if (eachItem.value == "brand") {
          obj["cellRenderer"] = "brand";
        }
        if (eachItem.value == "attribute_set_id") {
          obj["cellRenderer"] = "attribute_set_id";
        }

        return obj;
      });
      arry = [
        ...GridColumns_RR(),
        ...filds,
      ];

      SetGridCols(arry);
      if (gridApi !== undefined) {
        gridApi.redrawRows();
      }
    }
  }, [props.selevent]);

  const onSelectionChanged = () => {
    var selectedRows = gridApi.getSelectedRows();
    props.getSelectedRow(selectedRows);

  };

  const getRowStyle = (params) => {
    if (params.node.selected) {
      return { backgroundColor: "#EBF3FF !important" };
    } else {
      return { backgroundColor: "#fff !important" };
    }
  };

  return (
    <div className="mainGridListContainer">
      <AlertDialog
        open={successAlertOpen}
        close={() => setSuccessAlertOpen(false)}
        errorMessage={alertErrorMessage}
      />
      <div
        id="myGrid"
        className={"ag-theme-alpine mainGrid "}
        style={{
          width: "100%",
        }}
      >
        <AgGridReact
          ref={gridRef}
          singleClickEdit={true}
          columnDefs={gridcols}
          rowData={props.replacementData}
          defaultColDef={defaultColDef}
          onGridReady={onGridReady}
          rowSelection="multiple"
          suppressPaginationPanel={true}
          pagination={true}
          undoRedoCellEditing={true}
          props={props}
          getUpdateddata={props.getUpdateddata}
          open={(errorMessage) => {
            setSuccessAlertOpen(true);
            setAlertErrorMessage(errorMessage);
          }}
          paginationPageSize={props.replacementData?.length}
          onSelectionChanged={onSelectionChanged}
          suppressRowClickSelection={true}
          getRowHeight={getRowHeight}
          getRowStyle={getRowStyle}
          frameworkComponents={frameworkComponents}
          tooltipShowDelay={0}
          tooltipHideDelay={5000}
        ></AgGridReact>
        <Pagination
          totalRecords={props.totalRecords}
          totalItems={props.totalItems}
          paginationPageSize={10}
          pageNo={props.pageNo}
          gridApi={gridApi}
          selectedlimit={props.selectedlimit}
          getSelectedPage={props.getSelectedPage}
        ></Pagination>
      </div>
    </div>
  );
};

export default Grid;
