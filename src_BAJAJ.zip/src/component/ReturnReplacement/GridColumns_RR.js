/* eslint-disable */
export const cellbg = (params) => {
  let classnames = "";
  const bgClr = " whiteColor ";
  const is_expired = params.data.is_expired === 1;
  classnames = (is_expired ? " disableCell " : bgClr) + classnames;
  if (params.colDef.field == "sku") {
    classnames =
      classnames +
      " skuTextStyle skuHeaderClass" +
      (is_expired ? " skuCell" : "");
  }
  if (params.colDef.field != "all") {
    classnames = classnames + " wordWrap";
  }
  if (
    params.colDef.field == "all" ||
    params.colDef.field == "brand" ||
    params.colDef.field == "model_no" ||
    params.colDef.field == "model_code_validation"
  ) {
    classnames = classnames + " justifyContentLeft";
  }
  return classnames;
};

const GridColumns_RR = () => {
  const checkboxSelection = (params) => {
    if (params.columnApi)
      return params.columnApi.getRowGroupColumns().length === 0;
    else return 0;
  };
  let defaultdridcols = [
    {
      headerName: "All",
      field: "all",
      width: 100,
      minWidth: 100,
      maxWidth: 100,
      cellClass: cellbg,
      pinned: "left",
      lockPinned: true,
      lockPosition: true,
      checkboxSelection: checkboxSelection,
      headerCheckboxSelection: checkboxSelection,
      cellStyle: {
        borderRight: "1px solid #E8E7E6 !important",
        borderBottom: "1px solid #E8E7E6 !important",
      },
    },
    {
      headerName: "SKU",
      field: "sku",
      cellClass: cellbg,
      headerClass: "skuHeaderClass",
      resizable: true,
      width: 330,
      minWidth: 330,
      maxWidth: 330,
      cellStyle: {
        "text-overflow": "clip",
        "word-wrap": "break-word",
        overflow: "visible",
        "white-space": "normal",
        "user-select": "text",
        "line-height": "15px",
        "font-size": "14px",
        "font-family": "Lato",
        color: "#231F20",
        "border-right": "1px solid #E8E7E6 !important",
        borderBottom: "1px solid #E8E7E6 !important",
      },
      pinned: "left",
    },
    {
      headerName: "Seller SKU ID",
      field: "seller_sku_id",
      flex: 1,
      minWidth: 150,
      cellClass: cellbg,
      cellStyle: {
        paddingTop: "30px",
        borderRight: "1px solid #E8E7E6 !important",
        color: "#8d8882",
        borderBottom: "1px solid #E8E7E6 !important",
      },
    },
    {
      headerName: "Model ID",
      field: "model_id",
      flex: 1,
      minWidth: 150,
      cellClass: cellbg,
      cellStyle: {
        paddingTop: "30px",
        borderRight: "1px solid #E8E7E6 !important",
        color: "#8d8882",
        borderBottom: "1px solid #E8E7E6 !important",
      },
    },
    {
      headerName: "Service Type",
      field: "service_type",
      cellRenderer: "ServiceTypeRR",
      flex: 1,
      minWidth: 250,
      cellStyle: {
        borderRight: "1px solid #E8E7E6 !important",
        borderBottom: "1px solid #E8E7E6 !important",
      },
      cellClass: cellbg,
      editable: false,
    },
    {
      headerName: "TAT (Days)",
      field: "tat",
      flex: 1,
      minWidth: 150,
      cellClass: cellbg,
      editable: (prams) => {
        console.log("gunaaaaaa", prams);
        const check =
          prams.data.service_type == 2 ||
          prams.data.service_type == 3 ||
          prams.data.service_type == 4;

        console.log("check", check);
        return check;
      },
      cellRenderer: "TatRR",
      cellEditor: "StockValueEditor",
      cellStyle: {
        borderRight: "1px solid lightgrey !important",
        borderBottom: "1px solid #E8E7E6 !important",
      },
    },
    {
      headerName: "Action",
      field: "action",
      cellRenderer: "saveaction",
      flex: 1,
      pinned: "right",
      lockPinned: true,
      cellClass: cellbg,
      cellStyle: {
        borderBottom: "1px solid #E8E7E6 !important",
      },
    },
  ];
  return defaultdridcols;
};

export default GridColumns_RR;
