/* eslint-disable */
import React, { useEffect, useState } from "react";
import cancel from "../../images/cancel.png";
import "../ColumnPreferences/ColumnPrefernce.css";
import arrowDown from "../../images/blueArrow.svg";

const ColumnPrefernces = (props) => {
  const clmslength = props && props.selevent && props.selevent.length;

  /* used onClick of checkbox ond hit gtm */
  const selectColumn = (e, mainItem) => {
    let newArray = [];
    if (e.target.checked) {
      let combine = [...props.selevent, ...mainItem.items];
      combine = combine.filter(
        (thing, index, self) =>
          index === self.findIndex((t) => t.label === thing.label)
      );
      combine.filter((item) => {
        newArray.push(item.label);
      });
      props.sendValue(combine);
    } else {
      let combine = props.selevent.filter(
        (selectedItem) =>
          !mainItem.items.some((val) => selectedItem.label == val.label)
      );
      combine.filter((item) => {
        newArray.push(item.label);
      });
      props.sendValue(combine);
    }
  };

  const multiCheckBox = (mainItem, index) => {
    const temparray = props.selevent.filter((val) =>
      mainItem.items.some((item) => item.label == val.label)
    );

    const arrLength = props.colPrefs.length;
    return (
      <div key={mainItem.title}>
        <div
          className={`${
            index === arrLength - 1 ? "" : "main-checkbox-container"
          } pad-lef-10`}
        >
          <div class="form-check pad-lef-0">
            <input
              class="form-check-input form-checkbox-input"
              type="checkbox"
              value=""
              id={"flexCheckCheckedMain" + mainItem.title}
              checked={temparray.length == mainItem.items.length}
              onChange={(e) => {
                selectColumn(e, mainItem);
              }}
            />
            <label
              class="form-check-label font14 font10"
              for={"flexCheckCheckedMain" + mainItem.title}
            >
              {mainItem.title}
            </label>
          </div>
          <div className="grid-container">
            {mainItem.items.map(
              (aryItem, index) =>
                !aryItem.hide && (
                  <div className="grid-item" key={aryItem.label + index}>
                    <div className="form-check pad-lef-0">
                      <input
                        className="form-check-input form-checkbox-input"
                        type="checkbox"
                        value=""
                        id={"flexCheckCheckedSub" + aryItem.label}
                        checked={props.selevent.find(
                          (item) => item.label === aryItem.label
                        )}
                        onChange={(e) => {
                          let newArray = [];
                          const index = props.selevent.findIndex(
                            (item) => item.label == aryItem.label
                          );
                          if (index < 0) {
                            let combine = [...props.selevent, ...[aryItem]];
                            props.sendValue(combine);
                          } else {
                            var array = [...props.selevent];
                            array.splice(index, 1);
                            array.filter((item) => {
                              newArray.push(item.label);
                            });
                            props.sendValue(array);
                          }
                        }}
                      />
                      <label
                        className="form-check-label font14"
                        htmlFor={"flexCheckCheckedSub" + aryItem.label}
                      >
                        {aryItem.label}
                      </label>
                    </div>
                  </div>
                )
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="dropdown clmPrefDrpdwnBtn">
      <div className="clmToggle">
        <div className={`${clmslength > 0 ? "columnPrefContainer" : ""}`}>
          <div className="clmPrefTitle">
            {clmslength > 0 ? clmslength + " column selected" : "Columns"}
          </div>

          {clmslength > 0 && (
            <img
              className="columnPrefcloseImg"
              src={cancel}
              onClick={() => props.sendValue([])}
            />
          )}
        </div>
      </div>
      <div
        className={`dropdown-toggle dropdown-toggle-split clmToggle removeHardDrpdwnIcon tgldrpdwn`}
        data-toggle="dropdown"
        aria-haspopup="true"
        aria-expanded="true"
      ></div>
      <div
        class="dropdown-menu bord-rad-6 dropdown-menu-left drpdwnMenu"
        aria-labelledby="dropdownMenuButton"
      >
        {/* {!status && ( */}
        <div class="clmPrefDrpDwnItm">
          {props.colPrefs.map((mainItem, index) => {
            return (
              <div className="checkbox-container">
                {multiCheckBox(mainItem, index)}
              </div>
            );
          })}
        </div>
        {/* )} */}
      </div>
      <img
        src={arrowDown}
        height="16px"
        className="download_icon rotateIconArrow"
      />
    </div>
  );
};

export default ColumnPrefernces;
