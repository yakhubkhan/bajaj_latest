import SaveAction from "./SaveAction_RR";
import ServiceTypeRR from "./ServiceType_RR";
import TatRR, { StockValueEditor } from "./Tat_RR";

export const frameworkComponents = {
  saveaction: SaveAction,
  ServiceTypeRR: ServiceTypeRR,
  TatRR: TatRR,
  StockValueEditor: StockValueEditor,
};
