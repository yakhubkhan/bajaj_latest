import React, { useState, useEffect } from "react";
import { CSVLink } from "react-csv";
import successdownload from "../../images/Group.svg";
import partialdownload from "../../images/errorIcon.svg";
import errordownload from "../../images/error-download.png";
import Modal from "react-bootstrap/Modal";

const ResponseMessageRR = (props) => {
  const [isOpen, SetisOpen] = useState(false);
  let {
    isCsvError,
    isDownloadable,
    isPartial,
    downloadCsvData,
    csvHeader,
    csvFileName,
    isCsvSuccess,
  } = props;

  useEffect(() => {
    if ((isCsvError && !isPartial) || isPartial || isCsvSuccess) {
      SetisOpen(true);
    }
  }, [isCsvSuccess, isCsvError, isPartial]);
  const closeError = () => {
    SetisOpen(false);
  };
  /* Create and return Object to use in component based on condition */
  const getImage = () => {
    if (isCsvError && !isPartial) {
      return {
        image: <img alt="errordownload" height="85px" src={errordownload} />,
        popupTitle: "Offers could not be uploaded due to error",
        description:
          "The CSV file with error is available for download. Please edit and upload again",
      };
    } else if (isPartial) {
      return {
        image: (
          <img alt="partialdownload" height="85px" src={partialdownload} />
        ),
        popupTitle: "Offers have been partially uploaded",
        description: "",
      };
    } else if (isCsvSuccess) {
      return {
        image: (
          <img alt="successdownload" height="85px" src={successdownload} />
        ),
        popupTitle: "Offers Successfully uploaded",
        description: "",
      };
    } else {
      return {
        image: "",
        popupTitle: "",
        description: "",
      };
    }
  };

  return (
    <Modal className="error-upload" centered show={isOpen}>
      <Modal.Body dialogClassName="error-popups">
        <div className="error-close">
          <div className="gfg_text-upload">
            <div className="tabImageContainer-error">{getImage().image}</div>
            <div className="offer-error-upload">
              <span>{getImage().popupTitle}</span>
            </div>
            {getImage().description && (
              <div className="offer-upload-required">
                <span>{getImage().description}</span>
              </div>
            )}
            {isDownloadable && (
              <div className="d-flex flex-column p-3">
                <CSVLink
                  data={downloadCsvData}
                  filename={csvFileName}
                  className="btn btn-primary"
                  target="_blank"
                  headers={csvHeader}
                  onClick={() => closeError()}
                >
                  Download CSV file
                </CSVLink>
              </div>
            )}
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
};

export default ResponseMessageRR;
