/* eslint-disable */
import React from "react";
import "../Tabs/TabItem.css"
import activeTab from "../../images/activeTab.svg";

const Tabsbar = (props) => {
  return (
    <div className="disp_flex tabBarContainer">
    <div 
      className=
        "tabItemContainer-logistic disp_flex alignitemsCenter isSelected"
        // onClick={() => props.clickTab("active")}
    >
      <div className="tabImageContainer">
        <img height="50px" src={activeTab} alt="listIcon" />
      </div>
      <div className="disp_flex tabTitleContainer">
        <div>
          <span className={"tabTitle  whiteColorTxt"}>
            Active Listing
          </span>
          <div className={"tabCount whiteColorTxt"}>
          {
            props.isDisaplyXYformat
              ? props.searchActiveRecordsCount + "/" + props.activeRecordsCount
              : props.activeRecordsCount
          }
          </div>
        </div>
      </div>
    </div>
    </div>
  );
};

export default Tabsbar;
