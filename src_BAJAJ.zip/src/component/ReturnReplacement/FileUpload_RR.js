/* eslint-disable */
import React, { useState, useEffect, useRef } from "react";
import Modal from "react-bootstrap/Modal";
import FileUploader from "devextreme-react/file-uploader";
import { axioscsvdata, uploadUrl } from "../../api/axios";
import {
  uploadedOfferHeaderRR,
  getmd5fromrow,
  getmd5fromrowArray,
} from "./CommonServices_RR";
import "./FileUploadRR.css";
import * as Constants from "../../utils/Constant";
import * as ConstantsRR from "./Constants_RR";

import { applyOffer, onCSVUpload, uploadOffer } from "../../gtm";
import cloudlogo from "../../images/cloudUpload.png";
import xCircle from "../../images/x-circle.svg";
import AlertDialog from "../Grid/Alert";
import moment from "moment";
import Papa from "papaparse";
import { HandlePricemanagementPHPApiRR } from "./HandlePricemanagementPHPApiRR";
import { WebWorker } from "../FileUpload/initWorker";
import uploadErrorIcon from "../../images/uploadErrorIcon.svg";

var webWorkersList = [];
var numberOfChunks = 0;
var completedchuncks = 0;
var downloadCsvValue = [];

const FileUploadRR = (props) => {
  const [showHeaderMessage, isShowHeaderMessage] = useState(false);
  const [csvError, isCsvError] = useState(false);
  const [speialCharError, setSpeialCharError] = useState("");
  const [partial, isPartial] = useState(false);
  const [message, errorMessage] = useState("");
  const [csvSuccess, isCsvSuccess] = useState(false);
  const [maxDealer, isMaxDealer] = useState(false);
  const [downloadable, isDownloadable] = useState(false);
  const [errorRowsFound, setErrorRowsFound] = useState(false);
  const [validRowsFound, setValidRowsFound] = useState(false);
  const [downloadCsvValuee, downloadCsvData] = useState([]);
  const [csvFileName, setCsvFileName] = useState("");
  const [progressPercentValue, progressPercent] = useState(0);
  const [currentTime, setCurrentTime] = useState("");
  const [csvData, setCsvData] = useState("");
  const [currentProcessCount, setCurrentProcessCount] = useState(0);
  const [limitReached, setLimitReached] = useState(0);
  const [chunkCount, setChunkCount] = useState(0);
  const [index, setIndex] = useState(0);
  const [isFailure, setFailure] = useState(0);
  const [isSuccess, setSuccess] = useState(0);
  const [targetName, setTargetName] = useState("");
  const [uploadedFileName, setUploadedFileName] = useState(null);
  const [fileSize, setFileSize] = useState(0);
  const [isDropZoneActive, setIsDropZoneActive] = useState(false);
  const [progressValue, setProgressValue] = useState(0);
  const [isProcessApiCompleted, setIsProcessApiCompleted] = useState(false);
  const [isManageApiCompleted, setIsMangeApiCompleted] = useState(false);
  const [uploadCSVArray, setUploadCSVArray] = useState([]);
  const [uploadCSVFullArray, setUploadCSVFullArray] = useState([]);
  const [headersFromCSV, setHeadersFromCSV] = useState([]);
  const [alertErrorMessage, setAlertErrorMessage] = useState("");
  const [successAlertOpen, setSuccessAlertOpen] = useState(false);
  const [modifiedFile, setModifiedFile] = useState([]);
  const [nonModifiedData, setNonModifiedData] = useState([]);

  // const [numberOfChunks, setNumberOfChunks] = useState(0);

  const fileUploader = useRef(null);
  // var numberOfChunks = 0;

  const uploadCSVMaxPercentageValue = 20;
  const uploadCSVProcessApiPercentageValue = uploadCSVMaxPercentageValue + 2;
  const uploadCSVApisRemainingPercentage =
    100 - uploadCSVProcessApiPercentageValue;

  useEffect(() => {
    if (props.open) {
      openUpload();
    }
  }, [props.open]);

  const updateProgressBar = () => {
    let progress = progressValue;
    const remaining =
      completedchuncks > 0
        ? (uploadCSVApisRemainingPercentage / csvData.apiCount) *
          completedchuncks
        : 0;

    progress = progress + remaining;

    if (props?.onProgress) {
      props.onProgress(progress);
    }
  };

  useEffect(() => {
    updateProgressBar();
  }, [progressValue, limitReached, csvData, completedchuncks, numberOfChunks]);

  useEffect(() => {
    if (csvData != "") {
      // bulkUploadCSVFile(limitReached);
      createThreadAndHitPricemanagementApi();
    }
  }, [csvData]);

  useEffect(() => {
    if (limitReached > 0) {
      bulkUploadCSVFile(limitReached);
    }
  }, [downloadCsvValue]);

  useEffect(() => {
    if (downloadCsvValue && downloadCsvValue.length > 0) {
      const dateTimeString = moment().format("DDMMYYHHmm");
      let filename =
        props.dealerid +
        "_" +
        dateTimeString +
        "_" +
        props.selectedTab +
        "_" +
        props?.selectedOption?.name +
        "_";
      if (csvError && !partial) {
        filename = filename + "errorupload";
      } else if (partial) {
        filename = filename + "partialupload";
      } else {
        filename = filename + "successupload";
      }
      filename = filename.toLowerCase() + ".csv";
      const headersTile = ["CHECKSUM", "UPLOAD STATUS"];

      props.sendResponse({
        csvError: csvError,
        speialCharError: speialCharError,
        maxDealer: maxDealer,
        partial: partial,
        message: message,
        showHeaderMessage: showHeaderMessage,
        downloadable: downloadable,
        downloadCsvValue: downloadCsvValue,
        csvFileName: filename,
        progressPercentValue: progressPercentValue,
        csvSuccess: csvSuccess,
        csvHeaderValue:
          csvData && csvData.headers
            ? [...csvData.headers, ...headersTile]
            : Constants.csvHeader,
      });
    }
  }, [
    downloadCsvValue,
    csvError,
    csvFileName,
    csvSuccess,
    maxDealer,
    partial,
    message,
    downloadable,
    showHeaderMessage,
    progressPercentValue,
    speialCharError,
  ]);

  let uploadPath = uploadUrl + "/upload/upload.php";

  /* To reset values before open upload modal and hit gtm */
  const openUpload = () => {
    setCurrentProcessCount(0);
    setCurrentTime();
    setLimitReached(0);
    setCsvData("");
    setChunkCount(0);
    downloadCsvData([]);
    isCsvError(false);
    isMaxDealer(false);
    errorMessage("");
    setSpeialCharError("");
    isShowHeaderMessage(false);
    isDownloadable(false);
    isPartial(false);
    setCsvFileName("");
    progressPercent(0);
    isCsvSuccess(false);
    setIndex(0);
    setTargetName("");
    setFailure(0);
    setSuccess(0);
    setValidRowsFound(false);
    setErrorRowsFound(false);
    setProgressValue(0);
    setUploadedFileName(null);
    const { dealerName, dealerid, fltersdata, typeUpload } = props;
    // let obj = {
    //   ListingName: props.selectedTab,
    //   dealerName: dealerName,
    //   dealerId: dealerid,
    //   dealerType: fltersdata.childDealers,
    //   eventName: typeUpload,
    // };
    // uploadOffer(obj);
  };

  /* gtm call */
  const callDataLayer = (code) => {
    onCSVUpload({
      ListingName: props.selectedTab,
      dealerId: props.dealerid,
      dealerName: props.dealerName,
      upload: props.typeUpload,
      code: code == 0 ? "error" : "success",
    });
  };

  const getSize = (size) => {
    let bytes = size;
    if (bytes >= 1073741824) {
      bytes = (bytes / 1073741824).toFixed(2) + " GB";
    } else if (bytes >= 1048576) {
      bytes = (bytes / 1048576).toFixed(2) + " MB";
    } else if (bytes >= 1024) {
      bytes = (bytes / 1024).toFixed(2) + " KB";
    } else if (bytes > 1) {
      bytes = bytes + " bytes";
    } else if (bytes == 1) {
      bytes = bytes + " byte";
    } else {
      bytes = "0 bytes";
    }
    return bytes;
  };

  const rowToMd5 = (data) => {
    let modified = [];
    let notModified = [];
    data.forEach((row, index) => {
      debugger;
      console.log(
        "CHECKSUM",
        row.NAME,
        getmd5fromrow(row, props.selectedOption.key),
        row.CHECKSUM
      );
      if (
        index <= 1 ||
        getmd5fromrow(row, props.selectedOption.key) != row.CHECKSUM
      ) {
        delete row.CHECKSUM;
        modified.push(row);
      } else {
        const values = Object.values(row);
        notModified.push([...values, ...["Not Updated"]]);
      }
    });
    setNonModifiedData(notModified);
    // setFilteredCsv(modified)
    return modified;
  };

  /* used while entering file while drog on drop */
  const onDropZoneEnter = (e) => {
    applyOffer({
      dealerName: props.dealerName,
      dealerId: props.dealerid,
      fileType: "Select File",
      upload: props.typeUpload,
    });
    if (e.value[0] && e.value[0].name == "modifiedUpdatedRows.csv") {
      return;
    }
    Papa.parse(e.value[0], {
      header: true,
      skipEmptyLines: "greedy",
      complete: (results) => {
        setHeadersFromCSV(results.meta.fields);
        console.log("ggggg", results.data);
        setUploadCSVFullArray(JSON.parse(JSON.stringify(results.data)));
        let data = rowToMd5(results.data);
        setUploadCSVArray(data);
        const file = Papa.unparse(data, {
          quotes: false, //or array of booleans
          quoteChar: '"',
          escapeChar: '"',
          delimiter: ",",
          header: true,
          newline: "\r\n",
          skipEmptyLines: false, //other option is 'greedy', meaning skip delimiters, quotes, and whitespace.
          columns: null, //or array of strings
        });
        const filecsv = new File([file], "modifiedUpdatedRows.csv", {
          type: "text/csv",
        });
        setModifiedFile([filecsv]);
      },
    });

    setIsDropZoneActive(false);
    setUploadedFileName(e.value[0].name);
    setFileSize(getSize(e.value[0].size));
    if (e.value[0].type != "text/csv") {
      errorMessage("Please upload the file in CSV format");
    } else {
      errorMessage("");
    }
  };

  /* To hit process.php api */
  const onUploaded = (e) => {
    let response = JSON.parse(e.request.responseText);
    if (typeof response.fileName !== "undefined") {
    }
    if (typeof response.fileName !== "undefined") {
      axioscsvdata({
        method: "post",
        url: uploadUrl + props.selectedOption.processURL,
        data: {
          data: {
            parentDealerId: props.parentDealerId,
            loginDealerId: window.dealerId,
            fileName: response.fileName,
            upload_type: props.selectedOption.uploadType,
            type: props.isParentUpload ? "parent" : "normal",
          },
        },
        headers: {
          "Content-Type": "application/json;charset=utf-8",
        },
      })
        .then((resp) => {
          setProgressValue(uploadCSVProcessApiPercentageValue);
          if (typeof resp.data.error !== "undefined") {
            isCsvError(true);
            isMaxDealer(false);
            isShowHeaderMessage(true);
            if (resp.data.error.code == 101) {
              setSuccessAlertOpen(true);
              setAlertErrorMessage("Please Upload the file in Correct Format");
            } else if (
              resp.data.error.code == 150 ||
              resp.data.error.code == 151
            ) {
              // errorMessage(resp.data.error.message);
              // setSpeialCharError(resp.data.error.message);
              setSuccessAlertOpen(true);
              setAlertErrorMessage(resp.data.error.message[0]);
            } else {
              errorMessage("The csv header does not contain stipulated Header");
            }

            setProgressValue(100);
            props.closeModal();
          } else if (typeof resp.data.success !== "undefined") {
            // let dataLength = resp.data.data.length;
            setCurrentTime(resp.data.currentTime);
            downloadCsvData([...downloadCsvValue]);
            setCurrentProcessCount(0);
            // setChunkCount(dataLength);
            // setLimitReached(dataLength);
            numberOfChunks = resp.data.apiCount;
            setCsvData(resp.data);

            // createThreadAndHitPricemanagementApi();
            // bulkUpload(dataLength)
            // props.closeModal();
          }
        })
        .catch((err) => {
          // console.log("in catch of filter");
          // console.log(err);
          setProgressValue(100);
        });
      applyOffer({
        dealerName: props.dealerName,
        dealerId: props.dealerid,
        fileType: "Upload File",
        upload: props.uploadType,
      });
    }
  };

  // const onProgress = (e) => {
  //   // let calculatedValue = (e.bytesLoaded / e.bytesTotal) * 100;
  //   // setProgressValue(calculatedValue);
  // };

  const isValidCSVHeaderFormat = () => {
    let headerDiscription = [];

    let headesStringFromCSV =
      headersFromCSV.length > 0
        ? headersFromCSV.join().replace(/[_,]/g, "").toUpperCase()
        : "";

    // headerDiscription = Constants.downloadCsvHeader;

    headerDiscription = ConstantsRR.downloadCsvHeaderRR;

    debugger;

    let headerDiscriptionStrng = headerDiscription
      .join()
      .replace(/[_,]/g, "")
      .toUpperCase();
    headerDiscriptionStrng = headerDiscriptionStrng + "CHECKSUM";

    return headesStringFromCSV == headerDiscriptionStrng;
  };

  const isValidLimitCount = () => {
    if (uploadCSVArray.length >= 100003) {
      return false;
    }
    return true;
  };

  const isGreaterThenZero = () => {
    //First two rows are header description and header sample so checking with value 2
    return uploadCSVArray.length == 2;
  };
  const combileCSVRows = (resp) => {
    if (
      typeof resp.validRowsFound !== "undefined" &&
      !validRowsFound &&
      resp.validRowsFound
    ) {
      setValidRowsFound(true);
      setSuccess(1);
    }
    if (
      typeof resp.errorRowsFound !== "undefined" &&
      !errorRowsFound &&
      resp.errorRowsFound
    ) {
      setErrorRowsFound(true);
      setFailure(1);
    }

    if (typeof resp.error !== "undefined") {
      // setIsMangeApiCompleted(true);
      isCsvError(true);
      isMaxDealer(false);
      isShowHeaderMessage(false);
      errorMessage(resp.error);
      // callDataLayer(0);
      if (numberOfChunks == 0 && csvData.apiCount == completedchuncks) {
        setProgressValue(100);
      }
    } else {
      resp.csvData.forEach((row) => {
        const index = row.length - 1;
        const md5 = getmd5fromrowArray(row, props.selectedOption.key);
        row.splice(index, 0, md5);
      });
      downloadCsvValue = [...downloadCsvValue, ...resp.csvData];
      // downloadCsvValue = combineSkus
      if (numberOfChunks == 0 && csvData.apiCount == completedchuncks) {
        setProgressValue(100);
        downloadCsvValue = [...downloadCsvValue, ...nonModifiedData];

        var ofd =
          props?.offer_header_resp &&
          props?.offer_header_resp[props.selectedOption.headerDescriptionKey];
        var ofs =
          props?.offer_header_resp &&
          props?.offer_header_resp[props.selectedOption.headerSampleKey];
        var uploadedDesc = uploadedOfferHeaderRR(ofd);
        var uploadedSample = uploadedOfferHeaderRR(ofs);

        // setIsMangeApiCompleted(true);
        setCsvFileName("Offers_" + props.dealerid + "_error.csv");
        downloadCsvValue = [uploadedDesc, uploadedSample, ...downloadCsvValue];
        if (resp.validRowsFound && resp.errorRowsFound) {
          // downloadCsvData([uploadedDesc, uploadedSample, ...combineSkus]);
          isCsvError(false);
          isPartial(true);
          errorMessage(
            "The CSV file with errors is available for download.Please edit and upload again"
          );
          callDataLayer(0);
        } else if (resp.errorRowsFound) {
          // downloadCsvData([uploadedDesc, uploadedSample, ...combineSkus]);
          isCsvError(true);
          isMaxDealer(false);
          isShowHeaderMessage(false);
          isPartial(false);
          errorMessage(
            "The CSV file with errors is available for download.Please edit and upload again"
          );
          callDataLayer(0);
        } else {
          // downloadCsvData([uploadedDesc, uploadedSample, ...combineSkus]);
          isCsvSuccess(true);
          setCsvFileName("Offers_" + props.dealerid + "_success.csv");
          callDataLayer(1);
        }
        isDownloadable(true);
      }
    }
  };

  const terminateAllCurrentWorkers = () => {
    webWorkersList.forEach((worker) => {
      worker.terminate();
    });
  };

  const postMessageForPMapi = (worker) => {
    worker.postMessage({
      csvData: csvData,
      dealerId: window.dealerId,
      selectedOption: props.selectedOption,
      currentIndex: numberOfChunks,
      parentDealerId: props.parentDealerId,
      uploadUrl: uploadUrl,
    });
    numberOfChunks = numberOfChunks - 1;
    // setNumberOfChunks(chunks);
  };

  const createThreadAndHitPricemanagementApi = () => {
    terminateAllCurrentWorkers();
    const threads = props.isParentUpload ? 3 : 4;
    const numberOfThreads =
      numberOfChunks >= threads ? threads : numberOfChunks;

    for (let i = 0; i < numberOfThreads; i++) {
      if (numberOfChunks > 0) {
        var worker = WebWorker(HandlePricemanagementPHPApiRR);
        webWorkersList.push(worker);
        postMessageForPMapi(worker);
        worker.onmessage = (e) => {
          completedchuncks = completedchuncks + 1;
          updateProgressBar();
          combileCSVRows(e.data);
          // worker.terminate()
          if (numberOfChunks > 0) {
            postMessageForPMapi(worker);
          }
        };
      }
    }
  };

  const onClickUpload = () => {
    // createThreadAndHitPricemanagementApi();
    // return;
    // alert('aaa')
    // props.onClickUpload()
    terminateAllCurrentWorkers();
    webWorkersList = [];
    numberOfChunks = 0;
    completedchuncks = 0;
    downloadCsvValue = [];

    if (!uploadedFileName) {
      errorMessage("Please select file to upload");
    } else if (!isValidLimitCount()) {
      const errorMsg = props.isParentUpload
        ? "Please upload file with less than 10000 SKUs to proceed"
        : "Please upload file with less than 100000 SKUs to proceed";

      setAlertErrorMessage(errorMsg);
      setSuccessAlertOpen(true);
    } else if (isGreaterThenZero()) {
      const errorMsg = "No Changes Found in the sheet";
      setAlertErrorMessage(errorMsg);
      setSuccessAlertOpen(true);
    } else if (!isValidCSVHeaderFormat()) {
      setAlertErrorMessage("Please Upload the file in Correct Format");
      setSuccessAlertOpen(true);
    } else {
      fileUploader.current.instance.upload();
      props.onClickUpload();
      props.closeModal();
    }
  };

  return (
    <>
      <AlertDialog
        open={successAlertOpen}
        close={() => {
          setSuccessAlertOpen(false);
          setAlertErrorMessage("");
        }}
        errorMessage={alertErrorMessage}
      />
      <div className="bulk-upload">
        <Modal
          className="csv-modal-header"
          show={props.open}
          onHide={props.closeModal}
          size="md"
          aria-labelledby="contained-modal-title-vcenter"
          centered
          contentClassName="contentClassRR"
        >
          <Modal.Body>
            <div className="closeContainerRR">
              <img
                height="26px"
                src={xCircle}
                onClick={() => props.closeModal()}
              />
            </div>
            <div
              id="dropzone-external"
              className={`flex-box dropuploadzoneRR ${
                isDropZoneActive ? "dropzone-activeRR" : "dropzone-inactive"
              }`}
              onMouseLeave={() => setIsDropZoneActive(false)}
            >
              <img className="icon_cloudRR" src={cloudlogo} alt="cloud"></img>
              <div className="dragDropText">
                Drag and drop Files or Browse on your computer
              </div>
              <div className="uploadWarningMessageRR">
                Upload might take up to 20 minutes depending on the size of your
                file. Please check Upload dropdown to track progress
              </div>
              <div className="uploadOffersBtnRR" onClick={onClickUpload}>
                Upload Offers
              </div>
              <div id="selectFileBtnId" className="selectFileOffersBtnRR">
                Select File
              </div>
              {uploadedFileName && (
                <div className="selectedFileNameContainerRR">
                  <div className="selectedFileNameRR">{uploadedFileName}</div>
                  <div className="selectedFileSizeRR">{fileSize}</div>
                </div>
              )}
              {message && (
                <div className="uploaderrorText">
                  {<img className="uploadErrorIcon" src={uploadErrorIcon} />}
                  {message}
                </div>
              )}
            </div>

            <FileUploader
              name="file"
              ref={fileUploader}
              accept="*"
              selectButtonText="Upload Offers"
              uploadUrl={uploadPath}
              uploadMode="useButtons"
              dialogTrigger="#selectFileBtnId"
              dropZone="#dropzone-external"
              onValueChanged={onDropZoneEnter}
              visible={false}
              onProgress={(e) => {
                const value = (e.bytesLoaded / e.bytesTotal) * 100;
                setProgressValue((value / 100) * uploadCSVMaxPercentageValue);
              }}
              allowedFileExtensions={[".csv"]}
              chunkSize={200000}
              onUploaded={onUploaded}
              value = {modifiedFile}

            />
          </Modal.Body>
        </Modal>
      </div>
    </>
  );
};

export default FileUploadRR;
