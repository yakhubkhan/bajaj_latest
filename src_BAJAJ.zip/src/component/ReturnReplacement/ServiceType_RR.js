import React from "react";

const ServiceTypeRR = (props) => {
  const onStatusChange = (e) => {
    const val = e.target.value;

    if (val == 1 || val == 5) {
      props.data.tat = "";
    }

    props.setValue(val);
    props.api.redrawRows({
      rowNodes: [props.api.getDisplayedRowAtIndex(props.rowIndex)],
    });
  };
  return (
    <div>
      <select
        className="statusslctRep"
        id="options"
        onChange={onStatusChange}
        value={props.data.service_type}
      >
        <option id="selectoption" hidden>
          Select
        </option>
        <option value={1}>Non returnable/Non replacable</option>
        <option value={2}>Return</option>
        <option value={3}>Replacement</option>
        <option value={4}>Return/Replacement both</option>
        <option value={5}>None</option>
      </select>
    </div>
  );
};

export default ServiceTypeRR;
