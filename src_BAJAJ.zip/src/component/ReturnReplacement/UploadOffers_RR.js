/* eslint-disable */
import React, { useState, useEffect } from "react";
import FileUpload from "../FileUpload/FileUpload";
import "../DownloadOffers/uploadOffers.css";

// import "./uploadOffers.css";
import arrowDown from "../../images/blueArrow.svg";
import {
    uploadRROptions
} from "../../utils/Constant";

import { uploadOffer } from "../../gtm";
import FileUploadRR from "./FileUpload_RR";

const UploadOffersRR = (props) => {
  const [modalOpen, isOpen] = useState(false);
  const [progressValue, setProgressValue] = useState(0);
  const [currentUploadingTypeTitle, setCurrentUploadingTypeTitle] =
    useState(null);
  const [currentUploadingOption, setCurrentUploadingOption] = useState(null);
  const [selectedOption, setSelectedOption] = useState(null);


  /* To check is any csv uploading and return bool */
  const isOptionUploading = (option) => {
    return (
      currentUploadingTypeTitle == props.title &&
      option.name == currentUploadingOption?.name &&
      progressValue > 0 &&
      progressValue < 100
    );
  };
  /* To check is any csv uploading and return bool */
  const isAnyOptionUploading = () => {
    return (
      currentUploadingTypeTitle == props.title &&
      progressValue > 0 &&
      progressValue < 100
    );
  };

  /* To open upload view popup */
  const openUpload = (option) => {
    isOpen(!modalOpen);
    setSelectedOption(option);
  };

  /*get call on Click on Upload cta */
  const onClickUpload = () => {
    setCurrentUploadingTypeTitle(props.title);
    setCurrentUploadingOption(selectedOption);
  };

  /* To close upload view popup */
  const closeModal = () => {
    isOpen(false);
  };

  /* To check and open upload view   */
  const onClickOption = (option) => {
    if (!isAnyOptionUploading()) {
      openUpload(option);
    }
  };

  /* To hit gtm */
//   const callDataLayer = () => {
//     const { dealerName, dealerid, fltersdata, typeUpload } = props;
//     let obj = {
//       ListingName: props.selectedTab,
//       dealerName: dealerName,
//       dealerId: dealerid,
//       dealerType: fltersdata.childDealers,
//       eventName: typeUpload,
//     };
//     uploadOffer(obj);
//   };

  /* progress value setting to state */
  const onProgress = (progress) => {
    setProgressValue(progress.toFixed());
    if (progress == 100) {
      setCurrentUploadingTypeTitle(null);
      setCurrentUploadingOption(null);
    }
  };

  let selectedTab = props.selectedTab;

  /* To get options to disaply in dropdown */
  const getOptions = () => {

    return uploadRROptions();

  };

  return (
    <div className="uplod">
      <FileUploadRR
        selectedTab={selectedTab}
        selectedOption={selectedOption}
        closeModal={closeModal}
        isParentUpload={props.isParentUpload}
        open={modalOpen}
        uploadType={props.uploadType}
        typeUpload={props.typeUpload}
        parentDealerId={props.parentDealerId}
        dealerid={props.dealerid}
        dealerName={props.dealerName}
        fltersdata={props.fltersdata}
        // offer_header_description={props.offer_header_description}
        // offer_header_sample={props.offer_header_sample}
        offer_header_resp={props.dashboardResp?.header_description}
        sendResponse={props.sendResponse}
        onProgress={onProgress}
        onClickUpload={onClickUpload}
      ></FileUploadRR>
      <div className="dropdown">
        {!Array.isArray(getOptions()) ? (
          <div>
            <div
              className="upldbtnLogistic"
              name="upload_offers"
              onClick={() => openUpload(getOptions())}
            >
              <span className="offrspc" name="upload_offers">
                {props.title}s
              </span>
            </div>
          </div>
        ) : (
          <div
            id="uploadDropdownLink"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
          >
            <div
              className="upldbtn"
              name="upload_offers"
            //   onClick={() => callDataLayer()}
            >
              <span className="offrspc" name="upload_offers">
                {props.title}
                <img
                  src={arrowDown}
                  height="15px"
                  className="download_icon rotateIconArrow"
                />
              </span>
            </div>
          </div>
        )}

        <div
          className="dropdown-menu uploadDropdownMenuContainer"
          aria-labelledby="uploadDropdownLink"
        >
          {Array.isArray(getOptions()) &&
            getOptions().map((option) => {
              return (
                <div
                key = {option.name}
                  className={
                    "d-flex uploadOption" +
                    (!isOptionUploading(option) && isAnyOptionUploading()
                      ? " disableUploadOption"
                      : "") +
                    (isOptionUploading(option) ? " disableAction" : "")
                  }
                  onClick={() => onClickOption(option)}
                >
                  <div className="uploadOptionName">{option.name}</div>
                  {isOptionUploading(option) && isAnyOptionUploading() && (
                    <div
                      className={
                        "d-flex uploadpregressContainer" +
                        (props.isParentUpload ? " mimumMargin" : "")
                      }
                    >
                      <div className="progress uploadProgress">
                        <div
                          className="progress-bar"
                          style={{ width: progressValue + "%" }}
                          role="progressbar"
                          aria-valuenow="25"
                          aria-valuemin="0"
                          aria-valuemax="100"
                        ></div>
                      </div>
                      <div className="uploadPercentageValue">
                        {progressValue}%
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
};
export default UploadOffersRR;
