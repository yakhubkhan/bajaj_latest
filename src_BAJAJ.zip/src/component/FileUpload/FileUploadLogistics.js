/* eslint-disable */
import React, { useState, useEffect, useRef } from "react";
import Modal from "react-bootstrap/Modal";
import FileUploader from "devextreme-react/file-uploader";
import { axioscsvdata, uploadUrl } from "../../api/axios";
import uploadedOfferHeader, {
  getArrangedData,
} from "../../utils/CommonServices";
import FileUploads from "./FileUploads.css";
import * as Constants from "../../utils/Constant";
import { applyOffer, onCSVUpload, uploadOffer } from "../../gtm";
import cloudlogo from "../../images/cloudUpload.png";
import ProgressBar from "devextreme-react/progress-bar";
import xCircle from "../../images/x-circle.svg";
import AlertDialog from "../Grid/Alert";
import Papa from "papaparse";

const FileUploadLogistics = (props) => {
  const [showHeaderMessage, isShowHeaderMessage] = useState(false);
  const [csvError, isCsvError] = useState(false);
  const [speialCharError, setSpeialCharError] = useState("");
  const [partial, isPartial] = useState(false);
  const [message, errorMessage] = useState("");
  const [csvSuccess, isCsvSuccess] = useState(false);
  const [maxDealer, isMaxDealer] = useState(false);
  const [downloadable, isDownloadable] = useState(false);
  const [errorRowsFound, setErrorRowsFound] = useState(false);
  const [validRowsFound, setValidRowsFound] = useState(false);
  const [downloadCsvValue, downloadCsvData] = useState([]);
  const [csvFileName, setCsvFileName] = useState("");
  const [progressPercentValue, progressPercent] = useState(0);
  const [currentTime, setCurrentTime] = useState("");
  const [csvData, setCsvData] = useState("");
  const [currentProcessCount, setCurrentProcessCount] = useState(0);
  const [limitReached, setLimitReached] = useState(0);
  const [chunkCount, setChunkCount] = useState(0);
  const [index, setIndex] = useState(0);
  const [isFailure, setFailure] = useState(0);
  const [isSuccess, setSuccess] = useState(0);
  const [targetName, setTargetName] = useState("");
  const [uploadedFileName, setUploadedFileName] = useState(null);
  const [fileSize, setFileSize] = useState(0);
  // const [uploadModal, setUploadModal] = useState(true);
  const [isDropZoneActive, setIsDropZoneActive] = useState(false);
  const [progressVisible, setProgressVisible] = useState(false);
  const [progressValue, setProgressValue] = useState(0);
  const [uploadCSVArray, setUploadCSVArray] = useState([]);

  const [isProcessApiCompleted, setIsProcessApiCompleted] = useState(false);
  const [isManageApiCompleted, setIsMangeApiCompleted] = useState(false);

  const [alertErrorMessage, setAlertErrorMessage] = useState("");
  const [successAlertOpen, setSuccessAlertOpen] = useState(false);

  const fileUploader = useRef(null);

  useEffect(() => {
    if (props.open) {
      openUpload();
    }
  }, [props.open]);

  useEffect(() => {
    let progress = progressValue;
    if (progress > 50 && (!isProcessApiCompleted || !isManageApiCompleted)) {
      console.log("progress", progress);
      progress = progress - 10;
    }

    if (props?.onProgress) {
      props.onProgress(progress);
    }
  }, [progressValue, isProcessApiCompleted, isManageApiCompleted]);

  useEffect(() => {
    if (csvData != "" && limitReached > 0) {
      bulkUploadCSVFile(limitReached);
    }
  }, [csvData]);

  useEffect(() => {
    if (limitReached > 0) {
      bulkUploadCSVFile(limitReached);
    }
  }, [downloadCsvValue]);

  useEffect(() => {

    if (downloadCsvValue && downloadCsvValue.length > 0)
      props.sendResponse({
        csvError: csvError,
        speialCharError: speialCharError,
        maxDealer: maxDealer,
        partial: partial,
        message: message,
        showHeaderMessage: showHeaderMessage,
        downloadable: downloadable,
        downloadCsvValue: downloadCsvValue,
        csvFileName: csvFileName,
        progressPercentValue: progressPercentValue,
        csvSuccess: csvSuccess,
        csvHeaderValue:
          csvData && csvData[0] && csvData[0][0]
            ? [...Object.keys(csvData[0][0]), ...["UPLOAD STATUS"]]
            : Constants.csvHeader,
      });
  }, [
    downloadCsvValue,
    csvError,
    csvFileName,
    csvSuccess,
    maxDealer,
    partial,
    message,
    downloadable,
    showHeaderMessage,
    progressPercentValue,
    speialCharError,
  ]);

  let uploadPath = uploadUrl + "/upload/upload.php";

  const openUpload = () => {
    setCurrentProcessCount(0);
    setCurrentTime();
    setLimitReached(0);
    setCsvData("");
    setChunkCount(0);
    downloadCsvData([]);
    isCsvError(false);
    isMaxDealer(false);
    errorMessage("");
    setSpeialCharError("");
    isShowHeaderMessage(false);
    isDownloadable(false);
    isPartial(false);
    setCsvFileName("");
    progressPercent(0);
    isCsvSuccess(false);
    setIndex(0);
    // setDataIndex(0);
    setTargetName("");
    setFailure(0);
    setSuccess(0);
    setValidRowsFound(false);
    setErrorRowsFound(false);
    setProgressVisible(false);
    setProgressValue(0);
    setUploadedFileName(null);
    const { dealerName, dealerid, fltersdata, typeUpload } = props;
    let obj = {
      ListingName: props.selectedTab,
      dealerName: dealerName,
      dealerId: dealerid,
      dealerType: fltersdata.childDealers,
      eventName: typeUpload,
    };
    uploadOffer(obj);
  };

  const callDataLayer = (code) => {
    onCSVUpload({
      ListingName: props.selectedTab,
      dealerId: props.dealerid,
      dealerName: props.dealerName,
      upload: props.typeUpload,
      code: code == 0 ? "error" : "success",
    });
  };

  const bulkUploadCSVFile = (data) => {
    let url;
    let allCsvData = csvData;
    if (typeof allCsvData[index] !== "undefined" && data > 0) {
      // let uploadFileUrl = window.isLogistic
      //   ? props.typeUpload === "upload offers"
      //     ? logisticNormalPath
      //     : logisticParentUploadPath
      //   : props.selectedOption.processURL;
      let limitReached = data - 1;
      setLimitReached(limitReached);
      let isLastData = limitReached == 0 ? 1 : 0;
      var currentData = allCsvData[index];

      if (index == 0) {
        currentData.splice(0, 2);
      }
      setIndex(index + 1);
      // setDataIndex(dataIndex + 1);
      var length = currentData.length;
      let isFirstData = currentProcessCount == 0 ? 1 : 0;
      setCurrentProcessCount(currentProcessCount + length);
      var currentChunkCount = chunkCount - limitReached;
      var progressCalc = (currentChunkCount / chunkCount) * 100;
      progressPercent(Math.round(progressCalc));
      var requestData = {};
      requestData.csv_data = JSON.stringify(currentData);
      requestData.targetName = targetName;
      requestData.isLastData = isLastData;
      requestData.currentTime = currentTime;
      requestData.isFirstData = isFirstData;
      requestData.isFailure = isFailure;
      requestData.isSuccess = isSuccess;
      requestData.loginDealerId = window.dealerId;
      requestData.parentDealerId = props.parentDealerId;
      requestData.upload_type = props.selectedOption.uploadType;
      // url = props.uploadType
      //   ? uploadUrl + "/upload/parent_price_upload.php"
      //   : uploadUrl + "/upload/price_management.php";
      url = uploadUrl + props.selectedOption.priceManagementURL;
      axioscsvdata({
        method: "post",
        url: url,
        data: requestData,
        dataType: "JSON",
      })
        .then((resp) => {
          // const resp =      await axioscsvdata({
          //     method: "post",
          //     url: url,
          //     data: requestData,
          //     dataType: "JSON",
          //   })
          //     .then((resp) => {
          //       console.log('gfgfgfg00', resp)
          //       return resp
          //     }).catch((err) => {

          //       console.log('lkkllk', err)
          //       return err

          //     })
          var ofd =
            props.offer_header_resp[props.selectedOption.headerDescriptionKey];
          var ofs =
            props.offer_header_resp[props.selectedOption.headerSampleKey];
          var uploadedDesc = uploadedOfferHeader(
            ofd,
            false,
            false,
            props.selectedOption.key
          );
          var uploadedSample = uploadedOfferHeader(
            ofs,
            false,
            false,
            props.selectedOption.key
          );
          if (
            typeof resp.data.validRowsFound !== "undefined" &&
            !validRowsFound &&
            resp.data.validRowsFound
          ) {
            setValidRowsFound(true);
            setSuccess(1);
          }
          if (
            typeof resp.data.errorRowsFound !== "undefined" &&
            !errorRowsFound &&
            resp.data.errorRowsFound
          ) {
            setErrorRowsFound(true);
            setFailure(1);
          }

          // if (typeof csvData !== "undefined" && csvData) {
          //   downloadCsvData([...downloadCsvValue, ...csvData]);
          // }
          //   if (typeof resp.data.csvData !== 'undefined' && resp.data.csvData) {
          //     downloadCsvData([...downloadCsvValue, ...resp.data.csvData] );
          // }
          const combineSkus = [...downloadCsvValue, ...resp.data.csvData];
          if (typeof resp.data.error !== "undefined") {
            setIsMangeApiCompleted(true);
            isCsvError(true);
            isMaxDealer(false);
            isShowHeaderMessage(false);
            errorMessage(resp.data.error);
            // callDataLayer(0);
          } else if (limitReached > 0) {
            // bulkUploadCSVFile(limitReached);
            resp.data.csvData && downloadCsvData(combineSkus);
          } else {
            setIsMangeApiCompleted(true);
            setCsvFileName("Offers_" + props.dealerid + "_error.csv");
            if (resp.data.validRowsFound && resp.data.errorRowsFound) {
              downloadCsvData([uploadedDesc, uploadedSample, ...combineSkus]);
              isCsvError(false);
              isPartial(true);
              errorMessage(
                "The CSV file with errors is available for download.Please edit and upload again"
              );
              callDataLayer(0);
            } else if (resp.data.errorRowsFound) {
              downloadCsvData([uploadedDesc, uploadedSample, ...combineSkus]);
              isCsvError(true);
              isMaxDealer(false);
              isShowHeaderMessage(false);
              isPartial(false);
              errorMessage(
                "The CSV file with errors is available for download.Please edit and upload again"
              );
              callDataLayer(0);
            } else {
              downloadCsvData([uploadedDesc, uploadedSample, ...combineSkus]);
              isCsvSuccess(true);
              setCsvFileName("Offers_" + props.dealerid + "_success.csv");
              callDataLayer(1);
            }
            isDownloadable(true);
          }
        })
        .catch((err) => {
          // console.log("in catfffch of filter");
          callDataLayer(0);
          setIsMangeApiCompleted(true);
          setIsProcessApiCompleted(true);
          // console.log(err);
        });
    }
  };

  const getSize = (size) => {
    let bytes = size;
    if (bytes >= 1073741824) {
      bytes = (bytes / 1073741824).toFixed(2) + " GB";
    } else if (bytes >= 1048576) {
      bytes = (bytes / 1048576).toFixed(2) + " MB";
    } else if (bytes >= 1024) {
      bytes = (bytes / 1024).toFixed(2) + " KB";
    } else if (bytes > 1) {
      bytes = bytes + " bytes";
    } else if (bytes == 1) {
      bytes = bytes + " byte";
    } else {
      bytes = "0 bytes";
    }

    return bytes;
  };

  const onDropZoneEnter = (e) => {
    applyOffer({
      dealerName: props.dealerName,
      dealerId: props.dealerid,
      fileType: "Select File",
      upload: props.typeUpload,
    });

    Papa.parse(e.value[0], {
      header: true,
      skipEmptyLines: true,
      complete: function (results) {
        console.log("ggggg", results.data);
        setUploadCSVArray(results.data);
      },
    });

    setIsDropZoneActive(false);
    setUploadedFileName(e.value[0].name);
    setFileSize(getSize(e.value[0].size));
    if (e.value[0].type != "text/csv") {
      errorMessage("Please upload the file in CSV format");
    } else {
      errorMessage("");
    }

    // console.log("e.value[0]", e.value[0]);
  };

  const onUploaded = (e) => {
    let response = JSON.parse(e.request.responseText);
    if (typeof response.fileName !== "undefined") {
      // let bytes = e.file.size;
      // if (bytes >= 1073741824) {
      //   bytes = (bytes / 1073741824).toFixed(2) + " GB";
      // } else if (bytes >= 1048576) {
      //   bytes = (bytes / 1048576).toFixed(2) + " MB";
      // } else if (bytes >= 1024) {
      //   bytes = (bytes / 1024).toFixed(2) + " KB";
      // } else if (bytes > 1) {
      //   bytes = bytes + " bytes";
      // } else if (bytes == 1) {
      //   bytes = bytes + " byte";
      // } else {
      //   bytes = "0 bytes";
      // }
      setProgressVisible(true);
      // setFileSize(bytes);
    }
    if (typeof response.fileName !== "undefined") {
      // let mainUrl = window.isLogistic
      //   ? props.typeUpload === "upload offers"
      //     ? logisticNormalProcessPath
      //     : logisticParentUploadProcessPath
      //   : props.selectedOption.processURL;
      axioscsvdata({
        method: "post",
        url: uploadUrl + props.selectedOption.processURL,
        data: {
          data: {
            parentDealerId: props.parentDealerId,
            loginDealerId: window.dealerId,
            fileName: response.fileName,
            upload_type: props.selectedOption.uploadType,
            type: props.isParentUpload ? "parent" : "normal",
          },
        },
        headers: {
          "Content-Type": "application/json;charset=utf-8",
        },
      })
        .then((resp) => {
          debugger;
          setIsProcessApiCompleted(true);
          if (typeof resp.data.error !== "undefined") {
            isCsvError(true);
            isMaxDealer(false);
            isShowHeaderMessage(true);

            // props.closeModal();

            if (
              // !window.isLogistic &&
              // props.isParentUpload &&
              // resp.data.error.message[0].includes("SELLER_SKU_ID")
              resp.data.error.code == 101
            ) {
              setSuccessAlertOpen(true);
              setAlertErrorMessage("Please Upload the file in Correct Format");
            } else if (resp.data.error.code == 150) {
              // errorMessage(resp.data.error.message);
              // setSpeialCharError(resp.data.error.message);
              setSuccessAlertOpen(true);
              setAlertErrorMessage(resp.data.error.message[0]);
            } else {
              errorMessage("The csv header does not contain stipulated Header");
            }

            setIsMangeApiCompleted(true);

            props.closeModal();
          } else if (typeof resp.data.success !== "undefined") {
            let dataLength = resp.data.data.length;
            setCurrentTime(resp.data.currentTime);
            downloadCsvData([...downloadCsvValue]);
            setCurrentProcessCount(0);
            setChunkCount(dataLength);
            setLimitReached(dataLength);
            setCsvData(resp.data.data);
            // bulkUpload(dataLength)
            // props.closeModal();
          }
        })
        .catch((err) => {
          // console.log("in catch of filter");
          // console.log(err);
          setIsMangeApiCompleted(true);
          setIsProcessApiCompleted(true);
        });
      applyOffer({
        dealerName: props.dealerName,
        dealerId: props.dealerid,
        fileType: "Upload File",
        upload: props.uploadType,
      });
    }
  };

  // const onProgress = (e) => {
  //   // let calculatedValue = (e.bytesLoaded / e.bytesTotal) * 100;
  //   // setProgressValue(calculatedValue);
  // };

  const isValidCSVHeaderFormat = () => {
    let headerDiscription = [];

    const headesFromCSV =
      uploadCSVArray.length > 0
        ? Object.keys(uploadCSVArray[0]).join().replace(/_/g, "").toUpperCase()
        : "";

    switch (props.selectedOption.key) {
      case "all":
        headerDiscription = Constants.downloadCsvHeader;
        break;
      case "price":
        headerDiscription = Constants.priceCSVHeader;
        break;
      case "status_inventory":
        headerDiscription = Constants.statusInventeryCSVHeader;
        break;
      case "installation_charges":
        headerDiscription = Constants.instalationChargesCSVHeader;
        break;
      case "active-logistic":
      case "parent-active-logistic":
        headerDiscription = Constants.downloadLogisticCsvHeader;
        break;
      default:
        break;
    }

    debugger

    const headerDiscriptionStrng = headerDiscription
      .join()
      .replace(/_/g, "")
      .toUpperCase();
    return headesFromCSV == headerDiscriptionStrng;
  };

  const isValidLimitCount = () => {
    if (props.isParentUpload && uploadCSVArray.length > 10000) {
      return false;
    } else if (uploadCSVArray.length > 70000) {
      return false;
    }
    return true;
  };

  const onClickUpload = () => {
    // alert('aaa')
    // props.onClickUpload()

    console.log("uploadCSVArray", uploadCSVArray);
    if (uploadedFileName) {
    } else {
      errorMessage("Please select file to upload");
    }

    if (!uploadedFileName) {
      errorMessage("Please select file to upload");
    } else if (!isValidLimitCount()) {
      const errorMsg = props.isParentUpload
        ? "Please upload file with less than 10000 SKUs to proceed"
        : "Please upload file with less than 70000 SKUs to proceed";

      setAlertErrorMessage(errorMsg);
      setSuccessAlertOpen(true);
    } else if (!isValidCSVHeaderFormat()) {
      setAlertErrorMessage("Please Upload the file in Correct Format");
      setSuccessAlertOpen(true);
    } else {
      fileUploader.current.instance.upload();
      props.onClickUpload();
      props.closeModal();
    }

    // uploadControl.upload();
  };

  return (
    <>
      <AlertDialog
        open={successAlertOpen}
        close={() => {
          setSuccessAlertOpen(false);
          setAlertErrorMessage("");
        }}
        errorMessage={alertErrorMessage}
      />
      <div className="bulk-upload">
        <Modal
          className="csv-modal-header"
          show={props.open}
          onHide={props.closeModal}
          size="md"
          aria-labelledby="contained-modal-title-vcenter"
          centered
          contentClassName="contentClass"
        >
          {/* <Modal.Header closeButton>Upload Offers</Modal.Header> */}
          {/* {uploadModal && ( */}
          <Modal.Body>
            {/* <label className="upload_label">
                {!progressVisible
                  ? "Drag and drop to upload your offer sheet"
                  : "your file is being uploaded . please wait"}
              </label> */}
            {/* <div className="flex-box"> */}
            {/* <div
                  id="dropzone-external-2"
                  className={`flex-box ${
                    isDropZoneActive
                      ? "dropzone-active"
                      : "dropzone-inactive"
                  }`}
                > */}
            {/* <img className="icon_cloud" src={cloudlogo} alt="cloud"></img> */}
            {/* </div> */}
            {/* <FileUploader
                  name="file"
                  accept="*"
                  uploadUrl={uploadPath}
                  uploadMode="instantly"
                  dialogTrigger="#dropzone-external-2"
                  dropZone="#dropzone-external-2"
                  maxFileSize={10000000}
                  onValueChanged={onDropZoneEnter}
                  visible={false}
                  onProgress={onProgress}
                  allowedFileExtensions={[".csv"]}
                  chunkSize={200000}
                  onUploaded={onUploaded}
                /> */}
            {/* </div> */}
            {/* {progressVisible && (
                <div>
                  <div className="Parentdiv">
                    <label className="upload_label2">{`uploading - ${progressValue}%`}</label>
                    <div className="bor_pro">
                      <ProgressBar
                        id="upload-progress"
                        min={0}
                        max={100}
                        width="30%"
                        showStatus={true}
                        visible={progressVisible}
                        value={progressValue}
                      ></ProgressBar>
                    </div>
                  </div>
                  <div className="disp_flex_upload">
                    <label className="upload_label">{uploadedFileName}</label>
                    <label className="upload_label">
                      {fileSize}
                    </label>
                  </div>
                </div>
              )} */}
            <div className="closeContainer">
              <img
                height="26px"
                src={xCircle}
                onClick={() => props.closeModal()}
              />
            </div>
            <div
              id="dropzone-external"
              className={`flex-box dropuploadzone ${
                isDropZoneActive ? "dropzone-active" : "dropzone-inactive"
              }`}
              onMouseLeave={() => setIsDropZoneActive(false)}
            >
              <img className="icon_cloud" src={cloudlogo} alt="cloud"></img>
              <div className="dragDropText">
                Drag and drop Files or Browse on your computer
              </div>
              <div className="uploadOffersBtn" onClick={onClickUpload}>
                Upload Offers
              </div>
              <div id="selectFileBtnId" className="selectFileOffersBtn">
                Select File
              </div>
              {uploadedFileName && (
                <div className="selectedFileNameContainer">
                  <div className="selectedFileName">{uploadedFileName}</div>
                  <div className="selectedFileSize">{fileSize}</div>
                </div>
              )}
              <div className="uploaderrorText">{message}</div>
            </div>
            {/* <div>Gunaaaa</div> */}

            <FileUploader
              name="file"
              ref={fileUploader}
              accept="*"
              selectButtonText="Upload Offers"
              uploadUrl={uploadPath}
              uploadMode="useButtons"
              // maxFileSize={10000000}
              dialogTrigger="#selectFileBtnId"
              dropZone="#dropzone-external"
              onValueChanged={onDropZoneEnter}
              visible={false}
              // uploadButtonText = "guna"
              onProgress={(e) =>
                setProgressValue((e.bytesLoaded / e.bytesTotal) * 100)
              }
              allowedFileExtensions={[".csv"]}
              chunkSize={200000}
              onUploaded={onUploaded}
              // onDropZoneEnter={() => setIsDropZoneActive(true)}
              // onDropZoneLeave={() => setIsDropZoneActive(false)}
              // onContentReady = {() => setIsDropZoneActive(false)}
            />
          </Modal.Body>
          {/* )} */}
        </Modal>
      </div>
    </>
  );
};

export default FileUploadLogistics;
