export const WebWorker = (worker) => {
  // const code = worker.toString();
  // const iife = `(${code})()`;
  // const blob = new window.Blob([iife]);
  // const fileURL = window.URL.createObjectURL(blob)
  // return new window.Worker(fileURL);


  let code = worker.toString();
  code = code.substring(code.indexOf("{") + 1, code.lastIndexOf("}"));
  code = new Blob([code], { type: 'application/javascript' });
  code = new Worker(URL.createObjectURL(code));
  return code;
};



