/*global event*/
/*eslint no-restricted-globals: ["error", "event"]*/

export const HandlePricemanagementPHPApi = () => {

  onmessageerror = (e) => {
    console.log("Worker: Message received from main script onmessageerror", e);
  };
  addEventListener("message", function (e) {
    console.log(
      "Worker: Message received from main script addEventListener",
      e.data
    );
    var requestData = {
      // requestData.csv_data = JSON.stringify(data);
      targetName: e.data.csvData.fileName,
      // requestData.isLastData = e.data.isLastData;
      currentTime: e.data.currentTime,
      isFirstData: e.data.isFirstData,
      isFailure: e.data.isFailure,
      isSuccess: e.data.isSuccess,
      loginDealerId: e.data.dealerId,
      parentDealerId: e.data.parentDealerId,
      upload_type: e.data.selectedOption.uploadType,
      chunk_size: e.data.csvData.chunk_size,
      api_count: e.data.currentIndex,
      fileName: e.data.csvData.fileName,
      original_filename: e.data.filenname
    };

    const url = e.data.uploadUrl + e.data.selectedOption.priceManagementURL;

    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestData),
    };
    const response = fetch(url, requestOptions)
      .then((response) => response.json())
      .then((data) =>{
        this.postMessage(data)

      } ).catch( e => this.postMessage(e)

      );
   ;

  });
};
