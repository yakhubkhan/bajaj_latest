import React, { useEffect } from "react";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import "./skeletonLoader.css";
import checkboximg from "../../images/checkboximg.svg";

const AgGridLoader = (props) => {
  const rowData = [1, 2, 3, 4]; // by default 4 row displaying

  useEffect(() => {
    document.body.classList.add("stop-scrolling");
  });
  useEffect(() => () => {
    document.body.classList.remove("stop-scrolling");
  });

  return (
    <div>
      {props.loading && (
        <div className="ag-grid-header">
          <img className="ag-grid-img" src={checkboximg} alt="checkbox_img" />

          <div className="ag-grid-h1">All</div>
          <div className="ag-grid-h2">SKU</div>
          <div className="ag-grid-h3">Model ID</div>
          <div className="ag-grid-h4">OEM Model Code</div>
          <div className="ag-grid-h5">MRP/MOP</div>
          <div className="ag-grid-h6">Stock</div>
          <div className="ag-grid-h7">Price</div>
          <div className="ag-grid-h8">Status</div>
          <div className="ag-grid-h9">Seller SKU ID</div>
          <div className="ag-grid-h10">Action</div>
        </div>
      )}
      {!props.loading && (
        <div className="card">
          <Skeleton className="ag-grid_all_loader" />
          <Skeleton className="ag-grid_sku_loader" />

          <Skeleton className="ag-grid_modelid_loader" />
          <Skeleton
            className="ag-grid_oem_loader"
            width="150px"
            height="20px"
          />
          <Skeleton
            className="ag-grid_mrp_loader"
            width="100px"
            height="20px"
          />
          <Skeleton
            className="ag-grid_stock_loader"
            width="50px"
            height="20px"
          />
          <Skeleton
            className="ag-grid_price_loader"
            width="50px"
            height="20px"
          />
          <Skeleton
            className="ag-grid_status_loader"
            width="50px"
            height="20px"
          />
          <Skeleton
            className="ag-grid_seller_loader"
            width="100px"
            height="20px"
          />
          <Skeleton
            className="ag-grid_action_loader"
            width="50px"
            height="20px"
          />
        </div>
      )}
      {rowData.map((item, index) => (
        <div style={{ marginTop: 10 }} key = {"loader"+index}>
          <div className="card">
            <Skeleton className="all_loader" />
            <Skeleton className="sku_loader" />
            <Skeleton className="modelid_loader" />
            <Skeleton className="oem_loader" />
            <Skeleton className="mrp_loader" />
            <Skeleton className="stock_loader" />
            <Skeleton className="price_loader" />
            <Skeleton className="status_loader" />
            <Skeleton className="seller_loader" />
            <Skeleton className="action_loader" />
          </div>
        </div>
      ))}
    </div>
  );
};
export default AgGridLoader;
