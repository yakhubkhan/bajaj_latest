import React from "react";
import Skeleton from "react-loading-skeleton";

const TabsLoader = (props) => {
  return (
    <div className="tabs_Loader">
      <span className="span_">
        <Skeleton className="newlist_skeleton" />
      </span>
      <span className="span_">
        <Skeleton className="activelist_skeleton" />
      </span>
      <span className="span_">
        <Skeleton className="inactive_skeleton" />
      </span>
      <span className="span_">
        <Skeleton className="pricealert_skeleton" />
      </span>
    </div>
  );
};

export default TabsLoader;
