import React from "react";
import Skeleton from "react-loading-skeleton";

const SettingsLoader = (props) => {
  return (
    <div>
      <div className="contleft centerLoader">
        <div className="card">
          <Skeleton className="column_skeleton" />
          <Skeleton className="sortby_skeleton" />
          <Skeleton className="action_select_skeleton" />
        </div>
      </div>
    </div>
  );
};

export default SettingsLoader;
