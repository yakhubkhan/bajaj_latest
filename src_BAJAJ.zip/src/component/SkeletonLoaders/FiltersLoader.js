import React from "react";
import Skeleton from "react-loading-skeleton";

const FiltersLoader = (props) => {
  return (
    <div className="filerLoaderContainer">
      <div className="filterLoaderLeft">
        <Skeleton className="category_skeleton" />
        <Skeleton className="varients_skeleton" />
        <Skeleton className="brand_skeleton" />
        <Skeleton className="dealerid_skeleton" />
      </div>
      <div className="filterLoaderLeft2">
        <Skeleton className="state_skeleton" />
        <Skeleton className="city_skeleton" />
        <Skeleton className="resetall_skeleton" />
      </div>
      <div className="filterLoaderLeft3">
        <Skeleton className="requestdownload_skeleton" />
        <Skeleton className="downloadready_skeleton" />
        <Skeleton className="dealerwise_skeleton" />
        <Skeleton className="citywise_skeleton" />
      </div>
    </div>
  );
};

export default FiltersLoader;
