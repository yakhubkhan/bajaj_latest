import React from "react";
import Skeleton from "react-loading-skeleton";

const HeaderLoader = (props) => {
  return (
    <div>
      <div className="main_headerSkeleton disp_flex headerLoader">
        <div className="disp_flex headerLeftLoader">
          <Skeleton className="bajajlogo_skeleton" />
          <Skeleton className="search_skeleton" />
          <Skeleton className="customer_img_skeleton" />
          <Skeleton className="customer_name_skeleton" />
        </div>
      </div>
      <div className="contleft centerLoader">
        <div className="titleLoaderContainer">
          <Skeleton className="level2header_skeleton" />
        </div>
      </div>
    </div>
  );
};

export default HeaderLoader;
