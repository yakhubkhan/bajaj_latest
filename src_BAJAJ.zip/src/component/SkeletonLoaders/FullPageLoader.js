import React from "react";
import FiltersLoader from "./FiltersLoader";
import AgGridLoader from "./AgGridLoader";
import TabsLoader from "./TabsLoader";
import SettingsLoader from "./SettingsLoader";
import HeaderLoader from "./HeaderLoader";

const FullPageLoader = (props) => {
  return (
    <div className="novertical">
      <HeaderLoader />

      <TabsLoader />

      <FiltersLoader />

      <SettingsLoader />

      <AgGridLoader isHeaderLoading={true} />
    </div>
  );
};

export default FullPageLoader;
