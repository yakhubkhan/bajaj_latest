/* eslint-disable */
import React from "react";
import crossIcon from "../../images/cross_audit.svg"


const AuditLogModalBody = (props) => {
  const { massRespData, auditData, skuKeys,selectedSku } = props;
  return (
    <div
      style={{
        width: "25%",
        marginTop: "10px",
        border: "2px solid lightgrey",
        overflow: "scroll",
        borderRadius: "11px",
      }}
    >
      <div
        id="myTab"
        role="tablist"
        style={{ listStyle: "none", marginTop: "10px" }}
      >
        {skuKeys.map((rowdta, indx) => {
          return (
            <div
            key = {"auditLogModalBody"+indx}
              className={
                // rowdta &&
                // rowdta[0] == (auditData && auditData[0] && auditData[0].sku)
                //   ? "matched auditLogCell"
                //   : "auditLogCell"

                  rowdta == selectedSku ? "matched auditLogCell" : "auditLogCell"


              }
              onClick={() => props.updateGridData(rowdta, indx)}
              style={{
                // border: "1px solid lightgrey",
                marginRight: "10px",
                marginLeft: "10px",
                marginBottom: "10px",
                borderRadius: "5px",
                height: "80px",
              }}
            >
              <a
                className={
                  indx == 0 ? "nav-link active skutab" : "nav-link skutab"
                }
                id="home"
                key={indx}
                data-toggle="tab"
                // href={rowdta[0]}
              >
                <div className="d-flex">
                  <span
                    className="auditskutab"
                    role="tab"
                    aria-controls="home"
                    aria-selected="true"
                  >
                    {rowdta}
                  </span>
                  <div style={{ marginTop: "-15px" }}>
                    <span
                      style={{ cursor: "pointer" }}
                      className="crossmrk"
                      onClick={(event) => {
                        props.removeRow(rowdta, indx)
                        event.stopPropagation()
                      }
              }
                    >
                      &times;
                    </span>
                  </div>
                </div>
              </a>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AuditLogModalBody;
