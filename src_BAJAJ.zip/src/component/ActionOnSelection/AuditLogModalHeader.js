/* eslint-disable */
import React from "react";
import dateFormat  from "dateformat";
import icon_DangerCircle from "../../images/icon_DangerCircle.svg";

const AuditLogModalHeader = (props) => {
  const { skuKeys, auditData, massRespData, selectedList, rightSideList } =
    props;
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center" }}>
        <span className="audit_header">Created By: </span>
        <span className="audit_header_log_time">
          {rightSideList.length > 0 ? rightSideList[0].sid : ""}
        </span>
        <img className="ellipse-17" src={icon_DangerCircle} alt="logo"></img>
      </div>

      <div style={{ display: "flex", alignItems: "center" }}>
        <span className="audit_header">Created On: </span>
        <span className="audit_header_log_time">
          {dateFormat(
            rightSideList.length > 0 ? rightSideList[0].added_at : "",

            "dd-mm-yyyy h:MM TT"
          )}
        </span>
        <img className="ellipse-17" src={icon_DangerCircle} alt="logo"></img>
      </div>
    </div>
  );
};

export default AuditLogModalHeader;
