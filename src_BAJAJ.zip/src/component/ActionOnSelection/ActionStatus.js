/* eslint-disable */
import React, { useEffect, useState } from "react";

const ActionStatus = (props) => {
  const [status, SetStatus] = useState("");
  useEffect(() => {
    if (
      (props && props.data.status === null) ||
      props.data.status === "" ||
      props.data.status === 0
    ) {
      SetStatus("new");
    } else if (props.data.status === 1) {
      SetStatus("active");
    } else if (props.data.status === 2) {
      SetStatus("inactive");
    }
  });

  return (
    <div>
      <label>{status}</label>
    </div>
  );
};
export default ActionStatus;
