/* eslint-disable */
import React, { useState, useEffect } from "react";
import "./ActionOnSelected.css";
import "./EditOnSelection.css";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";
import "../Grid/OfferesGrid.css";
import {
  dropdownOptions,
  gridColumns,
  framecomponents,
} from "../../utils/ActionOnEditGridColumns";
import AlertDialog from "../Grid/Alert";

const EditOnSelection = (props) => {
  const [drpdwnErr, setDrpdwnErr] = useState(false);
  const [isalertDisplay, setIsalertDisplay] = useState(false);
  const [actnStatus, setActnStatus] = useState(props.actnStatus);
  const [actnMsg, setActnMsg] = useState(props.actnMsg);
  const [actnonslctd] = useState(dropdownOptions());
  const [selectedsku, setSelectedsku] = useState(props.selectedsku);

  const [actnresp, setActnresp] = useState(props.actnresp);
  const [gridcols] = useState(gridColumns());
  const [, setActionErr] = useState("");
  const [, setSelectedTab] = useState("");

  const [selectedActnName, setSelectedActnName] = useState("");
  const [selectedActn, setSelectedActn] = useState("");
  const [gridApi, setGridApi] = useState(undefined);

  const [successAlertOpen, setSuccessAlertOpen] = useState(false);
  const [alertErrorMessage, setAlertErrorMessage] = useState("");

  useEffect(() => {
    document
      .getElementById("editActionModal")
      .parentElement.addEventListener("scroll", function (event) {
        document.getElementById("actionEditDropDown").classList.remove("show");
        document
          .getElementById("actionEditDropDownMenu")
          .classList.remove("show");
      });
  }, []);

  useEffect(() => {
    setActnStatus(props.actnStatus);
    setActnMsg(props.actnMsg);
    setActnresp(props.actnresp);
    if (gridApi) {
      gridApi.redrawRows();
    }
  }, [props.actnMsg]);

  useEffect(() => {
    if (selectedsku && gridApi) {
      gridApi.redrawRows();
    }
  }, [selectedsku]);

  useEffect(() => {
    if (props.selectedRows.length == 0) {
      setIsalertDisplay(true);
    }
  }, [props.selectedRows]);

  const getUpdateddata = (status, msg, sku, resp, selectedTab) => {
    setActionErr(false);
    if (status == "success") {
      props.onUpdateCallDashBoardApi();
      setActnStatus(status);
      setActnMsg(msg);
      setSelectedsku(sku);
      setActnresp(resp);
      setSelectedTab(selectedTab);
    } else {
      setActnStatus(status);
      setActnMsg(msg);
      setSelectedsku(sku);
      setActnresp(resp);
    }
    gridApi.redrawRows();
  };

  const onGridReady = (params) => {
    setGridApi(params.api);
    params.api.sizeColumnsToFit();
    params.api.selectAll();
    params.api.setDomLayout("autoHeight");
    document.querySelector("#myGrid").style.height = "";
  };

  const getSelectedAction = (actn) => {
    setSelectedActnName(actn.name);
    setSelectedActn(actn.value);
    props.getSelectedAction(actn.value);
  };

  const callMassOfferActn = (actnonselection) => {
    if (!actnonselection) {
      setDrpdwnErr(true);
      return;
    }
    setDrpdwnErr(false);
    document.getElementsByTagName("body")[0].classList.add("loading");
    props.callMassOfferActn(actnonselection);
    setSelectedActnName(undefined);
    setSelectedActn(undefined);
    setSelectedsku([]);
    props.resetPrice();
  };

  return (
    <div>
      <AlertDialog
        open={successAlertOpen}
        close={() => setSuccessAlertOpen(false)}
        errorMessage={alertErrorMessage}
      />
      <div className="containerHeader">
        <div className="actiondrpdwnContainer">
          <div id="actionEditDropDown" className="dropdown">
            <button
              className="actnslctEdit actnslctEditPopup"
              type="button"
              id="dropdownMenuButton"
              data-toggle="dropdown"
              aria-haspopup="true"
              aria-expanded="false"
            >
              {selectedActnName ? selectedActnName : "Select action"}
            </button>
            <div className="downword"></div>
            <div className="upword"></div>
            <div
              id="actionEditDropDownMenu"
              className="dropdown-menu  drpMenuEdit"
              aria-labelledby="dropdownMenuButton"
            >
              {actnonslctd.map((optn, indx) => {
                return (
                  <div
                    key={indx}
                    className="dropdown-item slctoptn slctoptnEdit"
                    value={optn.value}
                    onClick={() => getSelectedAction(optn)}
                  >
                    {optn.name}
                  </div>
                );
              })}
            </div>
          </div>

          <button
            className="apply applyBtn applrBtnEdit"
            onClick={() => callMassOfferActn(selectedActn)}
          >
            Apply
          </button>
        </div>

        <div>
          <div
            className="saveAllBtn "
            onClick={() => {
              gridApi.stopEditing();
              props.resetPrice();
              callMassOfferActn("saveAll");
            }}
          >
            Save All
          </div>
        </div>
      </div>
      <p className="drpdwnErrorMsg">
        {drpdwnErr ? "Please select option to apply" : ""}
      </p>

      <div className="ag-theme-alpine editGrid">
        <AgGridReact
          singleClickEdit={true}
          columnDefs={gridcols}
          rowData={props.selectedRows}
          defaultColDef={{
            sortable: true,
            resizable: true,
          }}
          open={(errorMessage) => {
            setSuccessAlertOpen(true);
            setAlertErrorMessage(errorMessage);
          }}
          onGridReady={onGridReady}
          onSelectionChanged={(event) => event.api.selectAll()}
          rowSelection={"multiple"}
          undoRedoCellEditing={true}
          props={{
            ...props,
            ...{ getUpdateddata: getUpdateddata },
          }}
          state={{
            actnMsg,
            selectedsku,
            actnresp,
            actnStatus,
          }}
          suppressRowClickSelection={true}
          getRowHeight={() => 95}
          getRowStyle={(params) => {
            return { backgroundColor: "#EBF3FF !important" };
          }}
          suppressDragLeaveHidesColumns={true}
          frameworkComponents={framecomponents()}
        ></AgGridReact>
        {isalertDisplay && (
          <div className="successAlert">
            <div>
              Status updated successfully. <br />
              Product moved to respective tab.
            </div>
            <div
              className="alertBtn"
              onClick={() => {
                setIsalertDisplay(false);
                props.closeModal();
              }}
            >
              Ok
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EditOnSelection;
