import React from "react";
import { AgGridReact } from "ag-grid-react";
import ActionStatus from "./ActionStatus";
import moment from "moment";
import icon_DangerCircle from "../../images/icon_DangerCircle.svg";

const AuditLogModalPopup = (props) => {
  let frameworkComponents = {
    ActionStatus: ActionStatus,
  };
  let defaultColDef = {
    sortable: true,
    resizable: true,
  };
  let gridcols = [
    {
      headerName: "SKU",
      field: "sku",
      cellClass: "no-border",
      resizable: true,
      width: 150,
      // minWidth: 150,
      // maxWidth: 150,
      suppressSizeToFit: true,
      cellStyle: {
        "text-overflow": "clip",
        "word-wrap": "break-word",
        overflow: "hidden",
        "white-space": "normal",
        "user-select": "text",
        "border-bottom": "2px solid #e9ecef !important",
        "line-height": "1.5",
        borderRight: "1px solid lightgrey !important" ,
        color:"#231f20",
        "display": "block !important",
        "padding": "7px 11px 30px 15px !important"
      },
    },
    {
      headerName: "Dealer ID",
      field: "sid",
      width: 110,
      minWidth: 110,
      maxWidth: 110,
      cellStyle: {
        "text-align": "center",
        "border-bottom": "2px solid #e9ecef !important",
        borderRight: "1px solid lightgrey !important",
        color: "#8d8882",
      },
    },
    {
      headerName: "Status",
      field: "prod_status",
      cellRenderer: "ActionStatus",
      width: 100,
      // minWidth: 100,
      // maxWidth: 100,
      cellStyle: {
        "text-align": "center",
        "border-bottom": "2px solid #e9ecef !important",
        borderRight: "1px solid lightgrey !important",
        color: "#1a1004",
      },
    },
    {
      headerName: "Offer Price",
      field: "price_offer",
      width: 120,
      // minWidth: 120,
      // maxWidth: 120,
      cellStyle: {
        "text-align": "center",
        "border-bottom": "2px solid #e9ecef !important",
        borderRight: "1px solid lightgrey !important",
        color: "#8d8882",
      },
    },
    {
      headerName: "Inventory",
      field: "inventory",
      width: 110,
      // minWidth: 110,
      // maxWidth: 110,
      cellStyle: {
        "text-align": "center",
        "border-bottom": "2px solid #e9ecef !important",
        borderRight: "1px solid lightgrey !important",
        color: "#1a1004",
      },
    },
    {
      headerName: "Service Type",
      field: "service_type",
      width: 150,
      cellStyle: {
        "text-align": "center",
        "border-bottom": "2px solid #e9ecef !important",
        borderRight: "1px solid lightgrey !important",
        color: "#1a1004",
      },
    },
    {
      headerName: "TAT",
      field: "tat",
      width: 110,
      cellStyle: {
        "text-align": "center",
        "border-bottom": "2px solid #e9ecef !important",
        borderRight: "1px solid lightgrey !important",
        color: "#1a1004",
      },
    },
    {
      headerName: "Updated on",
      field: "updated_so_at",
      headerComponentParams: {
        template: `<div class="updated_flex ag-header-cell-text">Updated On<div  data-toggle="tooltip" data-placement="left" title="User who updated the SKU"><img class="ellipse-18" src=${icon_DangerCircle} alt="logo"/></div>`,
      },
      cellRenderer: (data) => {
        return moment(data.data.updated_so_at).format("DD-MM-YYYY HH:mm A");
      },
      width: 150,
      // minWidth: 150,
      // maxWidth: 150,
      cellStyle: {
        "text-overflow": "clip",
        overflow: "visible",
        "white-space": "normal",
        "padding-left": "14",
        textAlign: "center",
        "border-bottom": "2px solid #e9ecef !important",
        borderRight: "1px solid lightgrey !important",
        color: "#8d8882",
      },
    },
    {
      headerName: "Updated by",
      field: "updated_so_by",
      headerComponentParams: {
        template: `<div class="updated_flex ag-header-cell-text">Updated by<div data-toggle="tooltip" data-placement="left" title="User who updated the SKU"><img class="ellipse-18" src=${icon_DangerCircle} alt="logo"/></div>`,
      },
      width: 140,
      // minWidth: 140,
      // maxWidth: 140,
      cellStyle: {
        "text-align": "center",
        "border-bottom": "2px solid #e9ecef !important",
        borderRight: "1px solid lightgrey !important",
        color: "#8d8882",
      },
    },
    {
      headerName: "Updated medium",
      field: "action",
      width: 180,
      // minWidth: 180,
      // maxWidth: 180,

      cellStyle: {
        "text-align": "center",
        "border-bottom": "2px solid #e9ecef !important",
        color: "#1a1004",
      },
    },
  ];

  const getRowHeight = (params) => {
    return 78;
  };

  return (
    <div className="audit_popup_main">
      <div className="tab-content" id="myTabContent">
        <div
          className="tab-pane fade show active"
          role="tabpanel"
          aria-labelledby="home-tab"
        >
          <div className="ag-theme-alpine auditlogGridContainer body-container">
            <AgGridReact
              columnDefs={gridcols}
              rowData={props.rightSideList}
              defaultColDef={defaultColDef}
              onGridReady={props.onGridReady}
              onSelectionChanged={props.onSelectionChanged}
              suppressRowClickSelection={true}
              getRowHeight={getRowHeight}
              suppressDragLeaveHidesColumns={true}
              frameworkComponents={frameworkComponents}
              suppressRowHoverHighlight={true}
            ></AgGridReact>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuditLogModalPopup;
