/* eslint-disable */
import React, { useEffect, useState, useRef } from "react";
import arrowDown from "../../images/blueArrow.svg";
import arrowDownGray from "../../images/arrowDownGray.png";

const ActionSelectionDropDown = (props) => {
  let container = useRef(null);
  const [status, setStatus] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [showDropdown, setDropdown] = useState(false);

  /* to open dropdown */
  const loadDropDown = (val) => {
    if (props.selectedRows != "") {
      if (!isOpen) setDropdown(val);
    }
  };

  /* get call on Apply cta */
  const HandleApply = () => {
    setDropdown(false);
    props.callMassOfferActn(props.selectedActn);
    props.resetSaveActionResp();
  };

  useEffect(() => {
    window.addEventListener("mousedown", handleClickOutside);
    return () => {
      window.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  /* to close dropdown on click on outside */
  const handleClickOutside = (event) => {
    if (container.current && !container.current.contains(event.target)) {
      setIsOpen(true);
      setDropdown(false);
    } else {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    if (props.selectedRows != "") {
      setStatus(true);
    } else {
      setStatus(false);
    }
  }, [props]);

  return (
    <>
      <div>
        <button
          type="button"
          className={!status ? "slctactn-grey" : "slctactn"}
          // title={
          //   !status
          //     ? ""
          //     : "Please select SKUs using Category or Brand filter first"
          // }
          onClick={() => loadDropDown(!showDropdown ? true : false)}
        >
          <span
            className={props.status ? "div_row filterLabel" : "filterLabel"}
          >
            Action on Selected
          </span>
          <span>
            {status ? (
              <img
                alt="arrowDown"
                src={arrowDown}
                height="16px"
                className={
                  "download_icon" + (showDropdown ? " rotateIcon" : "")
                }
              />
            ) : (
              <img
                alt="arrowDownGray"
                src={arrowDownGray}
                height="16px"
                className={
                  "download_icon" + (showDropdown ? " rotateIcon" : "")
                }
              />
            )}
          </span>
        </button>
        {showDropdown && (
          <div
            className={
              window.is2wDealer ? "action-dropdown-2w" : "action-dropdown"
            }
            ref={container}
          >
            {props.actnonslctd.map((optn, indx) => {
              return (
                <div
                  className="form-check radio-header"
                  onClick={(e) => props.getSelectedAction(optn.value)}
                  key = {optn.value}
                >
                  <input
                    className="form-check-input radio-style radio-size"
                    value={optn.value}
                    type="radio"
                    name="flexRadioDefault"
                    id={indx}
                    checked={props.selectedActn == optn.value}
                    onChange={(e) => props.getSelectedAction(optn.value)}
                  />
                  <label
                    className="form-check-label selected-options"
                    htmlFor="flexRadioDefault2"
                  >
                    {optn.name}
                  </label>
                </div>
              );
            })}
            <button
              className={
                status && props.selectedActn != ""
                  ? "actionOnSelectedApply"
                  : "initalSearchMain"
              }
              onClick={() => (props.selectedActn != "" ? HandleApply() : "")}
            >
              Apply
            </button>
          </div>
        )}
      </div>
    </>
  );
};

export default ActionSelectionDropDown;
