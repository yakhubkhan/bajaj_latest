import React from "react";
import { AgGridReact } from "ag-grid-react";
// import imgComponent from "./Image";
import ActionStatus from "./ActionStatus";
import moment from "moment";

const AuditLogModalPopup2W = (props) => {
  let frameworkComponents = {
    // imgComponent: imgComponent,
    ActionStatus: ActionStatus,
  };
  let defaultColDef = {
    sortable: true,
    resizable: true,
  };
  let gridcols = [
    {
      headerName: "SKU",
      field: "sku",
      cellClass: "no-border",
      resizable: true,
      width: 260,
      minWidth: 260,
      maxWidth: 260,
      cellStyle: {
        "text-overflow": "clip",
        "word-wrap": "break-word",
        overflow: "hidden",
        "white-space": "normal",
        "user-select": "text",
        "border-bottom": "2px solid #e9ecef !important",
        "line-height": "1.5",
        display: "block !important",
        borderRight: "1px solid lightgrey !important",
        color: "#231f20",
      },
    },
    {
      headerName: "Status",
      field: "prod_status",
      cellRenderer: "ActionStatus",
      width: 180,
      minWidth: 180,
      maxWidth: 180,
      cellStyle: {
        "text-align": "center",
        "border-bottom": "2px solid #e9ecef !important",
        borderRight: "1px solid lightgrey !important",
        color: "#1a1004",
      },
    },
    {
      headerName: "On Road Price",
      field: "ORP",
      width: 170,
      minWidth: 170,
      maxWidth: 170,
      cellStyle: {
        "text-align": "center",
        "border-bottom": "2px solid #e9ecef !important",
        borderRight: "1px solid lightgrey !important",
        color: "#8d8882",
      },
    },
    {
      headerName: "Inventory",
      field: "inventory",
      width: 170,
      minWidth: 170,
      maxWidth: 170,
      cellStyle: {
        "text-align": "center",
        "border-bottom": "2px solid #e9ecef !important",
        borderRight: "1px solid lightgrey !important",
        color: "#1a1004",
      },
    },
    {
      headerName: "Updated on",
      field: "updated_so_at",
      headerComponentParams: {
        template:
          '<div class="updated_flex ag-header-cell-text">Updated on<div class="ellipse-17" data-toggle="tooltip" data-placement="left" title="Time when the SKU was updated"><h6 class="ellipse">!</h6></div></div>',
      },
      cellRenderer: (data) => {
        return moment(data.data.updated_so_at).format("DD-MM-YYYY HH:mm A");
      },
      width: 200,
      minWidth: 200,
      maxWidth: 200,
      cellStyle: {
        "text-overflow": "clip",
        overflow: "visible",
        "white-space": "normal",
        "padding-left": "14",
        textAlign: "center",
        "border-bottom": "2px solid #e9ecef !important",
        borderRight: "1px solid lightgrey !important",
        color: "#8d8882",
      },
    },
    {
      headerName: "Updated by",
      field: "updated_so_by",
      headerComponentParams: {
        template:
          '<div class="updated_flex ag-header-cell-text">Updated by<div class="ellipse-17" data-toggle="tooltip" data-placement="left" title="User who updated the SKU"><h6 class="ellipse">!</h6></div></div>',
      },
      width: 150,
      minWidth: 150,
      maxWidth: 150,
      cellStyle: {
        "text-align": "center",
        "border-bottom": "2px solid #e9ecef !important",
        borderRight: "1px solid lightgrey !important",
        color: "#8d8882",
      },
    },
  ];

  const getRowHeight = (params) => {
    return 78;
  };

  return (
    <div style={{ width: "75%" }}>
      <div className="tab-content" id="myTabContent">
        <div
          className="tab-pane fade show active"
          role="tabpanel"
          aria-labelledby="home-tab"
        >
          <div
            className="ag-theme-alpine auditlogGridContainer"
            style={{
              height: "calc(80vh - 90px)",
              width: "100%",
              paddingLeft: "24px",
              paddingRight: "24px",
              paddingTop: "1%",
            }}
          >
            <AgGridReact
              columnDefs={gridcols}
              rowData={props.rightSideList}
              defaultColDef={defaultColDef}
              onGridReady={props.onGridReady}
              onSelectionChanged={props.onSelectionChanged}
              suppressRowClickSelection={true}
              getRowHeight={getRowHeight}
              suppressDragLeaveHidesColumns={true}
              frameworkComponents={frameworkComponents}
            ></AgGridReact>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuditLogModalPopup2W;
