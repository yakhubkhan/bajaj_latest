/* eslint-disable */
import React, { useState, useEffect } from "react";
import Modal from "react-bootstrap/Modal";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";
import "./ActionOnSelected.css";
import AuditLogModalPopup from "./AuditLogModalPopup";
import AuditLogModalPopup2W from "./AuditLogModalPopup2W";
import AuditLogModalBody from "./AuditLogModalBody";
import AuditLogModalHeader from "./AuditLogModalHeader";
import AuditLogModalHeader2w from "./AuditLogModalHeader2w";
import ActionSelectionDropDown from "./ActionSelectionDropDown";
import useFetch from "../../api/useFetch";
import EditOnSelection from "./EditOnSelection";
import { auditLogApply } from "../../gtm";
import xcircle from "../../images/x-circle.svg";
import AlertDialog from "../Grid/Alert";
import * as Constant from "../../utils/Constant";
import { getAuditLogApiURL } from "../../utils/apiURLs";

const ActionOnSelection = (props) => {
  const [selectedActn, setSelectedActn] = useState("");
  const [auditData, setAuditData] = useState([]);
  const [open, setOpen] = useState(false);
  // const [selectedList, setSelectedList] = useState(0);
  // const [skuKeys, setSkuKeys] = useState([]);
  const [massRespData, setMassRespData] = useState([]);

  const [skuKeys, setSkuKeys] = useState([]);
  const [selectedSku, setSelectedSku] = useState("");
  const [massOfferActionResp, setMassOfferActionResp] = useState([]);

  const [actionMsg, setActionMsg] = useState("");
  const [actnstatus, setActnstatus] = useState("");
  const [applyErrMsg, setApplyErrMsg] = useState("");
  const [showErr, setShowErr] = useState("");
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [alertErrorMessage, setAlertErrorMessage] = useState("");
  const [successAlertOpen, setSuccessAlertOpen] = useState(false);

  let gridApi = undefined;
  let offersArr = [];
  let skuarr = [];

  useEffect(() => {
    if (props.actionErr) {
      setShowErr(props.actionErr);
    }
  }, [props]);

  const getSelectedAction = (value) => {
    setSelectedActn(value);
  };

  const [isvalidaMassResp, fetchRequestAuditLog, callApi] = useFetch(
    "POST",
    "/massofferaction",
    null
  );

  const [saveAllResp, saveAllApi] = useFetch("POST", "/masssaveofferaction", {
    action: "activate",
    pm_key: props.md5value,
    data: {
      dealerId: props.dealerid,
      parentDealerId: props.parentDlerId,
      offers: offersArr,
    },
  });

  useEffect(() => {
    if (isvalidaMassResp.data) {
      callUserApi(isvalidaMassResp.data);
      props.startSkeletonLoader(false);
    }
  }, [isvalidaMassResp.data]);

  useEffect(() => {
    if (saveAllResp.data) {
      callUserApi(saveAllResp.data);
      props.startSkeletonLoader(false);
    }
  }, [saveAllResp.data]);

  /*  call offer api based on Action on selection dropdown selection on Apply cta click.*/
  const callUserApi = (offerData) => {
    props.startSkeletonLoader(true);
    props.setIsGetOffersListLoading(true);
    let rowSelected = props.selectedRow;
    if (selectedActn === Constant.priceManagement.auditlog) {
      setMassRespData(Object.entries(offerData.payload));
      let respdata = offerData.payload[rowSelected[0].sku];
      setAuditData(respdata);

      const skus = Object.keys(offerData.payload);
      setSkuKeys(skus);
      setSelectedSku(skus[0]);
      setMassOfferActionResp(offerData.payload);

      setOpen(true);
      setApplyErrMsg("");
      props.startSkeletonLoader(false);
      props.setIsGetOffersListLoading(false);
      setSelectedActn("");
    } else {
      if (offerData.errorBean && offerData.errorBean[0][0].errorCode !== 10) {
        props.selectedActionResp(
          "failedActionOnEdit",
          offerData.errorBean[0][0].errorMessage,
          skuarr,
          offerData.errorBean
        );
      } else {
        if (offerData.errorBean) {
          props.selectedActionResp(
            "success",
            offerData.errorBean[0][0].errorMessage,
            skuarr,
            offerData.errorBean
          );
          setApplyErrMsg("");
          setSelectedActn("");
        }
      }
    }
    stopLoader();
  };

  const stopLoader = () => {
    document.getElementsByTagName("body")[0].classList.remove("loading");
  };

  /*  call offer api based on Action on selection dropdown selection on Save cta click.*/
  const callMassOfferActn = (actnonselection) => {
    let rowSelected = props.selectedRow;
    let action = Constant.actnonslctd.filter((item) => {
      return item.value == actnonselection;
    });
    console.log(">>>>>>>>", actnonselection, action);
    if (rowSelected.length === 0) {
      stopLoader();
      setApplyErrMsg("Please select at least one SKU to update");
      setShowErr(true);
    } else if (actnonselection === "") {
      stopLoader();
      setApplyErrMsg("Please select option to apply");
      setShowErr(true);
    } else if (actnonselection === Constant.priceManagement.edit) {
      document.getElementsByTagName("body")[0].classList.remove("loading");
      if (
        props.isParentDealer &&
        props.selectedTab === Constant.priceManagement.new &&
        props.childIds.length === 0
      ) {
        setApplyErrMsg("Please select dealer id to continue editing.");
        setShowErr(true);
      } else {
        setIsEditModalOpen(true);
        setShowErr(false);
        setSelectedActn("");
        auditLogApply({
          dealerId: props.dealerid,
          dealerName: props.dealerName,
          selectionType: action[0].name,
          pageType: "Price Management",
          dealerType: window.dealer_type,
        });
      }
    } else {
      setShowErr(false);
      auditLogApply({
        dealerId: props.dealerid,
        dealerName: props.dealerName,
        selectionType: action[0].name,
        pageType: "Price Management",
        dealerType: window.dealer_type,
      });
      let rowSelected = props.selectedRow;
      rowSelected.map((val, indx) => {
        let obj = {};
        let skuobj = {};
        obj["id"] = window.is2wDealer ? val.sku : val.id;
        obj["sku"] = val.sku;
        obj["dealerId"] = val.dealer_id;
        obj["modelId"] = val.model_id;
        if (actnonselection === "saveAll") {
          obj["inventory"] = rowSelected[indx].inventory;
          obj["prod_status"] = val.prod_status;
          obj["offerPrice"] = val.offer_price;
          obj["seller_sku_data"] = val.seller_sku_id;
          // obj["modelId"] = val.model_id;
        }
        offersArr.push(obj);
        skuobj["sku"] = val.sku;
        skuarr.push(skuobj);
        return true;
      });
      if (actnonselection === "saveAll") {
        saveAllApi();
      } else {
        const payload = {
          action: selectedActn,
          pm_key: props.md5value,
          data: {
            dealerId: props.dealerid,
            parentDealerId: props.parentDlerId,
            offers: offersArr,
          },
          dealer_type:window.dealer_type
        };
        fetchRequestAuditLog(getAuditLogApiURL(), payload);
      }
    }
  };
  /* To close modal Audit log modal*/
  const closeModal = () => {
    setOpen(false);
    setSkuKeys([]);
  };
  /* On Ag grid initia render  */
  const onGridReady = (params) => {
    gridApi = params.api;
    params.api.sizeColumnsToFit();
  };

  /* get call on rows selection changed in grid */
  const onSelectionChanged = () => {
    var selectedRows = gridApi.getSelectedRows();
    props.getSelectedRow(selectedRows);
  };

  /*on change on Auditlog grid rows */
  const updateGridData = (sku, index) => {
    setSelectedSku(sku);
  };

  /* get call onClick on Close  cta in Audit log */
  const removeRow = (sku, indx) => {
    if (skuKeys.length > 1) {
      const remainingItems = skuKeys.filter((item) => item != sku);
      setSkuKeys(remainingItems);
      if (sku == selectedSku) {
        setSelectedSku(remainingItems[0]);
      }
    } else {
      closeModal();
    }
  };

  return (
    <div>
      <AlertDialog
        open={successAlertOpen}
        close={() => {
          setSuccessAlertOpen(false);
          setAlertErrorMessage("");
        }}
        errorMessage={alertErrorMessage}
      />
      <div className="d-flex">
        <ActionSelectionDropDown
          actnonslctd={props.actnonslctd}
          selectedActn={selectedActn}
          getSelectedAction={getSelectedAction}
          callMassOfferActn={callMassOfferActn}
          brand={props.brand}
          category={props.category}
          selectedTab={props.selectedTab}
          selectedRows={props.selectedRow}
          resetSaveActionResp={props.resetSaveActionResp}
        />
        <Modal
          show={open}
          onHide={closeModal}
          className="auditLoagBackDrop"
          style={{ zIndex: "1000000" }}
          backdropClassName="auditLoagBackDrop"
          size="sm"
          dialogClassName="auditLogModal error-close"
        >
          <div className="offer-download-close modal-audit">
            <img
              height="32px"
              src={xcircle}
              onClick={() => closeModal()}
              alt="close"
            />
          </div>
          <Modal.Header className="modaltitlecontainer boredr_none">
            <Modal.Title id="ModalHeader" className="audtlgtxt">
              {Constant.priceManagement.audit_log}
            </Modal.Title>
            {window.is2wDealer ? (
              <AuditLogModalHeader2w
              rightSideList={massOfferActionResp[selectedSku]}
              />
            ) : (
              <AuditLogModalHeader
              rightSideList = {massOfferActionResp[selectedSku]}
              />
            )}
          </Modal.Header>
          <Modal.Body className="auditlogModalBody error-close">
            <div className="main-body">
              <AuditLogModalBody
                massRespData={massRespData}
                auditData={auditData}
                updateGridData={updateGridData}
                removeRow={removeRow}
                skuKeys={skuKeys}
                selectedSku={selectedSku}
              />
              {window.is2wDealer ? (
                <AuditLogModalPopup2W
                  setAuditData={auditData}
                  onGridReady={onGridReady}
                  onSelectionChanged={onSelectionChanged}
                  rightSideList = {massOfferActionResp[selectedSku]}
                />
              ) : (
                <AuditLogModalPopup
                  setAuditData={auditData}
                  onGridReady={onGridReady}
                  onSelectionChanged={onSelectionChanged}
                  rightSideList={massOfferActionResp[selectedSku]}
                />
              )}
            </div>
          </Modal.Body>
        </Modal>
        <Modal
          id="editActionModal"
          className="auditLoagBackDrop"
          style={{ zIndex: "1000000" }}
          backdropClassName="auditLoagBackDrop"
          show={isEditModalOpen}
          onHide={() => setIsEditModalOpen(false)}
        >
          <Modal.Header className="border_none" closeButton>
            <Modal.Title id="ModalHeader" className="audtlgtxt editTxt">
              {Constant.priceManagement.edit}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="edit_modal">
            <EditOnSelection
              selectedRows={props.selectedRow}
              selectedsku={props.selectedsku}
              gridrows={props.gridrows}
              actnresp={props.actnresp}
              childIds={props.childIds}
              parentDlerId={props.parentDlerId}
              onUpdateCallDashBoardApi={props.onUpdateCallDashBoardApi}
              callMassOfferActn={callMassOfferActn}
              closeModal={() => setIsEditModalOpen(false)}
              actnStatus={props.actionStatus}
              actnMsg={props.actionMsg}
              getSelectedRow={props.getSelectedRow}
              getSelectedStatus={props.getSelectedStatus}
              getSelectedAction={getSelectedAction}
              resetPrice={props.resetPrice}
            />
          </Modal.Body>
        </Modal>
      </div>
      <div>{showErr ? <p className="masserrtxt">{applyErrMsg}</p> : ""}</div>
    </div>
  );
};
export default ActionOnSelection;
