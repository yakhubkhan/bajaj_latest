
/* eslint-disable */
export const cellbg = (params) => {
  let classnames = "borderBottom";
  const bgClr = params.node.selected ? " greenColor " : " whiteColor ";
  const category_flag = params.data.category_flag != 1;
  classnames = (category_flag ? " disableCell " : bgClr) + classnames;

  if (params.colDef.field == "sku") {
    classnames = classnames + " skuTextStyle skuHeaderClass model_des ";
  }
  if (
    (params.colDef.field == "delivery_fee" ||
      params.colDef.field == "action") &&
    category_flag
  ) {
    classnames = classnames.replace("disableCell", "");
  }
  if (params.colDef.field == "model_id") {
    classnames = classnames + " model_des1";
  } else {
    classnames = classnames + " model_des";
  }
  if (params.colDef.field == "offer_price") {
    classnames = classnames + " price";
  }
  return classnames;
};

const GridColumnsLogistics = () => {
  const checkboxSelection = (params) => {
    if (params.columnApi)
      return params.columnApi.getRowGroupColumns().length === 0;
    else return 0;
  };

  let defaultdridcols = [
    {
      headerName: "All",
      field: "all",
      width: 80,
      minWidth: 80,
      maxWidth: 100,
      cellClass: cellbg,
      pinned: "left",
      lockPinned: true,
      lockPosition: true,
      checkboxSelection: checkboxSelection,
      headerCheckboxSelection: checkboxSelection,
    },
    {
      headerName: "SKU",
      field: "sku",
      cellClass: cellbg,
      headerClass: "skuHeaderClass",
      tooltip: (params) => params.value,
      resizable: true,
      width: 310,
      minWidth: 310,
      maxWidth: 310,
      cellRenderer: "Sku",
      cellTooltip: true,
      cellStyle: {
        "word-wrap": "break-word",
        "white-space": "normal",
        "user-select": "text",
        // width: "100px",

        // "line-height": "15px",
        // display: "-webkit-box",
        margin: "0 auto",
        "line-height": "1.4",
        "-webkit-line-clamp": "2",
        "-webkit-box-orient": "vertical",
        overflow: "hidden",
        "text-overflow": "ellipsis",
        "border-right": "1px solid #E8E7E6 !important",
        "border-left": "1px solid #E8E7E6 !important",
        borderBottom: "1px solid #e8e7e6 !important"

      },
      pinned: "left",
    },
    {
      headerName: "Model ID",
      field: "model_id",
      width: 170,
      minWidth: 170,
      maxWidth: 170,
      cellClass: cellbg,
      cellStyle: { borderRight: "1px solid #E8E7E6 !important",borderBottom: "1px solid #e8e7e6 !important", paddingTop: '30px', color: '#8d8882' },
    },
    {
      headerName: "Logistics By",
      field: "logistics_by",
      cellRenderer: "LogisticsBy",
      width: 200,
      minWidth: 200,
      maxWidth: 200,
      cellClass: cellbg,
      cellStyle: { borderRight: "1px solid #E8E7E6 !important",borderBottom: "1px solid #e8e7e6 !important" },
      editable: false,
    },
    {
      headerName: "Logistics Fee",
      field: "logistics_fee",
      cellRenderer: "LogisticsFee",
      width: 200,
      minWidth: 200,
      maxWidth: 200,
      cellClass: cellbg,
      cellStyle: { borderRight: "1px solid #E8E7E6 !important",borderBottom: "1px solid #e8e7e6 !important" },
      editable: false,
    },
    {
      headerName: "Delivery Fee",
      field: "delivery_fee",
      cellRenderer: "DeliveryFeeDisplay",
      cellEditor: "DeliveryFeeEditor",
      width: 200,
      minWidth: 200,
      maxWidth: 200,
      cellStyle: { borderRight: "1px solid #E8E7E6 !important",borderBottom: "1px solid #e8e7e6 !important" },
      cellClass: cellbg,
      editable: true,
    },
    {
      headerName: "Price",
      field: "offer_price",
      valueFormatter: (params) => '₹' + params.value,
      width: 180,
      minWidth: 180,
      maxWidth: 180,
      cellClass: cellbg,
      cellStyle: { borderRight: "1px solid #E8E7E6 !important",borderBottom: "1px solid #e8e7e6 !important", paddingTop: '30px' },
    },
    {
      headerName: "Action",
      field: "action",
      cellRenderer: "saveaction",
      width: 200,
      minWidth: 200,
      maxWidth: 200,
      pinned: "right",
      lockPinned: true,
      cellClass: cellbg,
      cellStyle: {borderBottom: "1px solid #e8e7e6 !important" },

    },
  ];
  return defaultdridcols;
};

export default GridColumnsLogistics;
