import React from "react";
import "../../css/custom.css";

const CustomTooltip = (props) => {
  props.reactContainer.classList.add("custom-tooltip");
  const copyText = () => {
    navigator.clipboard.writeText(props.value);
  };
  return (
    <div>
      <i className="fa fa-clone" aria-hidden="true" onClick={copyText()}></i>
      <span className="sku-tooltip">{props.value}</span>
    </div>
  );
};

export default CustomTooltip;
