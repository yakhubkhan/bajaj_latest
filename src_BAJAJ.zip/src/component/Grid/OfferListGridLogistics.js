/* eslint-disable */
import React, { useState, useEffect, useRef } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "./OffersListGridLogistics.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";
import Pagination from "./Pagination";
import { frameworkComponents } from "./FrameworkComponentsLogistics";
import GridColumnsLogistics, { cellbg } from "./GridColumnsLogistic";
import PriceAlertGrid from "../../utils/PriceAlertGrid";
import { resetSKU } from "../../gtm";
import listingImage from "../../images/blankPage.png";
import stickyGridHeader from "./stickyGridHeader";
import AlertDialog from "./Alert";

import "./OfferesGrid.css";

function usePrevious(value) {
  const ref = useRef();
  useEffect(() => {
    ref.current = value;
  });
  return ref.current;
}

const OffersListGridLogistics = (props) => {
  let defaultColDef = {
    sortable: true,
    resizable: true,
    tooltipComponent: "customTooltip",
  };
  const [successAlertOpen, setSuccessAlertOpen] = useState(false);
  const [alertErrorMessage, setAlertErrorMessage] = useState("");
  const [gridApi, setGridApi] = useState();
  const [gridColumnApi, setGridColumnApi] = useState();
  const [selectedstatus, SetSelectedStatus] = useState("");
  const [actnStatus, SetActnStatus] = useState("");
  const [actnMsg, SetActnMsg] = useState("");
  const [currentTab, SetCurrentTab] = useState("");
  const [selectedsku, SetSelectedSku] = useState([]);
  const [actnresp, SetActnResp] = useState([]);
  const [pageNo, SetPageNo] = useState(1);
  const [gridcols, SetGridCols] = useState(GridColumnsLogistics());
  const [status, setStatus] = useState(true);
  const [status1, setStatus1] = useState(true);
  let container = useRef(null);


  const getRowStyle = (params) => {
    if (params.node.selected) {
      return { backgroundColor: "#EBF3FF !important" };
    } else if (params.data.category_flag == 0) {
      return { backgroundColor: "rgb(248, 248, 248) !important" };
    } else {
      return { backgroundColor: "#fff !important" };
    }
  };

  const getRowHeight = (params) => {
    return 91;
  };

  useEffect(() => {
    if (gridApi !== undefined && props.gridrows && props.gridrows.length > 0) {
      gridApi.redrawRows();
    }
  }, [actnresp]);

  useEffect(() => {
    stickyGridHeader();
  }, [status]);

  useEffect(() => {
    // if(status1 !== status){
    if (
      props.selectedTab === "new" &&
      (props.brand.length || props.category.length)
    ) {
      setStatus(false);
    } else if (
      props.selectedTab === "new" &&
      (props.brand.length === 0 || props.category.length === 0)
    ) {
      setStatus(true);
    } else {
      setStatus(false);
    }
    // }
  }, [props]);

  const prevActnResp = usePrevious(actnresp);
  const prevPropsActnResp = usePrevious(props.actnresp);
  const prevSelectedStatus = usePrevious(selectedstatus);
  const prevPropsSelectedStatus = usePrevious(props.selectedstatus);
  const prevPropsSelevent = usePrevious(props.selevent);
  const prevPropsSelectedTab = usePrevious(props.selectedTab);

  useEffect(() => {
    if (
      prevPropsActnResp !== props.actnresp ||
      prevPropsActnResp !== prevActnResp
    ) {
      SetActnStatus(props.actionStatus);
      SetActnMsg(props.actionMsg);
      SetSelectedSku(props.selectedsku);
      SetActnResp(props.actnresp);
      SetCurrentTab(props.selectedTab);
      if (gridApi !== undefined) {
        gridApi.redrawRows();
      }
    }

    let gridColumns = gridcols.filter((item) => {
      return (
        item.field != "referenceprice" &&
        item.headerName != "Best Reference Price"
      );
    });

    if (
      props.selectedTab === "new" &&
      (props.brand.length || props.category.length)
    ) {
      setStatus(false);
    } else if (
      props.selectedTab === "new" &&
      (props.brand.length === 0 || props.category.length === 0)
    ) {
      setStatus(true);
    } else {
      setStatus(false);
    }

    if (currentTab !== props.selectedTab) {
      let arry = [...gridColumns, ...PriceAlertGrid(props.selectedTab)];
      SetGridCols(arry);
      SetCurrentTab(props.selectedTab);
    }
    if (
      prevPropsSelectedStatus !== props.selectedstatus ||
      prevPropsSelectedStatus !== prevSelectedStatus
    ) {
      SetSelectedStatus(props.selectedstatus);
    }
    if (
      prevPropsSelectedTab !== props.selectedTab &&
      document.getElementById("pageNumInputID")
    ) {
      SetPageNo(1);
      document.getElementById("pageNumInputID").value = 1;
    }
    // gridColumnApi&& gridColumnApi.autoSizeAllColumns()
  }, [
    gridcols,
    prevActnResp,
    prevPropsActnResp,
    prevSelectedStatus,
    prevPropsSelectedStatus,
    prevPropsSelevent,
    prevPropsSelectedTab,
  ]);

  useEffect(() => {
    let arry = [];
    if (prevPropsSelevent !== props.selevent) {
      const filds = props.selevent.map((eachItem, index) => {
        var obj = {};
        obj["headerName"] = eachItem.label;
        obj["field"] = eachItem.value;
        obj["cellClass"] = cellbg;
        obj["cellStyle"] = { borderRight: "1px solid #E8E7E6 !important",  borderBottom: "1px solid #e8e7e6 !important", paddingTop: "30px", borderBottom: "1px solid #e8e7e6" };
        if (eachItem.value == "visibleOnWebsite") {
          obj["cellRenderer"] = "visibleOnWebsite";
        }
        if (eachItem.value == "creationTime") {
          obj["cellRenderer"] = "creationTime";
        }
        if (eachItem.value == "MRP/MOP") {
          obj["cellRenderer"] = "MrpMop";
        }
        if (eachItem.value == "Min/Max") {
          obj["cellRenderer"] = "MinMax";
        }
        if (eachItem.value == "image") {
          obj["cellRenderer"] = "imgComponent";
          obj["cellStyle"] = {  borderBottom: "1px solid #e8e7e6 !important", borderRight: "1px solid #E8E7E6 !important"}
        }

        if(index == props.selevent.length -1) {
          obj["cellStyle"] = { borderRight: "0px !important"}
        }

        return obj;
      });
      if (currentTab === "pricealert") {
        arry = [
          ...GridColumnsLogistics(),
          ...filds,
          ...PriceAlertGrid(props.selectedTab),
        ];
      } else {
        arry = [
          ...GridColumnsLogistics(),
          ...filds,
          // ...[
          //   {
          //     headerName: "Best Reference Price",
          //     field: "best_reference_price",
          //     cellRenderer: "Best Reference Price",
          //     width: 82,
          //     minWidth: 82,
          //     maxWidth: 250,
          //     cellClass: cellbg,
          //   },
          // ],
        ];
      }

      const index = arry.findIndex((item) => item.field == "image");
      if (index >= 0) {
        const element = arry[index];
        arry.splice(index, 1);
        arry.splice(1, 0, element);
      }
      SetGridCols(arry);
      if (gridApi !== undefined) {
        gridApi.redrawRows();
      }
    }
  }, [props.selevent]);

  const onGridReady = (params) => {
    const { api, columnApi } = params;
    setGridApi(api);
    setGridColumnApi(columnApi);
    // params.api.sizeColumnsToFit();
    params.api.setDomLayout("autoHeight");
    params.columnApi.autoSizeAllColumns();
    if (document.querySelector("#myGrid")) {
      document.querySelector("#myGrid").style.height = "";
    }
  };

  const onSelectionChanged = () => {
    var selectedRows = gridApi.getSelectedRows();
    if (gridApi !== undefined) {
      gridApi.redrawRows();
    }
    props.getSelectedRow(selectedRows);
    // props.downloadHanlder(selectedRows);
    resetSKU({
      dealerId: props.dealerid,
      dealerName: props.dealerName,
      selectedTab: props.selectedTab,
      filter: props.filter,
    });
  };

  props.gridrows?.map((item) => {
    if (!item.referenceprice) {
      item.referenceprice = 0;
    }
  });

  useEffect(() => {
    window.addEventListener("mousedown", handleClickOutside);
    return () => {
      window.removeEventListener("mousedown", handleClickOutside);
    };
  }, [gridApi]);

  const handleClickOutside = (event) => {
    if (container.current && !container.current.contains(event.target)) {
      gridApi.stopEditing();
    }
  };

  return (
    <div className="mainGridListContainer">
      <AlertDialog
        open={successAlertOpen}
        close={() => setSuccessAlertOpen(false)}
        errorMessage={alertErrorMessage}
      />
      {!status ? (
        <div
        ref = {container}
          id="myGrid"
          className={
            "ag-theme-alpine mainGrid " +
            (props.isGetOffersListLoading ? "hideList" : "")
          }
          style={{
            width: "100%",
            // paddingTop: '22px'
          }}
        >
          <AgGridReact
            singleClickEdit={true}
            columnDefs={gridcols}
            rowData={props.gridrows}
            defaultColDef={defaultColDef}
            onGridReady={onGridReady}
            rowSelection="multiple"
            suppressPaginationPanel={true}
            pagination={true}
            open={(errorMessage) => {
              setSuccessAlertOpen(true);
              setAlertErrorMessage(errorMessage);
            }}
            undoRedoCellEditing={true}
            onGridColumnsChanged={() =>
              gridColumnApi && gridColumnApi.autoSizeAllColumns()
            }
            props={props}
            state={{
              actnMsg,
              selectedsku,
              actnresp,
              actnStatus,
              rowData: props.gridrows.map((a) => ({ ...a })),
            }}
            paginationPageSize={props.gridrows?.length}
            onSelectionChanged={onSelectionChanged}
            suppressRowClickSelection={true}
            getRowHeight={getRowHeight}
            getRowStyle={getRowStyle}
            suppressDragLeaveHidesColumns={true}
            frameworkComponents={frameworkComponents}
            tooltipShowDelay={0}
            tooltipHideDelay={5000}
          ></AgGridReact>
          <div key = {props.selectedTab}>
          <Pagination
            totalRecords={props.totalRecords}
            totalItems={props.totalItems}
            isFilterSearch={props.isFilterSearch}
            getSelectedPage={props.getSelectedPage}
            paginationPageSize={10}
            pageNo={pageNo}
            gridApi={gridApi}
            selectedlimit={props.selectedlimit}
          ></Pagination>
          </div>
        </div>
      ) : (
        <div className="blank_data">
          <img
            src={listingImage}
            alt="listing image"
            className="pad_top_70"
          ></img>
          <p className="pad_top_30 choose_from_Category">
            Please choose from <b>Category</b> and <b>Brand</b> to see your
            preferred SKUs
          </p>
        </div>
      )}
    </div>
  );
};

export default OffersListGridLogistics;
