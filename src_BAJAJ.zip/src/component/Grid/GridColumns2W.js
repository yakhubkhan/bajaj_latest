/* eslint-disable */
export const cellbg = (params) => {
  let classnames = "borderBottom";
  const bgClr = " whiteColor ";
  const is_expired = params.data.is_expired === 1;
  classnames = (is_expired ? " disableCell " : bgClr) + classnames;

  if (params.colDef.field == "sku") {
    classnames =
      classnames +
      " skuTextStyle skuHeaderClass model_des " +
      (is_expired ? " skuCell" : "");
  }
  if (params.colDef.field == "model_id") {
    classnames = classnames + " model_des1";
  } else {
    classnames = classnames + " model_des";
  }

  return classnames;
};

const GridColumns2W = () => {
  const checkboxSelection = (params) => {
    if (params.columnApi)
      return params.columnApi.getRowGroupColumns().length === 0;
    else return 0;
  };
  let defaultdridcols = [
    {
      headerName: "All",
      field: "all",
      width: 40,
      minWidth: 40,
      maxWidth: 80,
      cellClass: cellbg,
      pinned: "left",
      lockPinned: true,
      lockPosition: true,
      checkboxSelection: checkboxSelection,
      headerCheckboxSelection: checkboxSelection,
      cellStyle: {borderRight: "1px solid #E8E7E6 !important", borderBottom: "1px solid #e8e7e6 !important" },

    },
    {
      headerName: "SKU",
      field: "sku",
      cellClass: cellbg,
      headerClass: "skuHeaderClass",
      resizable: true,
      width: 330,
      // left: 200,
      minWidth: 330,
      maxWidth: 330,
      cellRenderer: "Sku",
      tooltipField: "sku",
      cellStyle: {
        // "text-overflow": "clip",
        "word-wrap": "break-word",
        // "overflow": "visible",
        "white-space": "normal",
        "user-select": "text",
        // width: "100px",

        // "line-height": "15px",
        // display: "-webkit-box",
        margin: "0 auto",
        "line-height": "1.4",
        "-webkit-line-clamp": "2",
        "-webkit-box-orient": "vertical",
        overflow: "hidden",
        "text-overflow": "ellipsis",
        "border-right": "1px solid #E8E7E6 !important",
        borderBottom: "1px solid #e8e7e6 !important"
      },
      pinned: "left",
    },
    {
      headerName: "Model ID",
      field: "model_id",
      width: 150,
      minWidth: 150,
      maxWidth: 150,
      cellClass: cellbg,
      cellStyle: { borderRight: "1px solid #E8E7E6 !important", borderBottom: "1px solid #e8e7e6 !important" },
    },
    {
      headerName: "Ex Showroom Price",
      field: "Ex_Showroom_Price",
      editable: true,
      cellRenderer: "Stock",
      cellEditor: "StockValueEditor",
      tooltip: (params) => {
        if (params.value === undefined || params.value === "") {
          return "Please fill all the fields to save changes";
        }
      },
      width: 180,
      minWidth: 180,
      maxWidth: 180,
      cellClass: cellbg,
      cellStyle: { borderRight: "1px solid #E8E7E6 !important", borderBottom: "1px solid #e8e7e6 !important" },
    },
    {
      headerName: "RTO Charges",
      field: "RTO",
      editable: true,
      cellRenderer: "Stock",
      cellEditor: "StockValueEditor",
      tooltip: (params) => {
        if (params.value === undefined || params.value === "") {
          return "Please fill all the fields to save changes";
        }
      },
      width: 150,
      minWidth: 180,
      maxWidth: 180,
      // left: 736,
      cellClass: cellbg,
      cellStyle: { borderRight: "1px solid #E8E7E6 !important", borderBottom: "1px solid #e8e7e6 !important" },
    },
    {
      headerName: "Insurance Price",
      field: "Insurance",
      editable: true,
      cellRenderer: "Stock",
      cellEditor: "StockValueEditor",
      tooltip: (params) => {
        if (params.value === undefined || params.value === "") {
          return "Please fill all the fields to save changes";
        }
      },
      width: 150,
      minWidth: 180,
      maxWidth: 180,
      cellStyle: { borderRight: "1px solid #E8E7E6 !important", borderBottom: "1px solid #e8e7e6 !important" },
      cellClass: cellbg,
    },
    {
      headerName: "Stock",
      field: "inventory",
      editable: true,
      cellRenderer: "Stock",
      cellEditor: "StockValueEditor",
      tooltip: (params) => {
        if (params.value === undefined || params.value === "") {
          return "Please fill all the fields to save changes";
        }
      },
      width: 150,
      minWidth: 180,
      maxWidth: 180,
      cellClass: cellbg,
      cellStyle: { borderRight: "1px solid #E8E7E6 !important", borderBottom: "1px solid #e8e7e6 !important" },
    },
    {
      headerName: "Status",
      field: "prod_status",
      cellRenderer: "Status",
      width: 150,
      minWidth: 150,
      maxWidth: 150,
      cellStyle: {
        Right: "220px !important",
        borderRight: "1px solid lightgrey !important",
        borderBottom: "1px solid #e8e7e6 !important",
      },
      cellClass: cellbg,
    },
    {
      headerName: "Max On Road Price",
      field: "Max_ORP",
      width: 180,
      minWidth: 180,
      maxWidth: 180,
      cellClass: cellbg,
      cellStyle: {
        borderRight: "1px solid lightgrey !important",
        borderBottom: "1px solid #e8e7e6 !important",
      },
    },
    // {
    //   headerName: "On Road Price",
    //   field: "on_road_price",
    //   width: 180,
    //   minWidth: 180,
    //   maxWidth: 180,
    //   cellClass: cellbg,
    //   cellStyle: { borderRight: "1px solid lightgrey !important" },
    // },
    {
      headerName: "Action",
      field: "action",
      cellRenderer: "saveaction",
      width: 150,
      minWidth: 180,
      maxWidth: 180,
      pinned: "right",
      lockPinned: true,
      cellClass: cellbg,
      cellStyle: {borderBottom: "1px solid #e8e7e6 !important" },

    },
  ];
  return defaultdridcols;
};

export default GridColumns2W;
