/* eslint-disable */
import React, { useState, useEffect } from "react";
import "./OfferesGrid.css";

const Price = (props) => {
  const [showmodal, SetShowmodal] = useState(true);
  let wrapperRef = React.createRef();
  const getPrice = (price) => {
    props.setValue(price.target.value);
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
  }, []);

  const handleClickOutside = (event) => {
    if (
      wrapperRef.current !== null &&
      !wrapperRef.current.contains(event.target)
    ) {
      props.agGridReact.api.clearFocusedCell();
      if (showmodal) {
        SetShowmodal(false);
      }
    }
  };
  let response = props.agGridReact.props.state;
  let actionStatus =
    typeof response.actnStatus !== "undefined" && response.actnStatus !== ""
      ? response.actnStatus
      : "";
  let actionMessage =
    typeof response.actnMsg === "object"
      ? response.actnMsg[0]
      : response.actnMsg;
  let skuInfo =
    response.selectedsku &&
    typeof response.selectedsku[0] !== "undefined" &&
    response.selectedsku[0] !== ""
      ? response.selectedsku[0]
      : "";
  var inputClass = "rupee";
  let actnresp =
    typeof response.actnresp !== "undefined" ? response.actnresp : {};
  var isSku = actnresp.length > 0 && actnresp[0].sku === props.data.sku;
  if (
    !isSku &&
    typeof actnresp[0] !== "undefined" &&
    typeof actnresp[0].skuid !== "undefined"
  ) {
    const skuid = props.data.skuid ? props.data.skuid : props.data.sku+"_"+props.data.dealer_id
    isSku = actnresp.length > 0 && actnresp[0].skuid === skuid;
  }

  if (actnresp.itemPrice !== "undefined" && !isSku) {
    isSku = skuInfo.sku === props.data.sku;
  }

  if (
    actnresp.itemPrice !== "undefined" &&
    typeof skuInfo.skuid !== "undefined" &&
    !isSku
  ) {
    isSku = skuInfo.skuid === props.data.skuid;
  }

  let erroCode =
    actnresp.length > 0 &&
    typeof actnresp[0] !== "undefined" &&
    typeof actnresp[0][0] !== "undefined"
      ? actnresp[0][0].errorCode
      : 0;
  if (actionStatus === "failed" && isSku) {
    inputClass = "rupee";
  }
  let priceValue = props.value == null ? 0 : props.value;

  return (
    <div>
      {actionStatus === "fee_preview" && isSku && actnresp && showmodal && (
        <div className="tooltiptext">
          <div className="feetxt" style={{ fontWeight: "bold" }}>
            Fee Preview
          </div>
          <div className="feetxt">
            Item Price
            <span style={{ paddingLeft: "34%" }} className="spntxt">
              Rs. {actnresp.itemPrice}
            </span>
          </div>
          <div className="feetxt">
            Dealer Charges
            <span className="spntxt">Rs. {actnresp.dealerCharges}</span>
          </div>
          <div className="feetxt" style={{ fontWeight: "bold" }}>
            Net Realisation
            <span className="spntxt">Rs. {actnresp.customerPays}</span>
          </div>
        </div>
      )}
      <div>
        <input
          type="text"
          className={`${inputClass} stockInput`}
          onChange={getPrice}
          value={"₹ " + priceValue}
        ></input>
      </div>

      {actionStatus && actionMessage !== "fee_preview" && isSku && (
        <label
          className={`issueText ${
            actionStatus === "failed" ? "redcolor" : "blucolor"
          }`}
        >
          {actionStatus !== "failed" && actionMessage}
        </label>
      )}
      {actionStatus && actionMessage !== "fee_preview" && isSku && (
        <label
          className={`issueText ${
            actionStatus === "failedActionOnEdit" ? "redcolor" : "blucolor"
          }`}
        >
          {actionStatus === "failedActionOnEdit" && actionMessage}
        </label>
      )}
      {erroCode !== 0 && actnresp.length > 0 && (
        <div>
          {actnresp.map((selrow, indx) => {
            if (selrow[0] !== undefined) {
              let isSkuId =
                typeof selrow[0].skuid !== "undefined"
                  ? selrow[0].skuid === props.data.skuid
                  : selrow[0].sku === props.data.sku;
              if (isSkuId) {
                return (
                  <label
                    className={`issueText ${
                      selrow[0].errorCode !== 10 ? "redcolor" : "blucolor"
                    }`}
                  >
                    {actionStatus !== "failed" && selrow[0].errorMessage}
                  </label>
                );
              }
            } else {
              let isSkuId =
                typeof selrow.skuid !== "undefined"
                  ? selrow.skuid === props.data.skuid
                  : selrow.sku === props.data.sku;
              if (isSkuId) {
                return (
                  <label
                    className={`issueText ${
                      selrow[0].errorCode !== 10 ? "redcolor" : "blucolor"
                    }`}
                  >
                    {actionStatus !== "failed" && selrow.errorMessage}
                  </label>
                );
              }
            }
          })}
        </div>
      )}
    </div>
  );
};
export default Price;
