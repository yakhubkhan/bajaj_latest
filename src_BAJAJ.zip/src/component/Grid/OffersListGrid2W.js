/* eslint-disable */
import React, { useState, useEffect, useRef } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";
import Pagination2W from "./Pagination2W";
import { frameworkComponents } from "./FrameworkComponents2W";
import GridColumns2W, { cellbg } from "./GridColumns2W";
import PriceAlertGrid from "../../utils/PriceAlertGrid";
import { resetSKU } from "../../gtm";
import AlertDialog from "./Alert";
import listingImage from "../../images/blankPage.png";
import stickyGridHeader from "./stickyGridHeader";

import "./OfferesGrid.css";

function usePrevious(value) {
  const ref = useRef();
  useEffect(() => {
    ref.current = value;
  });
  return ref.current;
}

const OffersListGrid2W = (props) => {
  let defaultColDef = {
    sortable: true,
    resizable: true,
    tooltipComponent: "customTooltip",
  };

  const [successAlertOpen, setSuccessAlertOpen] = useState(false);
  const [alertErrorMessage, setAlertErrorMessage] = useState("");
  const [gridApi, setGridApi] = useState();
  const [gridColumnApi, setGridColumnApi] = useState();
  const [selectedstatus, SetSelectedStatus] = useState("");
  const [actnStatus, SetActnStatus] = useState("");
  const [actnMsg, SetActnMsg] = useState("");
  const [currentTab, SetCurrentTab] = useState("");
  const [selectedsku, SetSelectedSku] = useState([]);
  const [actnresp, SetActnResp] = useState([]);
  const [pageNo, SetPageNo] = useState(1);
  const [gridcols, SetGridCols] = useState(GridColumns2W());
  const [status, setStatus] = useState(true);

  const getRowStyle = (params) => {
    if (params.node.selected) {
      return { backgroundColor: "#EBF3FF !important" };
    } else {
      return { backgroundColor: "#fff !important" };
    }
  };

  const getRowHeight = (params) => {
    return 91;
  };

  useEffect(() => {
    if (gridApi !== undefined && props.gridrows && props.gridrows.length > 0) {
      gridApi.redrawRows();
    }
  }, [actnresp]);

  useEffect(() => {
    stickyGridHeader();
  }, [status]);

  const prevActnResp = usePrevious(actnresp);
  const prevPropsActnResp = usePrevious(props.actnresp);
  const prevSelectedStatus = usePrevious(selectedstatus);
  const prevPropsSelectedStatus = usePrevious(props.selectedstatus);
  const prevPropsSelevent = usePrevious(props.selevent);
  const prevPropsSelectedTab = usePrevious(props.selectedTab);

  useEffect(() => {
    if (
      prevPropsActnResp !== props.actnresp ||
      prevPropsActnResp !== prevActnResp
    ) {
      SetActnStatus(props.actionStatus);
      SetActnMsg(props.actionMsg);
      SetSelectedSku(props.selectedsku);
      SetActnResp(props.actnresp);
      SetCurrentTab(props.selectedTab);
      if (gridApi !== undefined) {
        gridApi.redrawRows();
      }
    }

    let gridColumns = gridcols.filter((item) => {
      return (
        item.field != "referenceprice" &&
        item.headerName != "Best Reference Price"
      );
    });

    if (currentTab !== props.selectedTab) {
      let arry = [...gridColumns, ...PriceAlertGrid(props.selectedTab)];
      SetGridCols(arry);
      SetCurrentTab(props.selectedTab);
    }
    if (
      prevPropsSelectedStatus !== props.selectedstatus ||
      prevPropsSelectedStatus !== prevSelectedStatus
    ) {
      SetSelectedStatus(props.selectedstatus);
    }
    if (
      prevPropsSelectedTab !== props.selectedTab &&
      document.getElementById("pageNumInputID")
    ) {
      SetPageNo(1);
      document.getElementById("pageNumInputID").value = 1;
    }
    // gridColumnApi&& gridColumnApi.autoSizeAllColumns()
  }, [
    gridcols,
    prevActnResp,
    prevPropsActnResp,
    prevSelectedStatus,
    prevPropsSelectedStatus,
    prevPropsSelevent,
    prevPropsSelectedTab,
  ]);

  useEffect(() => {
    let arry = [];
    if (prevPropsSelevent !== props.selevent) {
      const filds = props.selevent.map((eachItem) => {
        var obj = {};
        obj["headerName"] = eachItem.label;
        obj["field"] = eachItem.value;
        obj["cellClass"] = cellbg;
        obj["cellStyle"] = {borderRight: "1px solid #E8E7E6 !important", borderBottom: "1px solid #e8e7e6 !important"};

        if (eachItem.value == "visibleOnWebsite") {
          obj["cellRenderer"] = "visibleOnWebsite";
        }
        if (eachItem.value == "creationTime") {
          obj["cellRenderer"] = "creationTime";
        }
        if (eachItem.value == "MRP/MOP") {
          obj["cellRenderer"] = "MrpMop";
        }
        if (eachItem.value == "Min/Max") {
          obj["cellRenderer"] = "MinMax";
        }
        if (eachItem.value == "image") {
          obj["cellRenderer"] = "imgComponent";
        }

        return obj;
      });
      if (currentTab === "pricealert") {
        arry = [
          ...GridColumns2W(),
          ...filds,
          ...PriceAlertGrid(props.selectedTab),
        ];
      } else {
        arry = [
          ...GridColumns2W(),
          ...filds,
          // ...[
          //   {
          //     headerName: "Best Reference Price",
          //     field: "best_reference_price",
          //     cellRenderer: "Best Reference Price",
          //     width: 82,
          //     minWidth: 82,
          //     maxWidth: 250,
          //     cellClass: cellbg,
          //   },
          // ],
        ];
      }

      const index = arry.findIndex((item) => item.field == "image");
      if (index >= 0) {
        const element = arry[index];
        arry.splice(index, 1);
        arry.splice(1, 0, element);
      }
      SetGridCols(arry);
      if (gridApi !== undefined) {
        gridApi.redrawRows();
      }
    }
  }, [props.selevent]);

  const onGridReady = (params) => {
    const { api, columnApi } = params;
    setGridApi(api);
    setGridColumnApi(columnApi);
    // params.api.sizeColumnsToFit();
    params.api.setDomLayout("autoHeight");
    params.columnApi.autoSizeAllColumns();
    if (document.querySelector("#myGrid")) {
      document.querySelector("#myGrid").style.height = "";
    }
  };

  const onSelectionChanged = () => {
    var selectedRows = gridApi.getSelectedRows();
    // if (gridApi !== undefined) {
    //   gridApi.redrawRows();
    // }
    props.getSelectedRow(selectedRows);
    props.downloadHanlder(selectedRows);
    resetSKU({
      dealerId: props.dealerid,
      dealerName: props.dealerName,
      selectedTab: props.selectedTab,
      filter: props.filter,
    });
  };

  props.gridrows.map((item) => {
    if (!item.referenceprice) {
      item.referenceprice = 0;
    }
  });

  return (
    <div className="mainGridListContainer">
      <AlertDialog
        open={successAlertOpen}
        close={() => setSuccessAlertOpen(false)}
        errorMessage={alertErrorMessage}
      />
      <div
        id="myGrid"
        className={
          "ag-theme-alpine mainGrid " +
          (props.isGetOffersListLoading ? "hideList" : "")
        }
        style={{
          width: "100%",
          // paddingTop: '22px'
        }}
      >
        <AgGridReact
          singleClickEdit={true}
          columnDefs={gridcols}
          rowData={props.gridrows}
          defaultColDef={defaultColDef}
          onGridReady={onGridReady}
          rowSelection="multiple"
          suppressPaginationPanel={true}
          pagination={true}
          open={(errorMessage) => {
            setSuccessAlertOpen(true);
            setAlertErrorMessage(errorMessage);
          }}
          undoRedoCellEditing={true}
          onGridColumnsChanged={() =>
            gridColumnApi && gridColumnApi.autoSizeAllColumns()
          }
          props={props}
          state={{ actnMsg, selectedsku, actnresp, actnStatus }}
          paginationPageSize={props.gridrows.length}
          onSelectionChanged={onSelectionChanged}
          suppressRowClickSelection={true}
          getRowHeight={getRowHeight}
          getRowStyle={getRowStyle}
          suppressDragLeaveHidesColumns={true}
          frameworkComponents={frameworkComponents}
          tooltipShowDelay={0}
          tooltipHideDelay={5000}
        ></AgGridReact>
        <div key = {props.selectedTab}>
        <Pagination2W
          totalRecords={props.totalRecords}
          totalItems={props.totalItems}
          isFilterSearch={props.isFilterSearch}
          getSelectedPage={props.getSelectedPage}
          paginationPageSize={10}
          pageNo={pageNo}
          gridApi={gridApi}
          selectedlimit={props.selectedlimit}
        ></Pagination2W>
        </div>
      </div>
    </div>
  );
};

export default OffersListGrid2W;
