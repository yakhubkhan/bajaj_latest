import SaveAction from "./SaveAction";
import Sku from "./Sku2W";
import CustomTooltip from "./CustomTooltip2W";
import LogisticsBy from "./LogisticsBy";
import LogisticsFee from "./LogisticsFee";
import visibleOnWebsite from "./VisibleOnWebsite";
import {
  DeliveryFeeEditor,
  DeliveryFeeDisplay,
} from "./DeliveryFee";

export const frameworkComponents = {
  saveaction: SaveAction,
  DeliveryFeeDisplay: DeliveryFeeDisplay,
  DeliveryFeeEditor: DeliveryFeeEditor,
  Sku: Sku,
  customTooltip: CustomTooltip,
  LogisticsFee: LogisticsFee,
  LogisticsBy: LogisticsBy,
  visibleOnWebsite: visibleOnWebsite,
};
