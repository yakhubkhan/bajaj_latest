/* eslint-disable */
import React, { useEffect, useState } from "react";
import CryptoJS from "crypto-js";
import { axiospricemgmt } from "../../api/axios";
import { blankdetails, successresps } from "../../utils/SaveGrid";
import { saveItem } from "../../gtm";
import AlertDialog from "../Grid/Alert";

let md5dlerid = CryptoJS.MD5("24");
let md5value = md5dlerid.toString();

const SaveAction2W = (props) => {
  const [isHover, setIshover] = useState(false);

  const [alertErrorMessage, setAlertErrorMessage] = useState("");
  const [successAlertOpen, setSuccessAlertOpen] = useState(false);

  const validateButton = () => {
    let selectedrowData = props.data;

    const { RTO, Insurance, Ex_Showroom_Price, inventory } = selectedrowData;

    if (
      RTO == null ||
      RTO == "" ||
      Insurance == null ||
      Insurance == "" ||
      Ex_Showroom_Price == null ||
      Ex_Showroom_Price == "" ||
      inventory == null ||
      inventory == ""
    ) {
      // setDisableButton(true);
      // setIsAllfilled(false)
      return false;
    } else {
      // setDisableButton(false);
      // setIsAllfilled(true)

      return true;
    }
  };

  const isValidSaveCTA = () => {
    let selectedrowData = props.data;
    const { RTO, Insurance, Ex_Showroom_Price, Max_ORP } = selectedrowData;
    let errorMessage = "";
    let Inventory =
      selectedrowData.inventory == null
        ? parseInt(0)
        : parseInt(selectedrowData.inventory);
    //Note: Please append other validation error messages to "errorMessage" by using slash("/").
    if (
      parseInt(RTO) + parseInt(Insurance) + parseInt(Ex_Showroom_Price) >
      Max_ORP
    ) {
      errorMessage =
        "Sum of Ex-Showroom Price, Insurance Price & RTO Charges can’t be more than Max ORP";
    }
    if (
      Inventory === 0 &&
      selectedrowData.prod_status === 1 &&
      props.selectedTab !== "new"
    ) {
      errorMessage = errorMessage != "" ? `${errorMessage}/ ` : "";
      errorMessage = errorMessage + "Status can't be Active when Stock is 0";
    }
    if (errorMessage != "") {
      setSuccessAlertOpen(true);
      setAlertErrorMessage(errorMessage);
    }
    document.getElementsByTagName("body")[0].classList.remove("loading");

    return errorMessage == "";
  };

  const saveRow = (row, e) => {
    let selectedrowData = props.data;
    const { rto, insurance_price, price, max_orp } = selectedrowData;
    debugger;
    let md5value = props.agGridReact.props.props.md5value;
    let selectedTab = props.agGridReact.props.props.selectedTab;
    let parentDlerId = props.agGridReact.props.props.parentDlerId;
    let childDealers = props.agGridReact.props.props.childIds;
    let dealerId = props.agGridReact.props.props.dealerid;
    let dealerName = props.agGridReact.props.props.dealerName;
    let filter = props.agGridReact.props.props.filter;

    if (selectedTab === "new") {
      if (dealerId == parentDlerId && childDealers.length == 0) {
        childDealers = [];
      }
    } else {
      if (childDealers.length == 0 && childDealers != parentDlerId) {
        childDealers = [dealerId];
      } else {
        childDealers = [];
      }
    }
    document.getElementsByTagName("body")[0].classList.add("loading");
    let shouldDoInventoryValidation =
      selectedrowData.prod_status == "inactive" ||
      selectedrowData.prod_status == 2
        ? false
        : true;
    let Inventory =
      selectedrowData.inventory == null
        ? parseInt(0)
        : parseInt(selectedrowData.inventory);

    if (
      selectedrowData.offer_price == 0 ||
      selectedrowData.prod_status == "" ||
      selectedrowData.prod_status == "selectoption"
    ) {
      let resp = blankdetails;
      if (selectedTab === "new") {
        resp.errorBean[0].sku = selectedrowData.sku;
      } else {
        resp.errorBean[0].skuid = selectedrowData.skuid;
      }
      document.getElementsByTagName("body")[0].classList.remove("loading");
      props.agGridReact.props.props.getUpdateddata(
        "failed",
        resp.errorBean[0].errorMessage,
        [],
        resp.errorBean
      );
    }
    //  else if (
    //   (childDealers.length == 0 || childDealers.length > 10) &&
    //   selectedTab === "new"
    // ) {
    //   let resp = {
    //     status: "failed",
    //     payload: null,
    //     errorBean: [
    //       {
    //         sku: selectedrowData.sku,
    //         errorCode: 6,
    //         errorMessage: "Please Choose Dealer Ids to Active.",
    //       },
    //     ],
    //   };
    //   if (childDealers.length > 10) {
    //     resp.errorBean[0].errorMessage =
    //       "Max 10 dealers allowed to activate the offers";
    //   }
    //   document.getElementsByTagName("body")[0].classList.remove("loading");
    //   props.agGridReact.props.props.getUpdateddata(
    //     "failed",
    //     resp.errorBean[0].errorMessage,
    //     [],
    //     resp.errorBean
    //   );

    //   props.agGridReact.props.open(resp.errorBean[0].errorMessage);
    // }
    else {
      let selectedstatus = selectedrowData.prod_status;
      if (selectedrowData.prod_status == "active") {
        selectedstatus = "1";
      } else if (selectedrowData.prod_status == "inactive") {
        selectedstatus = "2";
      }
      let action = "";
      let id = "";
      let skuobj = {};
      let skuarr = [];
      if (selectedTab === "new") {
        skuobj["sku"] = selectedrowData.sku;
      } else {
        skuobj["skuid"] = selectedrowData.skuid;
      }
      skuarr.push(skuobj);
      if (selectedrowData.id != null) {
        action = "update";
        id = selectedrowData.id;
      } else {
        action = "insert";
        id = "NULL";
      }

      console.log("selectedrowData", selectedrowData);

      if (isValidSaveCTA()) {
        let data = {
          action: action,
          pm_key: md5value,
          data: {
            login_dealerId: window.dealerId,
            dealerId: selectedrowData.dealer_id,
            childDealers: childDealers,
            parentDealerId: parentDlerId,
            id: id,
            sku: selectedrowData.sku,
            modelId: selectedrowData.model_id,
            mop: selectedrowData.mop_price,
            mrp: selectedrowData.selling_price,
            Inventory: Inventory,
            offerPrice: selectedrowData.offer_price,
            variants: selectedrowData.cic,
            attribute_set_id: selectedrowData.category,
            reference_price: selectedrowData.referenceprice,
            prod_status: selectedstatus,
            seller_sku_id:
              selectedrowData.sku + "-" + selectedrowData.dealer_id,
            seller_sku_data: selectedrowData.seller_sku_id,
            Ex_Showroom_Price: parseInt(selectedrowData.Ex_Showroom_Price),
            RTO: parseInt(selectedrowData.RTO),
            Insurance: parseInt(selectedrowData.Insurance),
            cityId: selectedrowData.cityid,
            brand: selectedrowData.brand,
            Max_ORP:selectedrowData.Max_ORP
          },
        };

        axiospricemgmt({
          method: "post",
          url: "/updatetwowheelereofferaction",
          data: data,
          headers: {
            "Content-Type": "application/json",
          },
        })
          .then(function (resp) {
            document
              .getElementsByTagName("body")[0]
              .classList.remove("loading");
            if (resp.data.errorBean === undefined) {
              if (selectedTab === "new") {
                successresps.errorBean[0].sku = selectedrowData.sku;
              } else {
                successresps.errorBean[0].skuid = selectedrowData.skuid;
              }
              saveItem({
                dealerId: selectedrowData.dealer_id,
                dealerName: dealerName,
                status: "success",
                item: selectedrowData,
                selectedTab: selectedTab,
                filter: filter,
              });
              props.agGridReact.props.open();
              props.agGridReact.props.props.getUpdateddata(
                "success",
                successresps.errorBean[0].errorMessage,
                [],
                successresps.errorBean,
                selectedTab
              );
              props.agGridReact.props.open();
            } else if (resp.data.errorBean[0].errorCode != 10) {
              saveItem({
                dealerId: selectedrowData.dealer_id,
                dealerName: dealerName,
                status: "error",
                item: selectedrowData,
                selectedTab: selectedTab,
                filter: filter,
              });
              //comp.setState({ actionMsg: resp.data.errorBean[0].errorMessage })
              props.agGridReact.props.props.getUpdateddata(
                "failed",
                resp.data.errorBean[0].errorMessage,
                skuarr,
                resp.data.errorBean,
                selectedTab
              );
              props.agGridReact.props.open(resp.data.errorBean[0].errorMessage);
            } else {
              saveItem({
                dealerId: selectedrowData.dealer_id,
                dealerName: dealerName,
                status: "error",
                item: selectedrowData,
                selectedTab: selectedTab,
                filter: filter,
              });
              //comp.setState({ actionMsg: resp.data.errorBean[0].errorMessage })
              props.agGridReact.props.props.getUpdateddata(
                "success",
                resp.data.errorBean[0].errorMessage,
                skuarr,
                resp.data.errorBean,
                selectedTab
              );
              props.agGridReact.props.open(resp.data.errorBean[0].errorMessage);
            }
          })
          .catch(function (err) {
            saveItem({
              dealerId: selectedrowData.dealer_id,
              dealerName: dealerName,
              status: "error",
              item: selectedrowData,
              selectedTab: selectedTab,
              filter: filter,
            });
            document
              .getElementsByTagName("body")[0]
              .classList.remove("loading");
          });
          document.getElementsByTagName("body")[0].classList.remove("loading");
        }
    }
  };

  return (
    <>
      <AlertDialog
        open={successAlertOpen}
        close={() => {
          setSuccessAlertOpen(false);
          setAlertErrorMessage("");
        }}
        errorMessage={alertErrorMessage}
      />
      <div
        className="mainDivContainer"
        onMouseEnter={() => {
          props.api.stopEditing();
          setIshover(validateButton());
        }}
        onMouseLeave={() => setIshover(validateButton())}
      >
        <button
          type="button"
          id={"saveButton2w" + props.data.sku + props.data.stringModelId}
          className={
            !validateButton() ? "savebtn2W savebtn2Wdisable" : "savebtn2W"
          }
          onClick={saveRow}
        >
          Save
        </button>
        {!isHover ? (
          <div className="tooltiptextBtn">
            <span className="tooltipSpanText">
              Please fill all the fields to save changes
            </span>
          </div>
        ) : (
          <div></div>
        )}
      </div>
    </>
  );
};
export default SaveAction2W;
