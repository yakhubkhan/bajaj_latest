import React from "react";
import "../../css/custom.css";

const ReferencePrice = (props) => {
  return (
    <div>
      <div>
        <span>{props.data.referenceprice}</span>
      </div>
      <div>
        <span className="reference-price">
          {props.data &&
            props.data.price_percent &&
            props.data.price_percent.toFixed(1)}
          %
        </span>
      </div>
    </div>
  );
};

export default ReferencePrice;
