import React from "react";
import Dialog from "@material-ui/core/Dialog";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import { makeStyles } from "@material-ui/core/styles";
import Group from "../../images/Group.svg";
import xcircle from "../../images/x-circle.svg";
import { Typography } from "@material-ui/core";
import downloadError from "../../images/errorIcon.svg";
import "./Alert.css";
//Note :-
//This is used on update
//1. If you send props.errorMessage then it will display error image with error message(props.errorMessage)
//2. If you are not sending props.errorMessage then it will display sussess image with message "Successfully updated".

export default function AlertDialog(props) {
  const useStyles = makeStyles((theme) => ({
    dialog: {
      maxWidth: "500px",
    },
  }));

  const classes = useStyles();

  /* to close the alert */
  const handleClose = () => {
    props.close();
  };

  return (
    <div>
      <Dialog
        open={props.open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        sx={{
          "& .MuiDialog-container": {
            "& .MuiPaper-root": {
              width: "100%",
              maxWidth: "500px",
            },
          },
        }}
        PaperProps={classes.paper}
      >
        <Typography align="center">
          <img
            src={xcircle}
            alt="xcircle"
            className="closeImg"
            onClick={handleClose}
          />
        </Typography>
        <DialogContent className="text">
          <DialogContentText className="text">
            <div>
              <Typography align="center">
                <img
                  src={props.errorMessage ? downloadError : Group}
                  alt="errorMessage"
                  className="tick"
                />
              </Typography>
            </div>
            <div>
              <Typography>
                <p
                  className={
                    props.errorMessage ===
                    "Sum of Ex-Showroom Price, Insurance Price & RTO Charges can’t be more than Max ORP"
                      ? "action-2w"
                      : "Msg"
                  }
                >
                  {props.errorMessage
                    ? props.errorMessage
                    : "Successfully updated"}
                </p>
              </Typography>
            </div>
          </DialogContentText>
        </DialogContent>
      </Dialog>
    </div>
  );
}
