/* eslint-disable */
import React, { useEffect, useState } from "react";

const LogisticsFee = (props) => {
  /* status change function */
  const onStatusChange = (e) => {
    props.setValue(e.target.value);
  };
  const options = [
    { name: "Customer", key: "Customer" },
    { name: "Dealer", key: "Dealer" },
  ];
  const getmagentodeliveryflagRespData =
    props.agGridReact.props?.props?.getmagentodeliveryflagResp?.data?.payload;
  /* to check cell enable or not */
  const isenableCell = () => {
    let text = props.data.logistics_by;

    const matchedValue = getmagentodeliveryflagRespData.find(
      (item) => item.delivery_by == props.data.logistics_by
    );

    return matchedValue?.delivery_type == 1;
  };

  return (
    <div>
      <select
        className={
          "statusslctLogic" + (isenableCell() ? "" : " disableLogistics")
        }
        id="options"
        onChange={onStatusChange}
      >
        <option value="">Paid By</option>
        {options.map((item) => (
          <option
            value={item.key}
            selected={props.value?.toLowerCase() == item.key.toLowerCase()}
          >
            {item.name}
          </option>
        ))}
      </select>
    </div>
  );
};

export default LogisticsFee;
