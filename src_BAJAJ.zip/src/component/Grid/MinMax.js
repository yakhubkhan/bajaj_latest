import React from 'react';

const MinMax = (props) => {
    const minPrice = props.data.min_price;
    const maxPrice = props.data.max_price;
    return (
        <div>
            <div>{minPrice}</div>
            <hr className="mrpline"></hr>
            <div>{maxPrice}</div>
        </div>
    )
}
export default MinMax;