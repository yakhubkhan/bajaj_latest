import React from "react";

const CustomTooltip = (props) => {
  props.reactContainer.classList.add("custom-tooltip");
  const copyText = () => {
    navigator.clipboard.writeText(props.value);
  };
  return (
    <div>
      {props.colDef.headerName === "SKU" && (
        <i class="fa fa-clone" aria-hidden="true" onClick={copyText()}></i>
      )}
      <span style={{ color: "black", marginLeft: "10px" }}>{props.value}</span>
    </div>
  );
};

export default CustomTooltip;
