/* eslint-disable */
import React, { useState, useEffect } from "react";

const LogisticsBy = (props) => {
  /* status change function */
  const onStatusChange = (e) => {
    const val = e.target.value;
    props.setValue(val);
    props.data.logistics_fee =
      !props.data.logistics_fee && val == "Shadow Fax" ? "Customer" : null;
    props.api.redrawRows({
      rowNodes: [props.api.getDisplayedRowAtIndex(props.rowIndex)],
    });
  };

  const getmagentodeliveryflagRespData =
    props.agGridReact.props?.props?.getmagentodeliveryflagResp?.data?.payload;

  useEffect(() => {
    if (!props.value && getmagentodeliveryflagRespData.length == 1) {
      props.setValue(getmagentodeliveryflagRespData[0].delivery_by);

      props.api.redrawRows({
        rowNodes: [props.api.getDisplayedRowAtIndex(props.rowIndex)],
      });
    }
  });

  if (getmagentodeliveryflagRespData.length >= 2) {
    return (
      <div>
        <select
          className="statusslctLogic"
          id="options"
          onChange={(e) => onStatusChange(e)}
        >
          <option value="">Select</option>
          {getmagentodeliveryflagRespData.map((item) => (
            <option
              value={item.delivery_by}
              selected={props.value == item.delivery_by}
            >
              {item.delivery_by}
            </option>
          ))}
        </select>
      </div>
    );
  } else {
    return (
      <div className="disableLogisticsText">
        {getmagentodeliveryflagRespData[0].delivery_by}
      </div>
    );
  }
};
export default LogisticsBy;
