import SaveAction from "./SaveAction2W";
import dateField from "./DateField";
import Price from "./Price";
import Stock, { StockValueEditor } from "./Stock2W";

import Status from "./Status";
import CreationTime from "./CreationTime";
import MrpMop from "./MrpMop";
import Sku from "./Sku2W";
import MinMax from "./MinMax";
import visibleOnWebsite from "./VisibleOnWebsite";
import imgComponent from "./ImageComponent";
import SellerSku from "./SellerSku";
import ReferencePrice from "./ReferencePrice";
import CustomTooltip from "./CustomTooltip2W";

export const frameworkComponents = {
  saveaction: SaveAction,
  dateField: dateField,
  Price: Price,
  Stock: Stock,
  StockValueEditor: StockValueEditor,
  creationTime: CreationTime,
  MrpMop: MrpMop,
  Sku: Sku,
  MinMax: MinMax,
  visibleOnWebsite: visibleOnWebsite,
  imgComponent: imgComponent,
  Status: Status,
  SellerSku: SellerSku,
  ReferencePrice: ReferencePrice,
  customTooltip: CustomTooltip,
};
