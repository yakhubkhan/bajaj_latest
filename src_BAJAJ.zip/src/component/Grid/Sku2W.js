import React from "react";
import {
  checkSkuLowStockInventory,
  checkSkuStockOutInventory,
} from "../../utils/CommonServices";
const Sku = (props) => {
  const sku = props.data.sku;
  const { selectedTab } = props.agGridReact.props.props;
  const new_product = props.data.new_product;
  console.log("selected tab", selectedTab)
  if (new_product && selectedTab == "new") {
    return (
      <div>
        <div className="newLaunch">
          <div className="newLaunchText">New Catalogue</div>
        </div>
        <div className="sku_val">{sku}</div>
      </div>
    );
  } else {
    return (
      <div>
        {checkSkuStockOutInventory(props.data,selectedTab) && (
          <div className="outOfStock">
            <span className="outOfStockText">Out Of Stock</span>
          </div>
        )}
        {checkSkuLowStockInventory(props.data,selectedTab) && (
          <div className="lowStock">
            <span className="lowStockText">Low Stock</span>
          </div>
        )}
        <div className="sku_val">{sku}</div>
      </div>
    );
  }
};
export default Sku;
