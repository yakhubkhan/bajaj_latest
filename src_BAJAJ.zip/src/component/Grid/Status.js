import React, { useState, useEffect } from "react";

const Stock = (props) => {
  const [status, SetStatus] = useState("");
  useEffect(() => {
    if (props.value !== "") {
      SetStatus(props.value);
    } else {
      if (
        props.data.prod_status === null ||
        props.data.prod_status === "" ||
        props.data.prod_status === 0
      ) {
        SetStatus("new");
      } else if (props.data.prod_status === 1) {
        SetStatus("active");
      } else if (props.data.prod_status === 2) {
        SetStatus("inactive");
      }
    }
  }, [props.value, props.data.prod_status]);

  /* to change status value*/
  const onStatusChange = (e) => {
    props.agGridReact.props.props.getSelectedStatus(e.target.value);
    SetStatus(e.target.value);
    if (e.target.value === "active") {
      props.setValue(1);
    } else if (e.target.value === "inactive") {
      props.setValue(2);
    } else if (e.target.value === "selectoption") {
      props.setValue("");
    }
  };
  if (
    status === "new" ||
    status === "selectoption" ||
    props.data.prod_status === null ||
    props.data.prod_status === "" ||
    props.data.prod_status === 0
  ) {
    return (
      <div>
        <select className="statusslct" id="options" onChange={onStatusChange} defaultValue ="selectoption" >
          <option value="selectoption" disabled hidden>
            Select option
          </option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
      </div>
    );
  } else if (status === "active" || props.data.prod_status === 1) {
    return (
      <div>
        <select className="statusslct" id="options" onChange={onStatusChange} defaultValue = "active" >
          <option value="active" >
            Active
          </option>
          <option value="inactive">Inactive</option>
        </select>
      </div>
    );
  } else if (status === "inactive" || props.data.prod_status === 2) {
    return (
      <div>
        <select className="statusslct" id="options" onChange={onStatusChange} defaultValue = "inactive" >
          <option value="active">Active</option>
          <option value="inactive">
            inactive
          </option>
        </select>
      </div>
    );
  }
};
export default Stock;
