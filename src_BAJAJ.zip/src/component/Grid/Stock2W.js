/* eslint-disable */
import React, { forwardRef, useRef, useImperativeHandle, useMemo } from "react";

const Stock = (props) => {
  const stockValue = useMemo(() => {
    return props.value;
  }, [props.value]);

  return (
    <div className="disp_flex stockDisplayContainer ">
      <div
        className={stockValue?.length > 6 ? "stockDisplay2W" : "stockDisplay"}
      >
        {stockValue}
      </div>
    </div>
  );
};
export default Stock;

export const StockValueEditor = forwardRef((props, ref) => {
  const inputRef = useRef();

  const onStockChange = (value) => {
    const field = props.colDef.field;
    const element = document.getElementById(
      "saveButton2w" + props.data.sku + props.data.stringModelId
    );
    if (
      (value == "" ||
        props.data.RTO == null ||
        props.data.RTO == "" ||
        props.data.Ex_Showroom_Price == null ||
        props.data.Ex_Showroom_Price == "" ||
        props.data.Insurance == null ||
        props.data.Insurance == "" ||
        props.data.inventory == null ||
        props.data.inventory == "") &&
      (field == "RTO" ||
        field == "Ex_Showroom_Price" ||
        field == "Insurance" ||
        field == "inventory")
    ) {
      element.classList.add("savebtn2Wdisable");
    } else {
      element.classList.remove("savebtn2Wdisable");
    }
  };

  useImperativeHandle(ref, () => {
    return {
      getValue: () => {
        return inputRef.current.value;
      },
    };
  });
  return (
    <div>
      <input
        id={"stockTextField" + props.rowIndex}
        autoFocus
        className={"stockValue"}
        ref={inputRef}
        defaultValue={props.value}
        onChange={(e) => {
          const value = e.target.value.replace(/[^0-9]/g, "");
          props.data[props.colDef.field] = value;
          onStockChange(value);
          e.target.value = value;
        }}
      />
    </div>
  );
});
