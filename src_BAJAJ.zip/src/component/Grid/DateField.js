import React, { useState } from "react";
import DateRangePicker from "react-bootstrap-daterangepicker";
import moment from "moment";
import "./OfferesGrid.css";

const DateField = (props) => {
  const [startDate, setStartDate] = useState(props.data.start_date);
  const [endDate, setEndDate] = useState(props.data.end_date);

  const handleApply = (picker) => {
    setStartDate(picker.startDate);
    setEndDate(picker.endDate);
    props.data.start_date = picker.startDate.format("YYYY-MM-DD");
    props.data.end_date = picker.endDate.format("YYYY-MM-DD");
  };
  let startdte = "";
  let enddate = "";
  let strenddate = "";
  if (startDate === null && endDate === null) {
    startdte = "";
    enddate = "";
  } else {
    let strtdte = startDate;
    var dteformat = moment(strtdte).format("MM DD YYYY");
    var spltdte = dteformat.split(" ");
    var getmnth = moment(spltdte[0], "MM").format("MMMM");
    spltdte[0] = getmnth;
    let startdte = moment(spltdte.join(" ")).format("MMM DD,YYYY");

    let enddte = endDate;
    var enddteformat = moment(enddte).format("MM DD YYYY");
    var spltdte1 = enddteformat.split(" ");
    var getmnth1 = moment(spltdte1[0], "MM").format("MMMM");
    spltdte1[0] = getmnth1;
    let enddate = moment(spltdte1.join(" ")).format("MMM DD,YYYY");
    strenddate = startdte + "-" + enddate;
  }
  return (
    <DateRangePicker
      initialSettings={{
        showDropdowns: true,
      }}
      startDate={startdte}
      endDate={enddate}
      onApply={handleApply}
    >
      <div className="input-group">
        <input
          type="text"
          className="form-control datefield"
          value={strenddate}
        />
        <span className="input-group-btn icnheight">
          <button className="default date-range-toggle datebtn">
            <i className="fa fa-calendar  calicon" />
          </button>
        </span>
      </div>
    </DateRangePicker>
  );
  // }
};
export default DateField;
