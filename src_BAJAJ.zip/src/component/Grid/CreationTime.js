import React from 'react';
import moment from 'moment';

const CreationTime = (props) => {
    const  value = moment(props.value).format('DD-MM-YYYY  h:mm A');
    return (
        <div>
            {value}
        </div>
    );
};

export default CreationTime;


