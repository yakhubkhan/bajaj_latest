/* eslint-disable */
import React, { useState, useEffect, useRef } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";
import Pagination from "./Pagination";
import { frameworkComponents } from "./FrameworkComponents";
import GridColumns, { cellbg } from "./GridColumns";
import PriceAlertGrid from "../../utils/PriceAlertGrid";
import { resetSKU } from "../../gtm";
import stickyGridHeader from "./stickyGridHeader";
import AlertDialog from "./Alert";
import "./OfferesGrid.css";

function usePrevious(value) {
  const ref = useRef();
  useEffect(() => {
    ref.current = value;
  });
  return ref.current;
}

const OffersListGrid = (props) => {
  let defaultColDef = {
    sortable: true,
    resizable: true,
    tooltipComponent: "customTooltip",
  };
  const [successAlertOpen, setSuccessAlertOpen] = useState(false);
  const [alertErrorMessage, setAlertErrorMessage] = useState("");
  const [gridApi, setGridApi] = useState();
  const [gridColumnApi, setGridColumnApi] = useState();
  const [selectedstatus, SetSelectedStatus] = useState("");
  const [actnStatus, SetActnStatus] = useState("");
  const [actnMsg, SetActnMsg] = useState("");
  const [currentTab, SetCurrentTab] = useState("");
  const [selectedsku, SetSelectedSku] = useState([]);
  const [actnresp, SetActnResp] = useState([]);
  const [pageNo, SetPageNo] = useState(1);
  const [gridcols, SetGridCols] = useState(GridColumns());
  const [status, setStatus] = useState(true);
  const gridRef = useRef();

  /* to open the alert */
  const handleOpen = () => {
    setOpen(true);
  };
  /* to close the alert */
  const handleClose = () => {
    setOpen(false);
  };
  /* get row coloring */

  const getRowStyle = (params) => {
    if (params.node.selected) {
      // return { backgroundColor: "#EBF3FF !important" };
    } else if (params.data.category_flag === 0) {
      return { backgroundColor: "rgb(248, 248, 248) !important" };
    } else {
      return { backgroundColor: "#fff !important" };
    }
  };
  /* get row height */
  const getRowHeight = (params) => {
    return 90;
  };

  useEffect(() => {
    if (gridApi !== undefined && props.gridrows && props.gridrows.length > 0) {
      gridApi.redrawRows();
    }
  });

  useEffect(() => {
    stickyGridHeader();
  }, [status]);

  useEffect(() => {
    if (
      props.selectedTab === "new" &&
      (props.brand.length || props.category.length)
    ) {
      setStatus(false);
    } else if (
      props.selectedTab === "new" &&
      (props.brand.length === 0 || props.category.length === 0)
    ) {
      setStatus(true);
    } else {
      setStatus(false);
    }
    // }
  }, [props]);

  useEffect(() => {
    if (gridApi !== undefined) {
      gridApi.redrawRows();
    }
  }, [props.childIds]);

  const prevActnResp = usePrevious(actnresp);
  const prevPropsActnResp = usePrevious(props.actnresp);
  const prevSelectedStatus = usePrevious(selectedstatus);
  const prevPropsSelectedStatus = usePrevious(props.selectedstatus);
  const prevPropsSelevent = usePrevious(props.selevent);
  const prevPropsSelectedTab = usePrevious(props.selectedTab);

  useEffect(() => {
    if (
      prevPropsActnResp !== props.actnresp ||
      prevPropsActnResp !== prevActnResp
    ) {
      SetActnStatus(props.actionStatus);
      SetActnMsg(props.actionMsg);
      SetSelectedSku(props.selectedsku);
      SetActnResp(props.actnresp);
      SetCurrentTab(props.selectedTab);
      if (gridApi !== undefined) {
        gridApi.redrawRows();
      }
    }
    /* get grid filter valye */
    let gridColumns = gridcols.filter((item) => {
      return (
        item.field !== "referenceprice" &&
        item.headerName !== "Best Reference Price"
      );
    });

    if (
      props.selectedTab === "new" &&
      (props.brand.length || props.category.length)
    ) {
      setStatus(false);
    } else if (
      props.selectedTab === "new" &&
      (props.brand.length === 0 || props.category.length === 0)
    ) {
      setStatus(true);
    } else {
      setStatus(false);
    }

    if (currentTab !== props.selectedTab) {
      debugger;
      let arry = [
        ...gridColumns,
        ...PriceAlertGrid(props.selectedTab, props.selevent),
      ];
      SetGridCols(arry);
      SetCurrentTab(props.selectedTab);
    }
    if (
      prevPropsSelectedStatus !== props.selectedstatus ||
      prevPropsSelectedStatus !== prevSelectedStatus
    ) {
      SetSelectedStatus(props.selectedstatus);
    }
    if (
      prevPropsSelectedTab !== props.selectedTab &&
      document.getElementById("pageNumInputID")
    ) {
      SetPageNo(1);
      document.getElementById("pageNumInputID").value = 1;
    }
    setDealerIdandCityIdVisibil();
  }, [
    gridcols,
    prevActnResp,
    prevPropsActnResp,
    prevSelectedStatus,
    prevPropsSelectedStatus,
    prevPropsSelevent,
    prevPropsSelectedTab,
  ]);

  useEffect(() => {
    debugger;
    let arry = [];
    let check = false;
    if (prevPropsSelevent !== props.selevent) {
      const filds = props.selevent.map((eachItem) => {
        var obj = {};
        obj["headerName"] = eachItem.label;
        obj["field"] = eachItem.value;
        obj["cellClass"] = cellbg;
        obj["cellStyle"] = {
          borderRight: "1px solid #E8E7E6 !important",
          borderBottom: "1px solid #E8E7E6 !important",
          paddingTop: eachItem.label === "Min/Max" ? "20px" : "30px",
        };

        if (eachItem.value === "visibleOnWebsite") {
          obj["cellRenderer"] = "visibleOnWebsite";
        }
        if (eachItem.value === "creationTime") {
          obj["cellRenderer"] = "creationTime";
        }
        if (eachItem.value === "MRP/MOP") {
          obj["cellRenderer"] = "MrpMop";
        }
        if (eachItem.value === "Min/Max") {
          obj["cellRenderer"] = "MinMax";
        }
        if (eachItem.value === "image") {
          check = true;
          obj["cellRenderer"] = "imgComponent";
          obj["cellStyle"] = {
            borderBottom: "1px solid #e8e7e6 !important",
            borderRight: "1px solid #E8E7E6 !important",
          };
        }

        return obj;
      });
      if (currentTab === "pricealert") {
        arry = [
          ...GridColumns(),
          ...filds,
          ...PriceAlertGrid(props.selectedTab),
        ];
      } else {
        arry = [
          ...GridColumns(),
          ...filds,
          // ...[
          //   {
          //     headerName: "Best Reference Price",
          //     field: "best_reference_price",
          //     cellRenderer: "Best Reference Price",
          //     width: 200,
          //     minWidth: 200,
          //     maxWidth: 200,
          //     cellClass: cellbg,
          //     cellStyle: { borderRight: "1px solid lightgrey !important" },
          //   },
          // ],
        ];
      }

      const index = arry.findIndex((item) => item.field === "image");
      if (index >= 0) {
        const element = arry[index];
        arry.splice(index, 1);
        arry.splice(1, 0, element);
      }
      arry = arry.filter(
        (v, i, a) => a.findIndex((v2) => v2.field === v.field) === i
      );
      SetGridCols(arry);
      if (gridApi !== undefined) {
        gridApi.redrawRows();
      }
    }
    setDealerIdandCityIdVisibil();
  }, [props.selevent]);

  const onGridReady = (params) => {
    const { api, columnApi } = params;
    setGridApi(api);
    setGridColumnApi(columnApi);

    params.api.setDomLayout("autoHeight");
    params.columnApi.autoSizeAllColumns();
    if (document.querySelector("#myGrid")) {
      document.querySelector("#myGrid").style.height = "";
    }
    setDealerIdandCityIdVisibil();
  };

  const setDealerIdandCityIdVisibil = () => {
    const delaerClm = gridRef.current.columnApi.getColumn("dealer_id");
    // const cityIdClm = gridRef.current.columnApi.getColumn("cityid");
    const cityNameClm = gridRef.current.columnApi.getColumn("cityname");
    let allcolumns = gridRef.current.columnApi.getAllGridColumns();
    const indexofStatusColumn = allcolumns.findIndex(
      (item) => item.colDef.field == "prod_status"
    );
    const isDealerIdselectesinColumns = props.selevent.some(
      (item) => item.value == "dealer_id"
    );
    // const iscityIdselectesinColumns = props.selevent.some(
    //   (item) => item.value == "cityid"
    // );
    const iscityNameselectesinColumns = props.selevent.some(
      (item) => item.value == "cityname"
    );

    gridRef.current.columnApi.setColumnVisible(
      delaerClm,
      (props.selectedTab == "new" &&
        props.isParentDealer &&
        !props.isIndividualDealer) ||
        isDealerIdselectesinColumns
    );
    // gridRef.current.columnApi.setColumnVisible(
    //   cityIdClm,
    //   (props.selectedTab == "new" &&
    //     props.isParentDealer &&
    //     !props.isIndividualDealer) ||
    //     ((props.selectedTab == "active" || props.selectedTab == "inactive" || props.selectedTab == "pricealert") &&
    //     iscityIdselectesinColumns)
    // );
    gridRef.current.columnApi.setColumnVisible(
      cityNameClm,
      (props.selectedTab == "new" && props.isParentDealer) ||
        iscityNameselectesinColumns
    );

    gridRef.current.columnApi.moveColumns(
      [delaerClm, cityNameClm],
      indexofStatusColumn - 1
    );
  };

  const onSelectionChanged = () => {
    var selectedRows = gridApi.getSelectedRows();
    // if (gridApi !== undefined) {
    //   gridApi.redrawRows();
    // }
    props.getSelectedRow(selectedRows);
    resetSKU({
      dealerId: props.dealerid,
      dealerName: props.dealerName,
      selectedTab: props.selectedTab,
      filter: props.filter,
      pageType: "Price Management",
      dealerType: window.dealer_type,
    });
  };

  props?.gridrows?.map((item) => {
    if (!item.referenceprice) {
      item.referenceprice = 0;
    }
  });

  return (
    <div className="mainGridListContainer">
      <AlertDialog
        open={successAlertOpen}
        close={() => setSuccessAlertOpen(false)}
        errorMessage={alertErrorMessage}
      />
      <div
        id="myGrid"
        className={
          "ag-theme-alpine mainGrid " +
          (props.isGetOffersListLoading ? "hideList" : "")
        }
        style={{
          width: "100%",
        }}
      >
        <AgGridReact
          ref={gridRef}
          singleClickEdit={true}
          columnDefs={gridcols}
          rowData={props?.gridrows}
          defaultColDef={defaultColDef}
          onGridReady={onGridReady}
          rowSelection="multiple"
          suppressPaginationPanel={true}
          pagination={true}
          open={(errorMessage) => {
            setSuccessAlertOpen(true);
            setAlertErrorMessage(errorMessage);
          }}
          undoRedoCellEditing={true}
          onGridColumnsChanged={() =>
            gridColumnApi && gridColumnApi.autoSizeAllColumns()
          }
          props={props}
          state={{
            actnMsg,
            selectedsku,
            actnresp,
            actnStatus,
            rowData: props?.gridrows?.map((a) => ({ ...a })),
          }}
          paginationPageSize={props?.gridrows?.length}
          onSelectionChanged={onSelectionChanged}
          suppressRowClickSelection={true}
          getRowHeight={getRowHeight}
          getRowStyle={getRowStyle}
          frameworkComponents={frameworkComponents}
          tooltipShowDelay={0}
          tooltipHideDelay={5000}
        ></AgGridReact>
        <div key = {props.selectedTab}>
        <Pagination
          totalRecords={props.totalRecords}
          totalItems={props.totalItems}
          isFilterSearch={props.isFilterSearch}
          getSelectedPage={props.getSelectedPage}
          paginationPageSize={10}
          pageNo={pageNo}
          gridApi={gridApi}
          selectedlimit={props.selectedlimit}
        ></Pagination>
        </div>
      </div>
    </div>
  );
};

export default OffersListGrid;
