import React, { useState } from "react";
import { axiospricemgmt } from "../../api/axios";

const VisibleOnWebsite = (props) => {
  const [viewDtails, setViewDtails] = useState({});
  const [showmodal, setShowmodal] = useState(false);
  const callView = (e) => {
    let md5value = props.agGridReact.props.props.md5value;
    let parentDlerId = props.agGridReact.props.props.parentDlerId;
    let rowSelected = props.data;
    let obj = {};
    obj["dealerId"] = rowSelected.dealer_id;
    obj["parentDealerId"] = parentDlerId;
    obj["modelId"] = rowSelected.model_id;
    obj["sku"] = rowSelected.sku;
    obj["offerPrice"] = rowSelected.offer_price;
    document.getElementsByTagName("body")[0].classList.add("loading");
    axiospricemgmt({
      method: "post",
      url: "/offerdetails",
      data: {
        action: "reason",
        pm_key: md5value,
        data: obj,
      },
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then(function (resp) {
        document.getElementsByTagName("body")[0].classList.remove("loading");
        if (resp.data.payload !== null) {
          window.open(resp.data.payload.url);
        } else {
          setViewDtails(resp.data.errorBean);
          setShowmodal(true);
        }
      })
      .catch(function (err) {
        document.getElementsByTagName("body")[0].classList.remove("loading");
      });
  };

  return (
    <div>
      {showmodal ? (
        <div className="vwtooltip">
          <div className="vwtxt">{viewDtails[0].errorMessage}</div>
        </div>
      ) : (
        ""
      )}
      {props.data.visibleOnWebsite === "YES" ? (
        <div>
          <label className="feeprevw" onClick={callView}>
            View URL
          </label>
        </div>
      ) : (
        <div>
          <label className="feeprevw" onClick={callView}>
            View URL
          </label>
        </div>
      )}
    </div>
  );
};
export default VisibleOnWebsite;
