import React, {
  forwardRef,
  useImperativeHandle,
  useMemo,
  useRef,
} from "react";
import "./Stock.css";


const Stock = (props) => {
  const stockValue = useMemo(() => {
    return props.value;
  }, [props.value]);

  return (
    <div className="disp_flex stockDisplayContainer ">
      <div className="stockDisplay">{stockValue}</div>
    </div>
  );
};
export default Stock;

export const StockValueEditor = forwardRef((props, ref) => {
  const inputRef = useRef();

  useImperativeHandle(ref, () => {
    return {
      getValue: () => {
        return inputRef.current.value;
      },
    };
  });
  return (
    <div>
      <input
        id={"stockTextField" + props.rowIndex}
        autoFocus
        className={"stockValue"}
        ref={inputRef}
        defaultValue={props.value}
        onChange={(e) => {
          e.target.value = e.target.value.replace(/[^0-9]/g, "");
        }}
      />
    </div>
  );
});
