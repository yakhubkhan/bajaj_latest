import React from 'react';

const MrpMop = (props) => {
    const mrpval = props.data.selling_price;//this.props.data.selling_price.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",");
    const mopval = (typeof props.data.mop_price === 'string') ? props.data.mop_price.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",") : "";
    return(
        <div>
        <div>{mrpval}</div>
        <hr className="mrpline"></hr>
        <div>{mopval}</div>
    </div>
    )

}
export default MrpMop;