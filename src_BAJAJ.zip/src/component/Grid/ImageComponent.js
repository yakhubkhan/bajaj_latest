import React, { useState, useEffect } from "react";
import ImageGridCostant from "../../utils/ImageGrid";

const ImageComponent = (props) => {
  const [imgsrc, setImgSrc] = useState("");
  useEffect(() => {
    let baseurl = ImageGridCostant();
    setImgSrc(baseurl + props.data.image);
  }, [imgsrc, props]);

  return <img alt="imag" className="img-component" src={imgsrc}></img>;
};
export default ImageComponent;
