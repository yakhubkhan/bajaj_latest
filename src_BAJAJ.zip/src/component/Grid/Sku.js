/* eslint-disable */
import React from "react";

const Sku = (props) => {
  const sku = props.data.sku;
  const { selectedTab } = props.agGridReact.props.props;

  const getTags = () => {
    const new_product = props.data.new_product;

    const isNewTab = selectedTab == "new";
    const isActiveTab = selectedTab == "active";
    const isInActiveTab = selectedTab == "inactive";

    const isExpired = props.data.is_expired == 1;
    const isLowStock = props.data.low_stock_flag == 1;
    const isOutOfStock = props.data.inventory == 0;
    const isHotSelling = props.data.hot_selling == 1;
    const isAutoScaled = props.data.auto_scaled == 1;
    const isDeactivated = props.data.deactivated == 1;

    if (isExpired && (isActiveTab || isInActiveTab)) {
      return (
        <div className="tagsContainer">
        <div className="tagDiv expiredDiv">
          <span className="tagText">Expired SKU</span>
        </div>
        </div>
      );
    } else {
      return (
        <div className="tagsContainer">
          {new_product && isNewTab && (
            <div className="tagDiv newCalelogeDiv">
              <span className="tagText">New Catalogue</span>
            </div>
          )}
          {isLowStock && isActiveTab && (
            <div className="tagDiv lowStockDiv">
              <span className="tagText">Low Stock</span>
            </div>
          )}
          {isOutOfStock && isInActiveTab && (
            <div className="tagDiv lowStockDiv">
              <span className="tagText">Out 0f Stock</span>
            </div>
          )}
          {isHotSelling && (
            <div className="tagDiv hotSellingDiv">
              <span className="tagText">Hot Selling</span>
            </div>
          )}
          {isAutoScaled && isActiveTab && (
            <div className="tagDiv autoScallingDiv">
              <span className="tagText">Auto Scaled</span>
            </div>
          )}
          {isDeactivated && isInActiveTab && (
            <div className="tagDiv autoScallingDiv">
              <span className="tagText">Deactivated</span>
            </div>
          )}
        </div>
      );
    }
  };

  return (
    <div>
      {getTags()}
      <div style={{textAlign: "left", width:'300px'}}>{sku}</div>
    </div>
  );
};
export default Sku;