/* eslint-disable */
import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
} from "react";

export const DeliveryFeeDisplay = (props) => {
  const deliveryFeeValue = useMemo(() => {
    return props.value;
  }, [props.value]);

  return (
    <div className="disp_flex deliveryFeeDisplayContainer ">
      <div className="deliveryFeeDisplay">{deliveryFeeValue}</div>
    </div>
  );
};

export const DeliveryFeeEditor = forwardRef((props, ref) => {
  const inputRef = useRef();

  useEffect(() => {
    inputRef.current.focus();
    const id = "deleveryFeeTextField" + props.rowIndex;
    if (document.getElementById(id)) {
      document.getElementById(id).focus();
    }
  }, []);
  useImperativeHandle(ref, () => {
    return {
      getValue: () => {
        return inputRef.current.value;
      },
    };
  });
  return (
    <div>
      <input
        id={"deleveryFeeTextField" + props.rowIndex}
        autoFocus
        className={"deleveryFee"}
        ref={inputRef}
        defaultValue={props.value}
        onChange={(e) => {
          e.target.value = e.target.value.replace(/[^0-9]/g, "");
        }}
      />
    </div>
  );
});
