/* eslint-disable */
import React, { useState, useEffect } from "react";

const SellerSku = (props) => {
  const [sellerSkuId, setSellerSkuId] = useState("");

  const getSellerSku = (event) => {
    setSellerSkuId(event.target.value);
    props.setValue(event.target.value);
  };

  useEffect(() => {
    if (props.value == null) {
      setSellerSkuId(0);
    } else if (sellerSkuId) {
      setSellerSkuId(sellerSkuId);
    } else {
      setSellerSkuId(props.value);
    }
  }, [sellerSkuId]);

  return (
    <input
      type="text"
      className="stockInput"
      onChange={getSellerSku}
      value={sellerSkuId}
    ></input>
  );
};
export default SellerSku;
