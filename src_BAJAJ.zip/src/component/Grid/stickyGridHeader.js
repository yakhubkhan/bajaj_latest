const stickyGridHeader = () => {
  const listContainer = document.getElementById("myGrid");
  const headerElements = document.getElementsByClassName("ag-header");
  const listHeader = headerElements && headerElements[0];
  var stickyHeaderOffset =
    listContainer && listContainer.getBoundingClientRect().top;

  const bottomScrollElements = document.getElementsByClassName(
    "ag-body-horizontal-scroll"
  );

  if (!document.getElementById("gridHeaderContainer") && listHeader) {
    var parent = listHeader.parentNode;

    const gridHeaderContainer = document.createElement("div");
    const grayTop = document.createElement("div");
    grayTop.id = "grayTop";
    gridHeaderContainer.id = "gridHeaderContainer";
    parent.replaceChild(gridHeaderContainer, listHeader);
    gridHeaderContainer.appendChild(grayTop);
    gridHeaderContainer.appendChild(listHeader);
  }

  const bottomScrollElement = bottomScrollElements && bottomScrollElements[0];
  window.addEventListener("scroll", () => {
    const stickyMainHeaderHeight =
      document.getElementById("stickyMainHeader")?.offsetHeight;
    const headerContainerElement = document.getElementById(
      "gridHeaderContainer"
    );
    stickyHeaderOffset =
      listContainer && listContainer.getBoundingClientRect().top;

    if (window.pageYOffset > stickyHeaderOffset + 250) {
      if (headerContainerElement) {
        headerContainerElement.classList.add("sticky");
        headerContainerElement.style.top = stickyMainHeaderHeight + "px";
      }
    } else {
      headerContainerElement &&
        headerContainerElement.classList.remove("sticky");
    }
    if (
      window.scrollY + window.innerHeight >=
      document.body.scrollHeight - 130
    ) {
      bottomScrollElement &&
        bottomScrollElement.classList.remove("stickyBottom");
    } else {
      bottomScrollElement && bottomScrollElement.classList.add("stickyBottom");
    }
  });
};

export default stickyGridHeader;
