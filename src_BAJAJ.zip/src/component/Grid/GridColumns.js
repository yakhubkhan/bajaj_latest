/* eslint-disable */
export const cellbg = (params) => {
  let classnames = "";
  const bgClr = " whiteColor ";
  const is_expired = params.data.is_expired === 1;
  classnames = (is_expired ? " disableCell " : bgClr) + classnames;

  if (params.colDef.field == "sku") {
    classnames =
      classnames +
      " skuTextStyle skuHeaderClass" +
      (is_expired ? " skuCell" : "");
  }

  if(params.colDef.field != "all") {
    classnames = classnames + " wordWrap";
  }

  if (
    params.colDef.field == "all" ||
    params.colDef.field == "brand" ||
    params.colDef.field == "model_no" ||
    params.colDef.field == "model_code_validation"
  ) {
    classnames = classnames + " justifyContentLeft";
  }

  return classnames;
};

const GridColumns = () => {
  const checkboxSelection = (params) => {
    if (params.columnApi)
      return params.columnApi.getRowGroupColumns().length === 0;
    else return 0;
  };
  let defaultdridcols = [
    {
      headerName: "All",
      field: "all",
      width: 100,
      minWidth: 100,
      maxWidth: 100,
      cellClass: cellbg,
      pinned: "left",
      lockPinned: true,
      lockPosition: true,
      checkboxSelection: checkboxSelection,
      headerCheckboxSelection: checkboxSelection,
      cellStyle: { borderRight: "1px solid #E8E7E6 !important",borderBottom: "1px solid #E8E7E6 !important" },
    },
    {
      headerName: "SKU",
      field: "sku",
      cellClass: cellbg,
      headerClass: "skuHeaderClass",
      resizable: true,
      width: 330,
      minWidth: 330,
      maxWidth: 330,
      cellRenderer: "Sku",
      tooltipField: "sku",
      cellStyle: {
        "text-overflow": "clip",
        "word-wrap": "break-word",
        overflow: "visible",
        "white-space": "normal",
        "user-select": "text",
        "line-height": "15px",
        "font-size": "14px",
        "font-family": "Lato",
        "color": "#231F20",
        "border-right": "1px solid #E8E7E6 !important",
        borderBottom: "1px solid #E8E7E6 !important"
      },
      pinned: "left",
    },
    {
      headerName: "Model ID",
      field: "model_id",
      width: 150,
      minWidth: 150,
      maxWidth: 150,
      cellClass: cellbg,
      cellStyle: {
        paddingTop: "30px",
        borderRight: "1px solid #E8E7E6 !important",
        color: "#8d8882",
        borderBottom: "1px solid #E8E7E6 !important"
      },
    },
    {
      headerName: "OEM Model Code",
      field: "model_code_validation",
      width: 200,
      minWidth: 200,
      maxWidth: 200,
      cellClass: cellbg,
      cellStyle: {
        paddingTop: "30px",
        borderRight: "1px solid #E8E7E6 !important",
        color: "#8d8882",
        borderBottom: "1px solid #E8E7E6 !important"
      },
    },
    {
      headerName: "MRP/MOP",
      field: "MRP/MOP",
      cellRenderer: "MrpMop",
      width: 150,
      minWidth: 150,
      maxWidth: 150,
      cellClass: cellbg,
      cellStyle: {
        paddingTop: "20px",
        borderRight: "1px solid #E8E7E6 !important",
        color: "#707070",
        borderBottom: "1px solid #E8E7E6 !important"
      },
    },
    {
      headerName: "Stock",
      field: "inventory",
      editable: true,
      cellRenderer: "Stock",
      cellEditor: "StockValueEditor",
      width: 150,
      minWidth: 150,
      maxWidth: 150,
      cellClass: cellbg,
      cellStyle: {
        borderRight: "1px solid #E8E7E6 !important",
        borderBottom: "1px solid #E8E7E6 !important"
      },
    },
    {
      headerName: "Price",
      field: "offer_price",
      editable: true,
      cellRenderer: "Price",
      width: 140,
      minWidth: 140,
      maxWidth: 140,
      cellStyle: {
        borderRight: "1px solid #E8E7E6 !important",
        borderBottom: "1px solid #E8E7E6 !important"
      },
      cellClass: cellbg,
    },
    {
      headerName: "Status",
      field: "prod_status",
      cellRenderer: "Status",
      width: 140,
      minWidth: 140,
      maxWidth: 140,
      cellStyle: {
        borderRight: "1px solid #E8E7E6 !important",
        borderBottom: "1px solid #E8E7E6 !important"
      },
      cellClass: cellbg,
    },
    {
      headerName: "Dealer ID",
      field: "dealer_id",
      colId: "dealer_id",
      width: 150,
      minWidth: 150,
      maxWidth: 150,
      cellClass: cellbg,
      cellStyle: {
        borderRight: "1px solid lightgrey !important",
        pointerEvents: "none",
        borderBottom: "1px solid #E8E7E6 !important",
      },
    },
    {
      headerName: "CITY",
      field: "cityname",
      colId: "cityname",
      width: 150,
      minWidth: 150,
      maxWidth: 150,
      cellClass: cellbg,
      cellStyle: {
        borderRight: "1px solid lightgrey !important",
        pointerEvents: "none",
        borderBottom: "1px solid #E8E7E6 !important",
      },
    },
    // {
    //   headerName: "CITYID",
    //   field: "cityid",
    //   colId: "cityid",
    //   width: 150,
    //   minWidth: 150,
    //   maxWidth: 150,
    //   cellClass: cellbg,
    //   cellStyle: {
    //     borderRight: "1px solid lightgrey !important",
    //     pointerEvents: "none",
    //     borderBottom: "1px solid #E8E7E6 !important",
    //   },
    // },
    {
      headerName: "Seller SKU ID",
      field: "seller_sku_id",
      editable: true,
      cellRenderer: "SellerSku",
      width: 150,
      minWidth: 150,
      maxWidth: 150,
      cellStyle: {
        width: "150px !important",
        borderRight: "1px solid #E8E7E6 !important",
        borderBottom: "1px solid #E8E7E6 !important"
      },
      cellClass: cellbg,
    },

    {
      headerName: "Action",
      field: "action",
      cellRenderer: "saveaction",
      width: 150,
      minWidth: 150,
      maxWidth: 150,
      pinned: "right",
      lockPinned: true,
      cellClass: cellbg,
      cellStyle: {
        borderBottom: "1px solid #E8E7E6 !important"
      },
    },
  ];
  return defaultdridcols;
};

export default GridColumns;
