/* eslint-disable */
import CryptoJS from "crypto-js";
import { axiospricemgmt } from "../../api/axios";
import { blankdetails, successresps } from "../../utils/SaveGrid";
import { saveItem } from "../../gtm";
import React from "react";
import { saveActionApi } from "../../utils/apiURLs";

let md5dlerid = CryptoJS.MD5("24");
let md5value = md5dlerid.toString();

const SaveAction = (props) => {
  /* to validate the logistic update */
  const isValidForLogisticUpdate = () => {
    const selectedrowData = props.data;
    selectedrowData.logistics_fee =
      selectedrowData.logistics_by == "Self"
        ? ""
        : selectedrowData.logistics_fee;
    const isValidLogisticBy = selectedrowData.logistics_by;
    const isValidLogisticFee =
      (selectedrowData.logistics_by == "Self" &&
        !selectedrowData.logistics_fee) ||
      (selectedrowData.logistics_by != "Self" &&
        selectedrowData.logistics_fee != "");
    let delivery_fee = parseInt(selectedrowData.delivery_fee);
    delivery_fee = isNaN(delivery_fee) ? "" : delivery_fee;
    const isValidDeliveryFee =
      delivery_fee == "" ||
      delivery_fee == 0 ||
      (delivery_fee > 10 && delivery_fee < 1000);
    const isCategoryFlagValid = selectedrowData.category_flag != 1;

    if (!isCategoryFlagValid && !isValidLogisticBy) {
      props.agGridReact.props.open("Invalid logistic by");
    } else if (!isCategoryFlagValid && !isValidLogisticFee) {
      props.agGridReact.props.open("Invalid logistic Fee");
    } else if (!isValidDeliveryFee) {
      props.data.delivery_fee =
        props.agGridReact.props.state.rowData[props.rowIndex].delivery_fee;
      props.api.redrawRows({
        rowNodes: [props.api.getDisplayedRowAtIndex(props.rowIndex)],
      });

      props.agGridReact.props.open(
        "Delivery fee entered is not in the expected format, please enter only positive numeric values between 11 to 999 or 0"
      );
    }

    return (
      (isCategoryFlagValid && isValidDeliveryFee) ||
      (isValidLogisticBy && isValidLogisticFee && isValidDeliveryFee)
    );
  };
  /* for saving the row after edit */
  const saveRow = (row, e) => {
    let selectedrowData = props.data;
    let md5value = props.agGridReact.props.props.md5value;
    let selectedTab = props.agGridReact.props.props.selectedTab;
    let parentDlerId = props.agGridReact.props.props.parentDlerId;
    let childDealers = props.agGridReact.props.props.childIds;
    let dealerId = props.agGridReact.props.props.dealerid;
    let dealerName = props.agGridReact.props.props.dealerName;
    let filter = props.agGridReact.props.props.filter;
    if (selectedTab === "new") {
      // if (dealerId == parentDlerId && childDealers.length == 0) {
      //   childDealers = [];
      // }
      // if (childDealers.length == 0) {
      childDealers = [selectedrowData.dealer_id];
      // } else {
      //   childDealers = childDealers;
      // }
    } else {
      if (childDealers?.length == 0 && childDealers != parentDlerId) {
        childDealers = [dealerId];
      } else {
        childDealers = [];
      }
    }
    let shouldDoInventoryValidation =
      selectedrowData.prod_status == "inactive" ||
      selectedrowData.prod_status == 2
        ? false
        : true;
    let Inventory =
      selectedrowData.inventory == null
        ? parseInt(0)
        : parseInt(selectedrowData.inventory);
    const oldObj = props.agGridReact.props.state.rowData[props.rowIndex];

    if (
      selectedrowData.offer_price == null ||
      selectedrowData.offer_price == 0 ||
      selectedrowData.prod_status == "" ||
      selectedrowData.prod_status == "selectoption" ||
      selectedrowData.prod_status == null ||
      selectedrowData.inventory == null ||
      selectedrowData.inventory == ""
    ) {
      let resp = blankdetails;
      if (selectedTab === "new") {
        resp.errorBean[0].sku = selectedrowData.sku;
      } else {
        resp.errorBean[0].skuid = selectedrowData.skuid;
      }
      document.getElementsByTagName("body")[0].classList.remove("loading");
      props.agGridReact.props.open("Please fill blank fields");
    } else if (
      (selectedTab === "active" || selectedTab === "inactive") &&
      selectedrowData.inventory == 0 &&
      selectedrowData.prod_status == 1
    ) {
      props.agGridReact.props.open(
        "stock value can't be 0 if status is active"
      );
      props.data.inventory = oldObj.inventory;
      props.api.redrawRows({
        rowNodes: [props.api.getDisplayedRowAtIndex(props.rowIndex)],
      });
    }
    // else if (
    //   (childDealers.length == 0 || childDealers.length > 10) &&
    //   selectedTab === "new"
    // ) {
    //   // let resp = {
    //   //   status: "failed",
    //   //   payload: null,
    //   //   errorBean: [
    //   //     {
    //   //       sku: selectedrowData.sku,
    //   //       errorCode: 6,
    //   //       errorMessage: "Please Choose Dealer Ids to Active.",
    //   //     },
    //   //   ],
    //   // };
    //   var errorMessageText = "Please Choose Dealer Ids to Active.";
    //   // console.log(childDealers);
    //   if (childDealers.length > 10) {
    //     errorMessageText = "Max 10 dealers allowed to activate the offers";
    //   }

    //   document.getElementsByTagName("body")[0].classList.remove("loading");
    //   //comp.setState({ actionMsg: resp.errorBean[0].errorMessage })
    //   // props.agGridReact.props.props.getUpdateddata(
    //   //   "failed",
    //   //   resp.errorBean[0].errorMessage,
    //   //   [],
    //   //   resp.errorBean
    //   // );
    //   props.agGridReact.props.open(errorMessageText);
    // }
    else {
      let selectedstatus = selectedrowData.prod_status;
      if (selectedrowData.prod_status == "active") {
        selectedstatus = "1";
      } else if (selectedrowData.prod_status == "inactive") {
        selectedstatus = "2";
      }
      let action = "";
      let id = "";
      let skuobj = {};
      let skuarr = [];
      if (selectedTab === "new") {
        skuobj["sku"] = selectedrowData.sku;
      } else {
        skuobj["skuid"] = selectedrowData.skuid;
      }
      skuarr.push(skuobj);
      if (selectedrowData.id != null) {
        action = "update";
        id = selectedrowData.id;
      } else {
        action = "insert";
        id = "NULL";
      }

      let data = {
        login_dealerId: window.dealerId,
        dealerId: selectedrowData.dealer_id,
        childDealers: childDealers,
        parentDealerId: parentDlerId,
        id: id,
        sku: selectedrowData.sku,
        modelId: selectedrowData.model_id,
        mop: selectedrowData.mop_price,
        mrp: selectedrowData.selling_price,
        inventory: Inventory,
        offerPrice: selectedrowData.offer_price,
        cic: selectedrowData.cic,
        attribute_set_id: selectedrowData.attribute_set_id,
        reference_price: selectedrowData.referenceprice,
        prod_status: selectedstatus,
        seller_sku_id: selectedrowData.sku + "-" + selectedrowData.dealer_id,
        seller_sku_data: selectedrowData.seller_sku_id,
      };
      let payload = {
        action: action,
        pm_key: md5value,
        data: data,
        dealer_type: window.dealer_type,
      };

      if (window.isLogistic) {
        if (!isValidForLogisticUpdate()) {
          document.getElementsByTagName("body")[0].classList.remove("loading");
          return;
        }
        let delivery_fee = parseInt(selectedrowData.delivery_fee);
        delivery_fee = isNaN(delivery_fee) ? "" : delivery_fee;

        payload = {
          data: {
            sku: selectedrowData.sku,
            dealerId: selectedrowData.dealer_id,
            attribute_set_id: selectedrowData.attribute_set_id,
            logistics_by: selectedrowData.logistics_by,
            logistics_fee: selectedrowData.logistics_fee,
            delivery_fee: delivery_fee,
            cid: selectedrowData.cityid,
            offer_price: selectedrowData.offer_price,
          },
          dealer_type: window.dealer_type,
        };
      }
      document.getElementsByTagName("body")[0].classList.add("loading");

      axiospricemgmt({
        method: "post",
        url: saveActionApi(),
        data: payload,
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then(function (resp) {
          debugger;
          document.getElementsByTagName("body")[0].classList.remove("loading");
          if (resp.data.errorBean === undefined) {
            if (selectedTab === "new") {
              successresps.errorBean[0].skuid =
                selectedrowData.sku + "_" + selectedrowData.dealer_id;
            } else {
              successresps.errorBean[0].skuid = selectedrowData.skuid;
            }
            saveItem({
              dealerId: selectedrowData.dealer_id,
              dealerName: dealerName,
              status: "success",
              item: selectedrowData,
              selectedTab: selectedTab,
              filter: filter,
              pageType: "Price Managment",
              dealerType: window.dealer_type,
            });
            props.agGridReact.props.open();
            props.agGridReact.props.props.getUpdateddata(
              "success",
              successresps.errorBean[0].errorMessage,
              [],
              successresps.errorBean,
              selectedTab
            );
          } else if (resp.data.errorBean[0].errorCode != 10) {
            saveItem({
              dealerId: selectedrowData.dealer_id,
              dealerName: dealerName,
              status: "error",
              item: selectedrowData,
              selectedTab: selectedTab,
              filter: filter,
              pageType: "Price Managment",
              dealerType: window.dealer_type,
            });
            props.agGridReact.props.props.getUpdateddata(
              "failed",
              resp.data.errorBean[0].errorMessage,
              skuarr,
              resp.data.errorBean,
              selectedTab
            );

            if (resp.data.errorBean[0].errorCode == 1 && window.isLogistic) {
              props.data.delivery_fee = oldObj.delivery_fee;
              props.api.redrawRows({
                rowNodes: [props.api.getDisplayedRowAtIndex(props.rowIndex)],
              });
            }

            props.agGridReact.props.open(resp.data.errorBean[0].errorMessage);
          } else {
            saveItem({
              dealerId: selectedrowData.dealer_id,
              dealerName: dealerName,
              status: "error",
              item: selectedrowData,
              selectedTab: selectedTab,
              filter: filter,
              pageType: "Price Managment",
              dealerType: window.dealer_type,
            });

            props.agGridReact.props.props.getUpdateddata(
              "success",
              resp.data.errorBean[0].errorMessage,
              skuarr,
              resp.data.errorBean,
              selectedTab
            );

            props.agGridReact.props.open(resp.data.errorBean[0].errorMessage);
          }
        })
        .catch(function (err) {
          saveItem({
            dealerId: selectedrowData.dealer_id,
            dealerName: dealerName,
            status: "error",
            item: selectedrowData,
            selectedTab: selectedTab,
            filter: filter,
            pageType: "Price Managment",
            dealerType: window.dealer_type,
          });

          document.getElementsByTagName("body")[0].classList.remove("loading");
        });
    }
  };

  return (
    <>
      <button type="button" className="savebtn2W" onClick={saveRow}>
        Save
      </button>
    </>
  );
};
export default SaveAction;
