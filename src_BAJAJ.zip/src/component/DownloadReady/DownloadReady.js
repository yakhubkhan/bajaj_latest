/* eslint-disable */
import React, { useState, useRef, useEffect } from "react";
import "./DownloadReady.css";
import loaderProgressFile from "../../images/loaderProgressFile.png";
import orangeProgress from "../../images/orangeProgress.png";
import orangeTick from "../../images/orangeTick.svg";
import doNotDisturb from "../../images/doNotDisturb.svg";
import useFetch from "../../api/useFetch";
import moment from "moment";
import { getcsvdownloadsApiURL } from "../../utils/apiURLs";
import arrowDown from "../../images/blueArrow.svg";
import arrowUp from "../../images/blueArrowUp.svg";
import bell from "../../component/DownloadReady/Images/bell.png";
import { onDownloadCSV } from "../../gtm";

const DownloadReady = (props) => {
  let container = useRef(null);

  const [showDropdown, setDropdown] = useState(false);
  const [isTimeOut, setIsTimeOut] = useState(false);
  const [showBell, setShowBell] = useState(false);
  const [localData, setLocalData] = useState(localStorage.getItem("flag"));

  const [{ data }, getcsvdownload] = useFetch("POST", "/getcsvdownloads", null);
  var listItems = data?.data?.data;

  /* To hit /getcsvdownloads api  */
  const getCSVData = () => {
    const payload = {
      pm_key: props.pm_key,

      data: {
        dealerId: props.dealerId,
      },
    };
    getcsvdownload(getcsvdownloadsApiURL(), payload);
  };

  useEffect(() => {
    getCSVData();
    window.addEventListener("mousedown", handleClickOutside);
    return () => {
      window.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (props.getFiltersDataResp) {
      getCSVData();
    }
  }, [props.getFiltersDataResp]);

  /* To check is any option is downloaing on progress */
  const isAnyOptionDownloading = (dropDwon) => {
    const index = listItems?.findIndex((item) => item.filename === "");
    return index >= 0;
  };

  useEffect(() => {
    if (data) {
      listItems = data?.data?.data;
      listItems && props.setRequestDownloadResponse(listItems);
      const created_at =  listItems && moment(new Date(listItems[0]?.created_at));
      const current = moment(new Date());
      const minDiff = current.diff(created_at, "minutes");
      const waitingTime =  listItems && listItems[0]?.section === "new_listing" ? 10 : 5;

      if (
        listItems &&
        isAnyOptionDownloading() &&
        created_at &&
        minDiff >= waitingTime
      ) {
        setIsTimeOut(true);
      } else {
        setIsTimeOut(false);
      }

      clearInterval(window.timeIntervel);
      if (isAnyOptionDownloading("data")) {
        setShowBell(true);
        window.timeIntervel = setInterval(() => {
          getCSVData();
        }, 10000);
      } else {
        clearInterval(window.timeIntervel);
      }
    }
  }, [data]);

  /* To display gropdown and hit gtm */
  const displayDownloadReady = () => {
    setDropdown(!showDropdown);
    localStorage.setItem("flag", "true");
    setLocalData(true);
    setShowBell(false);
    onDownloadCSV({
      ListingName: props.selectedTab,
      dealerId: props.dealerid,
      dealerName: props.dealerName,
      eventName: "Download Ready",
      dealerType: window.dealer_type,
      pageType: "Price Management",
      section: "Download offers",
    });
  };

  /* To close dropdown while click on outside */
  const handleClickOutside = (event) => {
    if (container.current && !container.current.contains(event.target)) {
      setDropdown(false);
    }
  };

  /* return date on required format */
  const getFormatedDate = (dateString) => {
    let timeString = moment(new Date(dateString))
      .fromNow()
      .replace("minutes", "min");
    timeString = timeString === "an hour ago" ? "1 hour ago" : timeString;
    return timeString;
  };

  /* To download csv by using URL */
  const downloadFile = (fileName, urlData) => {
    var aLink = document.createElement("a");
    var evt = new MouseEvent("click");
    aLink.download = fileName;
    aLink.href = urlData;
    aLink.dispatchEvent(evt);
  };

  /* On click on Download cta */
  const onClickDownload = (option) => {
    const { filename } = option;
    let csvContent = window.atob(filename);
    downloadFile("OffersCSV.csv", csvContent);
  };

  /* To check is /getcsvdownload response has any empty object */
  const isNotEmptyObject = () => {
    return listItems && listItems.length && listItems[0]?.created_at;
  };

  /* create and return dropdown item div */
  const dropdownItem = (item, index) => {
    const { created_at, filename, file_name } = item;
    const isdownloading = filename === "";

    if (isAnyOptionDownloading() && isTimeOut) {
      return <div className="tryAgain" key = {"dropdownItemTryAgain"+index}>Download in progress, please check in 30 min.</div>;
    }
    return (
      <div className="d-flex dropdownItem" key={"dropdownItem" + index}>
        <div className="d-flex alignCenter">
          {isdownloading ? (
            <img className="itemIcon" src={orangeProgress} alt="cta" />
          ) : (
            <img className="itemIcon" src={orangeTick} alt="cta" />
          )}
          <div className="fileName">
            {isdownloading ? "Download file" : file_name}
          </div>
        </div>
        {isdownloading ? (
          <div className="d-flex">
            <div className="runningTxt">Running...</div>
            <div className="time">{getFormatedDate(created_at)}</div>
          </div>
        ) : (
          <div className="d-flex">
            <div className="downloadBtn" onClick={() => onClickDownload(item)}>
              Download
            </div>
            <div className="time">{getFormatedDate(created_at)}</div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="downloadReady" ref={container}>
      <div>
        <button
          className={`btnwdth download-offers download_ReadyBtn`}
          onClick={displayDownloadReady}
        >
          {isAnyOptionDownloading() && (
            <img className="ctaIcon" src={loaderProgressFile} alt="cta" />
          )}
          {isAnyOptionDownloading() ? "Processing file" : "Download Ready"}
          <img
            height="16px"
            alt="arrow"
            src={!showDropdown ? arrowDown : arrowUp}
            className="download_icon img_pre"
          />
          {(isNotEmptyObject() &&
            showBell &&
            !isAnyOptionDownloading() &&
            !isTimeOut) ||
          localData === "false" ? (
            <img className="bell" src={bell} alt="cta" />
          ) : (
            ""
          )}
        </button>
        {showDropdown && (
          <div className="downloadReadydropdownPanel">
            <div
              className={
                "dropdownContainer" +
                (isNotEmptyObject() && !isTimeOut ? "" : " minLength")
              }
            >
              {isNotEmptyObject() ? (
                listItems?.map((item, index) => {
                  return dropdownItem(item, index);
                })
              ) : (
                <div className="noRecordes">
                  <img
                    className="doNotDistrubIcon"
                    src={doNotDisturb}
                    alt="doNotDisturb"
                  />
                  No Records Found
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DownloadReady;
