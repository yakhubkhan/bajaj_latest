/* eslint-disable */
import React, { useState } from "react";
import Filters from "../Filters/Filters";
import ColumnPrefernces from "../ColumnPreferences/ColumnPrefernces";
import ActionOnSelection from "../ActionOnSelection/ActionOnSelection";
import "./MiddleSections.css";
import SortOptionJs from "../Filters/SortOptionJs";
import DownloadOffers from "../DownloadOffers/DownloadOffers";
import DownloadOffers2W from "../DownloadOffers/DownloadOffers2W";
import * as Constanst from "../../utils/Constant";
const MiddleSection = (props) => {
  const [modalOpen, isOpen] = useState(false);
  const [upload_type, setUploadType] = useState("");
  const openUpload = (name) => {
    isOpen(!modalOpen);
    setUploadType(name === "parent_price" ? name : "");
  };

  const startSkeletonLoader1 = (e) => {
    props.startSkeletonLoader(e);
  };

  const downloadCityCsvData = (downloadMethod) => {
    props.downloadData("normal_download", downloadMethod);
  };

  const downloadHanlder = (selectedData, downloadMethod = null, subSectio) => {
    props.downloadHanlder(selectedData, downloadMethod, subSectio);
  };

  const sendValue = (value) => {
    props.sendCheckboxValue(value);
  };

  const getResponse = (value) => {
    props.sendFileStatus(value);
  };

  const callBrand = (data, cond) => {
    props.parentCallback(data, cond);
  };

  let {
    parentDealerId,
    dealerid,
    isIndividualDealer,
    offer_header_description,
    offer_header_resp,
    offer_header_sample,
    dlerid,
    md5value,
    actnonslctd,
    selectedRow,
    selectedActionResp,
    isFilterApplied,
    cat,
    cic,
    brandFilter,
    cityFilter,
    stateFilter,
    selectedTab,
    searchParam,
    isParentDealer,
    selectedData,
    selectedsku,
    dealerName,
    fileData,
    listdata,
    actnresp,
    actionStatus,
    actionMsg,
    getSelectedRow,
    resetPrice,
    getSelectedStatus,
    onUpdateCallDashBoardApi,
    brand,
    category,
    dashBoardResp,
    resetSaveActionResp,
  } = props;

  return (
    <>
      <div className="filterLabelTitle">
        {(window.isLogistic || window.is2wDealer)
          ? Constanst.priceManagement.filter
          : Constanst.priceManagement.filters}
      </div>
      <div className="disp_flex filtersection">
        <div className="Product">
          <div className="filter">
            <Filters {...props} callFilter={callBrand}></Filters>
          </div>
        </div>
        <div className="offersheet">
          <div className="Product-label">
            {Constanst.priceManagement.offerSheet}
          </div>
          {window.is2wDealer ? (
            <DownloadOffers2W
              csvFileName="Offers.csv"
              dashBoardResp={dashBoardResp}
              selectedTab={selectedTab}
              dlerid={dlerid}
              cat={cat}
              cic={cic}
              dealerid={props.dealerid}
              brandFilter={brandFilter}
              cityFilter={cityFilter}
              stateFilter={stateFilter}
              searchParam={searchParam}
              parentDealerId={parentDealerId}
              md5value={md5value}
              offer_header_description={offer_header_description}
              offer_header_resp={offer_header_resp}
              offer_header_sample={offer_header_sample}
              selectedRow={selectedRow}
              selectedData={selectedData}
              downloadHanlder={downloadHanlder}
              filterApplied={isFilterApplied}
              downloadData={downloadCityCsvData}
              downloadThreholdError={props.downloadThreholdError}
              offersdashboardResp={props.offersdashboardResp}
              startRecords={props.startRecords}
              seconds={props.seconds}
              closeDToolTip={props.closeDToolTip}
              dealerName={dealerName}
              uploadType={upload_type}
              sortopt={props.sortopt}
              selectedPage={props.selectedPage}
              selectedLimit={props.selectedLimit}
              brand={brand}
              isParentDealer={isParentDealer}
              category={category}
              fltersdata={fileData}
              isFilter={props.isFilter}
              sendResponse={getResponse}
              getFiltersDataResp={props.getFiltersDataResp}
            />
          ) : (
            <DownloadOffers
              csvFileName="Offers.csv"
              selectedTab={selectedTab}
              dlerid={dlerid}
              cat={cat}
              cic={cic}
              dealerid={props.dealerid}
              isIndividualDealer = {isIndividualDealer}
              brandFilter={brandFilter}
              cityFilter={cityFilter}
              stateFilter={stateFilter}
              searchParam={searchParam}
              parentDealerId={parentDealerId}
              md5value={md5value}
              offer_header_description={offer_header_description}
              offer_header_resp={offer_header_resp}
              offer_header_sample={offer_header_sample}
              selectedRow={selectedRow}
              selectedData={selectedData}
              downloadHanlder={downloadHanlder}
              filterApplied={isFilterApplied}
              downloadData={downloadCityCsvData}
              downloadThreholdError={props.downloadThreholdError}
              offersdashboardResp={props.offersdashboardResp}
              startRecords={props.startRecords}
              seconds={props.seconds}
              closeDToolTip={props.closeDToolTip}
              dealerName={dealerName}
              uploadType={upload_type}
              sortopt={props.sortopt}
              selectedPage={props.selectedPage}
              selectedLimit={props.selectedLimit}
              brand={brand}
              isParentDealer={isParentDealer}
              category={category}
              fltersdata={fileData}
              sendResponse={getResponse}
              dashBoardResp={dashBoardResp}
              isFilter={props.isFilter}
              getFiltersDataResp={props.getFiltersDataResp}
            />
          )}
        </div>
      </div>
      <section className="sectiontop filter-section">
        <div className="settingLabelTitle">
          {(window.isLogistic || window.is2wDealer)
            ? Constanst.priceManagement.setting
            : Constanst.priceManagement.settings}
        </div>
        <div className="d-flex spaceBtwn becomeBlock">
          <div className="d-flex">
            <ColumnPrefernces
              colPrefs={props.colPrefs}
              selectedTab={props.selectedTab}
              selevent={props.selevent}
              sendValue={sendValue}
              brand={props.brand}
              category={props.category}
              dealerName={props.dealerName}
              dealerid={props.dealerid}
            ></ColumnPrefernces>
            {!window.isLogistic && (
              <div
                className={
                  props.selectedTab === Constanst.priceManagement.new
                    ? "sortoptions-new"
                    : "sortoptions"
                }
              >
                <SortOptionJs
                  options={props.options}
                  brand={props.brand}
                  category={props.category}
                  sortOptChangeFun={props.sortOptChangeFun}
                  selectedTab={props.selectedTab}
                />
              </div>
            )}
            {!(window.is2wDealer && selectedTab === "new") &&
              !window.isLogistic && (
                <ActionOnSelection
                  childIds={dlerid}
                  dealerid={dealerid}
                  parentDlerId={parentDealerId}
                  setIsGetOffersListLoading={props.setIsGetOffersListLoading}
                  md5value={md5value}
                  actnonslctd={actnonslctd}
                  selectedRow={selectedRow}
                  selectedActionResp={selectedActionResp}
                  startSkeletonLoader={(e) => startSkeletonLoader1(e)}
                  selectedsku={selectedsku}
                  selectedTab={selectedTab}
                  gridrows={listdata}
                  actnresp={actnresp}
                  onUpdateCallDashBoardApi={onUpdateCallDashBoardApi}
                  actionStatus={actionStatus}
                  actionMsg={actionMsg}
                  getSelectedRow={getSelectedRow}
                  getSelectedStatus={getSelectedStatus}
                  isParentDealer={isParentDealer}
                  dealerName={dealerName}
                  brand={brand}
                  category={category}
                  resetPrice={resetPrice}
                  resetSaveActionResp={resetSaveActionResp}
                />
              )}
          </div>
        </div>
      </section>
    </>
  );
};

export default MiddleSection;
