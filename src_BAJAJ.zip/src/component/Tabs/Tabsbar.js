/* eslint-disable */
import React from "react";
import "./Tabsbar.css";
import TabItem from "./TabItem";
import newTab from "../../images/newTab.svg";
import activeTab from "../../images/activeTab.svg";
import inActiveListingTab from "../../images/inActiveListingTab.svg";
import priceAlertTab from "../../images/priceAlertTab.svg";

const Tabsbar = (props) => {
  const is2wDealer = window.is2wDealer;
  /* to get list of tab values */
  const getTabValues = (key) => {
    const matchedItem = props.offersdta.find((item) => item[0] === key);
    return matchedItem ? matchedItem[1] : "";
  };

  return (
    <div className="disp_flex tabBarContainer">
      {!is2wDealer && !window.isLogistic && (
        <TabItem
          title="New Listing"
          // count={props.offersdta[0][1]}

          count={
            props.isDisaplyXYformat && props.selectedTab == "new"
              ? props.newSearchRecordCount
              : getTabValues("new")
          }
          newCatalogue={getTabValues("new_catalog") + " New Catalogue"}
          icon={newTab}
          onClick={() => props.clickTab("new")}
          isSelected={"new" == props.selectedTab}
          subTitleColor="#6a1b9a"
          subTitleBgColor="#f9f0ff"
          isDashboardApiLoading = {props.isDashboardApiLoading}
        />
      )}
      {/* 2w Newlist */}

      {is2wDealer && (
        <TabItem
          title="New Listing"
          // count={props.offersdta[0][1]}

          count={
            props.isDisaplyXYformat
              ? props.newSearchRecordCount + "/" + getTabValues("new")
              : getTabValues("new")
          }
          newCatalogue={getTabValues("new_catalog") + " New Catalogue"}
          icon={newTab}
          onClick={() => props.clickTab("new")}
          isSelected={"new" === props.selectedTab}
          subTitleColor="#6a1b9a"
          subTitleBgColor="#f9f0ff"
        />
      )}
      <TabItem
        title="Active Listing"
        count={
          props.isDisaplyXYformat
            ? props.searchActiveRecordsCount + "/" + getTabValues("active")
            : getTabValues("active")
        }
        subTitle={
          window.isLogistic ? "" : getTabValues("lowstock") + " Low Stock"
        }
        expiredSkuTitle={
          window.isLogistic
            ? ""
            : getTabValues("active_expired_sku") + " Expired SKU"
        }
        icon={activeTab}
        onClick={() => props.clickTab("active")}
        isSelected={"active" === props.selectedTab}
        subTitleColor={is2wDealer ? "#3f8dfb" : "#fb9b27"}
        subTitleBgColor={is2wDealer ? "#eef5ff" : "#fff6ec"}
        isDashboardApiLoading = {props.isDashboardApiLoading}
      />
      {!window.isLogistic && (
        <TabItem
          title="Inactive Listing"
          count={
            props.isDisaplyXYformat
              ? props.searchInActiveRecordsCount +
                "/" +
                getTabValues("inactive")
              : getTabValues("inactive")
          }
          subTitle={getTabValues("outofstock") + " Out of Stock"}
          expiredSkuTitle={
            getTabValues("inactive_expired_sku") + " Expired SKU"
          }
          icon={inActiveListingTab}
          onClick={() => props.clickTab("inactive")}
          isSelected={"inactive" === props.selectedTab}
          subTitleColor={"#d5b30e"}
          subTitleBgColor={"#fffbef"}
        />
      )}
      {!is2wDealer && !window.isLogistic && (
        <TabItem
          title="Price Alert"
          count={
            props.isDisaplyXYformat
              ? props.pricAlertSearchCount + "/" + getTabValues("pricealert")
              : getTabValues("pricealert")
          }
          icon={priceAlertTab}
          onClick={() => props.clickTab("pricealert")}
          isSelected={"pricealert" === props.selectedTab}
          subTitleColor="#fa4d56"
          subTitleBgColor="#fff4f5"
        />
      )}
    </div>
  );
};

export default Tabsbar;
