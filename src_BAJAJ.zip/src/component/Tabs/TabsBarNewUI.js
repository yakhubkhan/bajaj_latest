/* eslint-disable */
import React from "react";
import "./Tabsbar.css";
import TabItemWithTags from "./TabItemWithTags";
import newTab from "../../images/newTab.svg";
import activeTab from "../../images/activeTab.svg";
import inActiveListingTab from "../../images/inActiveListingTab.svg";
import priceAlertTab from "../../images/priceAlertTab.svg";

const TabsBarNewUI = (props) => {
  console.log("downloadPayloadData", props);
  const is2wDealer = window.is2wDealer;

  const getTabValues = (key) => {
    const matchedItem = props.offersdta.find((item) => item[0] == key);
    return matchedItem ? matchedItem[1] : "";
  };

  return (
    <div className="disp_flex tabBarContainer">
      <TabItemWithTags
        title="New Listing"
        // count={props.offersdta[0][1]}
        count={
          props.isDisaplyXYformat && props.selectedTab == "new"
            ? props.newSearchRecordCount
            : getTabValues("new")
        }
        subTitle={is2wDealer ? "100" + " New Launch" : ""}
        newCatalogue={getTabValues("new_catalog") + " New Catalogue"}
        icon={newTab}
        changeTag={(val) => props.changeTag(val)}
        onClick={() => props.clickTab("new")}
        isSelected={"new" == props.selectedTab}
        selectedTab={props.selectedTab}
        selectedTag={props.selectedTag}
        subTitleColor="#6a1b9a"
        subTitleBgColor="#f9f0ff"
        imgColor="#f9efff"
        tabsData={props.downloadPayloadData}
        hotsellingData={props.downloadPayloadData.hotselling_new}
      />
      <TabItemWithTags
        title="Active Listing"
        // count={props.offersdta[1][1]}
        count={
          props.isDisaplyXYformat
            ? props.searchActiveRecordsCount + "/" + getTabValues("active")
            : getTabValues("active")
        }
        subTitle={
          window.isLogistic ? "" : getTabValues("lowstock") + " Low Stock"
        }
        expiredSkuTitle={
          window.isLogistic
            ? ""
            : getTabValues("active_expired_sku") + " Expired SKU"
        }
        icon={activeTab}
        onClick={() => props.clickTab("active")}
        changeTag={(val) => props.changeTag(val)}
        isSelected={"active" == props.selectedTab}
        subTitleColor={is2wDealer ? "#3f8dfb" : "#fb9b27"}
        subTitleBgColor={is2wDealer ? "#eef5ff" : "#fff6ec"}
        imgColor="#ecfcf1"
        selectedTab={props.selectedTab}
        selectedTag={props.selectedTag}
        tabsData={props.downloadPayloadData}
        hotsellingData={props.downloadPayloadData.hotselling_active}
      />
      <TabItemWithTags
        title="Inactive Listing"
        // count={props.offersdta[2][1]}
        count={
          props.isDisaplyXYformat
            ? props.searchInActiveRecordsCount + "/" + getTabValues("inactive")
            : getTabValues("inactive")
        }
        subTitle={getTabValues("outofstock") + " Out of Stock"}
        expiredSkuTitle={getTabValues("inactive_expired_sku") + " Expired SKU"}
        icon={inActiveListingTab}
        onClick={() => props.clickTab("inactive")}
        changeTag={(val) => props.changeTag(val)}
        isSelected={"inactive" == props.selectedTab}
        subTitleColor={is2wDealer ? "#fa4d56" : "#d5b30e"}
        subTitleBgColor={is2wDealer ? "#fff4f5" : "#fffbef"}
        imgColor="#fff6ec"
        selectedTab={props.selectedTab}
        selectedTag={props.selectedTag}
        tabsData={props.downloadPayloadData}
        hotsellingData={props.downloadPayloadData.hotselling_inactive}
      />
      <TabItemWithTags
        title="Price Alert"
        count={
          // getTabValues("pricealert")}

          props.isDisaplyXYformat
            ? props.pricAlertSearchCount + "/" + getTabValues("pricealert")
            : getTabValues("pricealert")
        }
        // subTitle={props.offersdta[4][1] + " Out of Stock"}
        icon={priceAlertTab}
        changeTag={(val) => props.changeTag(val)}
        onClick={() => props.clickTab("pricealert")}
        isSelected={"pricealert" == props.selectedTab}
        subTitleColor="#fa4d56"
        subTitleBgColor="#fff4f5"
        imgColor="#fff0f0"
        selectedTab={props.selectedTab}
        selectedTag={props.selectedTag}
        tabsData={props.downloadPayloadData}
        hotsellingData={props.downloadPayloadData.hotselling_pricealert}
      />
    </div>
  );
};

export default TabsBarNewUI;
