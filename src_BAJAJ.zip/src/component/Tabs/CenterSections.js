/* eslint-disable */
import React from "react";
import "../../css/dx.common.css";
import "../../css/dx.light.css";
import "../../css/custom.css";
import MiddleSection from "../MiddleSection/MiddleSection";

const CenterSections = (props) => {
  const sendValue = (value) => {
    props.sendCheckboxValue(value);
  };
  return (
    <>
      <div className="sectionmiddle">
        <MiddleSection
          {...props}
          selevent={props.selevent}
          brand={props.brand}
          category={props.category}
          sendValue={sendValue}
          isFilter={props.isFilter}
          getFiltersDataResp={props.getFiltersDataResp}
        ></MiddleSection>
      </div>
    </>
  );
};

export default CenterSections;
