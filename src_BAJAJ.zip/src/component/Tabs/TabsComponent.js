/* eslint-disable */
import React, { useEffect, useState } from "react";
import "./TabComponent.css";
import { PulseLoader } from "react-spinners";
import AgGridLoader from "../SkeletonLoaders/AgGridLoader";
import FullPageLoader from "../SkeletonLoaders/FullPageLoader";
import TabLoader from "../SkeletonLoaders/TabsLoader";
import uploadedOfferHeader, {
  getArrangedData,
  getArrangedLogisticData,
  getArranged2wData,
  downloadCallback,
  uploadedOfferHeaderLogistics,
  uploadedOfferHeader2w,
  convertToLabelValueObjs,
} from "../../utils/CommonServices";
import "../../css/dx.common.css";
import "../../css/dx.light.css";
import "../../css/custom.css";
import ResponseMessage from "../ResponseMessage/ResponseMessage";
import * as Constants from "../../utils/Constant";
import Tabsbar from "./Tabsbar";
import TabsBarNewUI from "./TabsBarNewUI";
import Agreement from "./Agreement";
import CenterSections from "./CenterSections";
import useFetch from "../../api/useFetch";
import {
  selectCTA,
  searchTerm,
  sortSKU,
  onclickLevel2HeaderOptionGTM,
} from "../../gtm";
import Header from "../../Pages/Header";
import Level2Header from "../../Pages/Level2Header";
import {
  dashboardApi,
  getFilterApiURL,
  getofferListApiURL,
} from "../../utils/apiURLs";
import Grid from "./Grid";

const TabsComponent = (props) => {
  const [offersdta, setOffersdta] = useState([]);
  const [activetab, setActivetab] = useState(false);
  const [sortOpts, setSortOpts] = useState([]);
  const [colPrefs, setColPrefs] = useState([]);
  const [actnonslctd, setActnonslctd] = useState([]);
  const [listdata, setListdata] = useState([]);
  const [logisticsData, setLogisticsData] = useState([]);
  const [defaultColValues, setDefaultColValues] = useState([]);
  const [selval, setSelval] = useState("");
  const [selectedRow, setSelectedRow] = useState([]);
  const [actionStatus, setActionStatus] = useState("");
  const [actionMsg, setActionMsg] = useState("");
  const [fltersdata, setFltersdata] = useState({});
  const [categoryOpts, setCategoryOpts] = useState([]);
  const [cicOpts, setCicOpts] = useState([]);
  const [dealerOpts, setDealerOpts] = useState([]);
  const [brandOpts, setBrandOpts] = useState([]);
  const [cityOpts, setCityOpts] = useState([]);
  const [stateOpts, setStateOpts] = useState([]);
  const [selevent, setSelevent] = useState([]);
  const [selectedTab, setSelectedTab] = useState("active");
  const [searchParam, setSearchParam] = useState("");
  const [selectedPage, setSelectedPage] = useState(1);
  const [selectLimit, setSelectedLimit] = useState(10);
  const [selectedsku, setSelectedsku] = useState([]);
  const [isGetOffersListLoading, setIsGetOffersListLoading] = useState(false);
  const [isCsvError, setIsCsvError] = useState(false);
  const [downloadOffersData, setDownloadOffersData] = useState([]);
  const [newListing, setNewListing] = useState([]);
  const [activeListing, setActiveListing] = useState([]);
  const [inactiveListing, setInactiveListing] = useState([]);
  const [allListing, setAllListing] = useState([]);
  const [lowStock, setLowStock] = useState([]);
  const [outOfStock, setOutOfStock] = useState([]);
  const [downloadPayloadData, setDownloadPayloadData] = useState([]);
  const [actnresp, setActnresp] = useState([]);
  const [selectedstatus, setSelectedstatus] = useState([]);
  const [cat, setCat] = useState([]);
  const [cic, setCic] = useState([]);
  const [dlerid, setDlerid] = useState([]);
  const [brandFilter, setBrandFilter] = useState([]);
  const [cityFilter, setCityFilter] = useState([]);
  const [stateFilter, setStateFilter] = useState([]);
  const [sortopt, setSortopt] = useState("");
  const [actionErr, setActionErr] = useState(false);
  const [totalRecords, setTotalRecords] = useState(0);
  const [lowStockSearchRecordsCount, setLowStockSearchRecordsCount] =
    useState(0);
  const [outofStockSearchRecordsCount, setOutofStockSearchRecordsCount] =
    useState(0);
  const [searchActiveRecordsCount, setSearchActiveRecordsCount] = useState(0);
  const [searchInActiveRecordsCount, setSearchInActiveRecordsCount] =
    useState(0);
  const [pricAlertSearchCount, setPricAlertSearchCount] = useState(0);
  const [newSearchCount, setNewSearchCount] = useState(0);
  const [startRecords, setStartRecords] = useState(1);
  const [parentDealerId, setParentDealerId] = useState("");
  const [prodTitle, setProdTitle] = useState("");
  const [isFilter, setIsFilter] = useState(false);
  const [isFilterApplied, setIsFilterApplied] = useState(false);
  const [searchRecords, setSearchRecords] = useState(0);
  const [isFilterSearch, setIsFilterSearch] = useState(false);
  const [downloadError, setDownloadError] = useState(false);
  const [selectedTag, setSelectedTag] = useState();
  const [resetFilter, setResetFilter] = useState(false);
  const [isParentDealer, setIsParentDealer] = useState(false);
  const [downloadMethod, setDownloadMethod] = useState("");
  const [downloadThreholdError, setDownloadThreholdError] = useState(false);
  const [offer_header_description, setOffer_header_description] = useState([]);
  const [offer_header_sample, setOffer_header_sample] = useState([]);
  const [offer_header_resp, setOffer_header_resp] = useState([]);
  const [seconds, setSeconds] = useState(15);
  const [totalItems, setTotalItems] = useState(0);
  const [priceAlert, setPriceAlert] = useState([]);
  const [selectedData, setSelectedData] = useState([]);
  const [fileData, setFileData] = useState({});
  const [isIndividualDealer, setIsIndividualDealer] = useState(false);
  const [is_download_expired, setIs_download_expired] = useState(false);
  const [isDashBoadLoading, setIsDashBoadLoading] = useState(false);
  const [brand, setBrand] = useState([]);
  const [category, setCategory] = useState([]);
  const [downloadType, setDownloadType] = useState("");
  // const filterElement = React.createRef();
  const [status, setStatus] = useState(false);

  const dealerid = props.dealerId;
  const { supplierName } = props;

  const [{ data, isLoading, error }, fetchData, offersdashboardApiExtraObj] =
    useFetch("POST", "/offersdashboard/" + window.dealerId, null);

  const [getofferslistDataResp, fetchGetofferslistData, extraObj] = useFetch(
    "POST",
    "/getofferslist",
    null
  );

  const [getFiltersDataResp, fetchFiltersData, filtersDataExtraObj] = useFetch(
    "POST",
    "/getfilters",
    null
  );

  useEffect(() => {
    callDashBoardApi();
    filterApi([], [], [], [], [], [], false);
    // callOffersListApi(
    //   dealerid,
    //   seltab,
    //   [],
    //   [],
    //   [],
    //   [],
    //   [],
    //   [],
    //   searchParam,
    //   "",
    //   1,
    //   10,
    //   false,
    //   data?.parentDealerId
    // );
    // // setSelectedTab(seltab);
    // // setSelectedPage(1);
    // callFiltersApi(
    //   dealerid,
    //   seltab,
    //   [],
    //   [],
    //   [],
    //   [],
    //   [],
    //   [],
    //   searchParam,
    //   data?.parentDealerId
    // );
  }, [window.isLogistic]);

  useEffect(() => {
    debugger;
    setColPrefs(
      window.is2wDealer
        ? Constants.colPreferences2W
        :       Constants.colPreferences(
          selectedTab,
          props.isParentDealer,
          isIndividualDealer
        )
    );
  }, [selectedTab,isIndividualDealer]);

  useEffect(() => {
    if (error) {
      setIsDashBoadLoading(false);
    }
  }, [error]);

  const downloadHanlder = (selectedData, downloadMethod = null, subSection) => {
    if (selectedData.length > 0) {
      setIsFilter(true);
      setIsFilterApplied(false);
      setSelectedData(selectedData);
      if (downloadMethod != null) {
        if (downloadMethod != "normal_download") {
          if (
            selectedTab == downloadMethod ||
            downloadMethod == "new_listing" ||
            window.isLogistic
          ) {
            processDownloadCsv(selectedData, true, subSection);
          } else {
            downloadCityCsvDataFunc("normal_download", downloadMethod);
          }
        } else {
          processDownloadCsv(selectedData, true, subSection);
        }
      } else {
        processDownloadCsv(selectedData, false, subSection);
      }
    }
  };

  const getDataForCSV = (offersData, subSection) => {
    if (window.isLogistic) {
      return getArrangedLogisticData(
        offersData,
        props.getmagentodeliveryflagResp
      );
    } else if (window.is2wDealer) {
      return getArranged2wData(offersData);
    } else {
      return getArrangedData(offersData, subSection);
    }
  };

  const processDownloadCsv = (offers, isDownload = false, subSection) => {
    let offersData = selectedRow.length > 0 ? selectedRow : offers;
    var arrangeData = [];
    if (is_download_expired == true) {
      offersData = offersData.filter((item) => item.is_expired === 1);
    } else {
      offersData = offersData.filter(
        (item) => item.is_expired === 0 || !item.is_expired
      );
    }
    if (offersData.length > 0) {
      arrangeData = getDataForCSV(offersData, subSection);

      var ofs = "";
      var ofd = "";
      if (window.isLogistic) {
        ofs = offer_header_resp.logistic_header_sample;
        ofd = offer_header_resp.logistic_header_description;

        ofs = uploadedOfferHeaderLogistics(ofs, true);
        ofd = uploadedOfferHeaderLogistics(ofd, true);
      } else if (window.is2wDealer) {
        ofs = offer_header_resp.offer_2w_header_sample;
        ofd = offer_header_resp.offer_2w_header_description;

        ofs = uploadedOfferHeader2w(ofs, true);
        ofd = uploadedOfferHeader2w(ofd, true);
      } else {
        if (subSection == "price") {
          ofs = offer_header_resp.offer_price_header_sample;
          ofd = offer_header_resp.offer_price_header_description;
        } else if (subSection == "status_inventory") {
          ofs = offer_header_resp.offer_status_inventory_header_sample;
          ofd = offer_header_resp.offer_status_inventory_header_description;
        } else if (subSection == "installation_charges") {
          ofs = offer_header_resp.offer_installation_charges_header_sample;
          ofd = offer_header_resp.offer_installation_charges_header_description;
        } else {
          ofs = offer_header_resp.offer_header_sample;
          ofd = offer_header_resp.offer_header_description;
        }
        ofs = uploadedOfferHeader(ofs, true, false, subSection);
        ofd = uploadedOfferHeader(ofd, true, false, subSection);
      }

      arrangeData.unshift(ofs);
      arrangeData.unshift(ofd);
    }
    if (isDownload) {
      if (arrangeData.length >= 60000) {
        setDownloadThreholdError(true);
      } else if (arrangeData.length == 0) {
        setStartRecords(0);
        setSeconds(15);
      } else {
        setDownloadOffersData(arrangeData);
        if (arrangeData == null) {
          setStartRecords(0);
          setSeconds(15);
        } else {
          downloadCallback(downloadType, arrangeData, subSection);
        }
      }
    } else {
      setDownloadOffersData(arrangeData);
    }
  };

  useEffect(() => {
    if (data) {
      setIsDashBoadLoading(false);
      if (!offersdashboardApiExtraObj?.isFromUpdateDashboard) {
        setDownloadPayloadData(data?.payload);
        setIsFilter(false);
        setIsParentDealer(data?.isParentDealer);
        setOffer_header_description(
          data?.header_description?.offer_header_description
        );
        setOffer_header_resp(data?.header_description);
        setOffer_header_sample(data?.header_description.offer_header_sample);
        setParentDealerId(data?.parentDealerId);
        setProdTitle(data?.SUPPLIERDESC);
        data && setOffersdta(Object.entries(data.payload));

        let seltab = "";
        let limit = data?.payload.active ? data?.payload.active : 10;
        // if (
        //   Object.keys(data.payload).map((val, ind) => {
        //     if (val == "active") {
        //       seltab = val;
        //     }
        //   })
        // )
        //   callOffersListApi(
        //     dealerid,
        //     seltab,
        //     [],
        //     [],
        //     [],
        //     [],
        //     [],
        //     [],
        //     searchParam,
        //     "",
        //     1,
        //     10,
        //     false,
        //     data.parentDealerId
        //   );
        // setSelectedTab(seltab);
        setSelectedPage(1);
        // callFiltersApi(
        //   dealerid,
        //   seltab,
        //   [],
        //   [],
        //   [],
        //   [],
        //   [],
        //   [],
        //   searchParam,
        //   data.parentDealerId
        // );
      } else {
        setOffersdta(Object.entries(data?.payload));
        // setLowStockSearchRecordsCount(data?.payload.lowstock);
        // setOutofStockSearchRecordsCount(data?.payload.outofstock);
        // setSearchActiveRecordsCount(data?.payload.active);
        // setSearchInActiveRecordsCount(data?.payload.inactive);
        // setNewSearchCount(data?.payload.new);
        // //setTotalRecords(data?.payload);
        // setPricAlertSearchCount(data?.payload.pricealert);
        setParentDealerId(data?.parentDealerId);
        setIsFilterSearch(false);
        setProdTitle(data?.SUPPLIERDESC);
        // callOffersListApi(
        //   dealerid,
        //   selectedTab,
        //   cat,
        //   cic,
        //   dlerid,
        //   brandFilter,
        //   cityFilter,
        //   stateFilter,
        //   searchParam,
        //   "",
        //   1,
        //   selectLimit,
        //   false,
        //   data.parentDealerId
        // );
      }
    }
  }, [data]);

  const callDashBoardApi = () => {
    setIsDashBoadLoading(true);
    fetchData(dashboardApi(), {
      pm_key: props.md5value,
      dealerId: dealerid,
    });
    setAcctionList();
    //setActnonslctd(Constants.actnonslctd);
    setSortOpts(Constants.sortOptions);
    setColPrefs(
      window.is2wDealer ? Constants.colPreferences2W : Constants.colPreferences(
        selectedTab,
        props.isParentDealer,
        isIndividualDealer
      )
    );
    setDefaultColValues(Constants.selectedArr);
    setIsGetOffersListLoading(true);
  };

  const setAcctionList = (val) => {
    if (window.is2wDealer) {
      setActnonslctd(Constants.actnonslctd2W);
    } else {
      // setActnonslctd(Constants.actnonslctd);
      setActnonslctd(
        val == "new" ? Constants.actnonslctdNew : Constants.actnonslctd
      );
    }
  };

  useEffect(() => {
    if (getofferslistDataResp.data) {
      const format = /[^!@#$%&*()_|+\-=:'" ,.<>\r\n|\n|\r\{\}\[\]\\\/\w ]/g;
      getofferslistDataResp.data = JSON.parse(JSON.stringify(getofferslistDataResp.data).replace(format,''))
      if (getofferslistDataResp.data?.payload?.offers.length == 0 && selectedPage < 5 && selectedTab == "new") {
        const page = selectedPage + 1;
        setSelectedPage(page);
        getSelectedPage(page,20)
        return
      }
      if (getofferslistDataResp.data?.payload?.offers) {
        getofferslistDataResp.data.payload.offers =
          getofferslistDataResp.data?.payload.offers.slice(0, selectLimit);
      }
      if (extraObj.isDownload) {
        switch (extraObj.section) {
          case "all":
            setAllListing(getofferslistDataResp.data?.payload.offers);
            break;
          case "new":
            setNewListing(getofferslistDataResp.data?.payload.offers);
            break;
          case "inactive":
            setInactiveListing(getofferslistDataResp.data?.payload.offers);
            break;
          case "active":
            setActiveListing(getofferslistDataResp.data?.payload.offers);
            break;
          case "lowstock":
            setLowStock(getofferslistDataResp.data?.payload.offers);
            break;
          case "outofstock":
            setOutOfStock(getofferslistDataResp.data?.payload.offers);
            break;
          case "pricealert":
            setPriceAlert(getofferslistDataResp.data?.payload.offers);
            break;
          case "default":
            break;
        }
        if (getofferslistDataResp.data?.totalRecords > 300000) {
          setDownloadThreholdError(true);
        } else {
          processDownloadCsv(getofferslistDataResp.data?.payload.offers, true);
          let totalPages = 0;
          setTotalItems(totalPages);
          if (
            getofferslistDataResp.data?.totalRecords > 0 &&
            getofferslistDataResp.data?.totalRecords <= 10
          ) {
            totalPages = 1;
            setTotalItems(totalPages);
          } else {
            let perPagerecords = getofferslistDataResp.data?.totalRecords / 10; //divide by records per page,configured in OffersLIstGrid
            totalPages = Math.ceil(perPagerecords);
          }

          setTotalRecords(totalPages);
          setTotalItems(getofferslistDataResp.data?.totalRecords);
          setDownloadThreholdError(false);
        }
        if (extraObj.srch.length > 0) {
          setLowStockSearchRecordsCount(
            getofferslistDataResp.data?.lowStockSearchRecordsCount
          );
          setOutofStockSearchRecordsCount(
            getofferslistDataResp.data?.outofStockSearchRecordsCount
          );
          setSearchActiveRecordsCount(
            getofferslistDataResp.data?.searchActiveRecordsCount
          );
          setSearchInActiveRecordsCount(
            getofferslistDataResp.data?.searchInActiveRecordsCount
          );
          setPricAlertSearchCount(
            getofferslistDataResp.data?.pricAlertSearchCount
          );
          setNewSearchCount(getofferslistDataResp.data?.newSearchRecordCount);
          setSearchRecords(getofferslistDataResp.data?.totalRecords);
        }
      } else {
        const isNeedsToDisplayXCountInTabs =
          extraObj?.srch.length > 0 || extraObj.isFilterable;
        setLowStockSearchRecordsCount(
          isNeedsToDisplayXCountInTabs
            ? getofferslistDataResp.data?.lowStockSearchRecordsCount
            : 0
        );
        setOutofStockSearchRecordsCount(
          isNeedsToDisplayXCountInTabs
            ? getofferslistDataResp.data?.outofStockSearchRecordsCount
            : 0
        );
        setSearchActiveRecordsCount(
          isNeedsToDisplayXCountInTabs
            ? getofferslistDataResp.data?.searchActiveRecordsCount
            : 0
        );
        setNewSearchCount(
          isNeedsToDisplayXCountInTabs
            ? getofferslistDataResp.data.newSearchRecordCount
            : 0
        );

        setSearchInActiveRecordsCount(
          isNeedsToDisplayXCountInTabs
            ? getofferslistDataResp.data?.searchInActiveRecordsCount
            : 0
        );
        setPricAlertSearchCount(
          isNeedsToDisplayXCountInTabs
            ? getofferslistDataResp.data?.pricAlertSearchCount
            : 0
        );
        setNewSearchCount(
          isNeedsToDisplayXCountInTabs
            ? getofferslistDataResp.data?.newSearchRecordCount
            : 0
        );
        isNeedsToDisplayXCountInTabs &&
          setSearchRecords(getofferslistDataResp.data?.totalRecords);

        const getBackPrevSelectedRows =
          getofferslistDataResp.data?.payload?.offers.filter((item) =>
            selectedRow.some(
              (selectedSkueach) =>
                selectedSkueach.skuid == item.skuid &&
                selectedSkueach.sku == item.sku &&
                selectedSkueach.model_id == item.model_id &&
                selectedSkueach.cityid == item.cityid
            )
          );
        setListdata(getofferslistDataResp.data?.payload?.offers);
        setSelectedRow(getBackPrevSelectedRows);
        let totalPages = 0;
        if (
          getofferslistDataResp.data?.totalRecords > 0 &&
          getofferslistDataResp.data?.totalRecords <= 10
        ) {
          totalPages = 1;
        } else {
          let perPagerecords = getofferslistDataResp.data?.totalRecords / 10; //divide by records per page,configured in OffersLIstGrid
          totalPages = Math.ceil(perPagerecords);
          setTotalItems(getofferslistDataResp.data?.totalRecords);
        }

        setTotalRecords(totalPages);
        setSearchRecords(getofferslistDataResp.data?.totalRecords);
        setTotalItems(getofferslistDataResp.data?.totalRecords);

        if (getofferslistDataResp.data?.totalRecords == 0) {
          setStartRecords(0);
          setSeconds(15);
        } else {
          setStartRecords(1);
        }
      }
      setIsGetOffersListLoading(false);
    }
  }, [getofferslistDataResp.data]);

  useEffect(() => {
    if (getofferslistDataResp.error) {
      setDownloadThreholdError(true);
      setIsGetOffersListLoading(false);
    }
  }, [getofferslistDataResp.error]);

  const isAnyFilterApplied = () => {
    return (
      cat.length > 0 ||
      cic.length > 0 ||
      dlerid.length > 0 ||
      brandFilter.length > 0 ||
      cityFilter.length > 0 ||
      stateFilter.length > 0
    );
  };

  const callOffersListApi = (
    dealerid,
    section,
    cat,
    cic,
    id,
    brandFilter,
    cityFilter,
    stateFilter,
    srch,
    sortOptn,
    page,
    limit,
    isDownload,
    parentDlerId,
    isFilterable = false
  ) => {
    if (section == "pricealert") {
      if (sortOptn == "") {
        sortOptn = "price_percent";
      }
    }
    fetchGetofferslistData(
      getofferListApiURL(),
      {
        pm_key: props.md5value,
        data: {
          dealerId: dealerid,
          parentDealerId: parentDlerId,
          sort: sortOptn,
          page: page,
          limit: limit,
          section: section,
          filters: {
            search: srch,
            category: cat,
            cic: cic,
            childDealerId: id,
            brand: brandFilter,
            city: cityFilter,
            state: stateFilter,
          },
        },
      },

      {
        isDownload,
        section,
        srch,
        isFilterable:
          cat.length > 0 ||
          cic.length > 0 ||
          id.length > 0 ||
          brandFilter.length > 0 ||
          cityFilter.length > 0 ||
          stateFilter.length > 0,
      }
    );
  };

  useEffect(() => {
    if (getFiltersDataResp.data) {
      setFileData(getFiltersDataResp.data.payload.filters);
      const childDealers =
        getFiltersDataResp.data?.payload?.filters?.childDealers || [];
      const uncheckedChildDealers =
        getFiltersDataResp.data?.payload?.allfilters?.uncheckedChildDealers ||
        [];
      const allChildDealers = [...childDealers, ...uncheckedChildDealers];
      setIsIndividualDealer(
        allChildDealers &&
          allChildDealers.length == 1 &&
          allChildDealers[0] == window.dealerId
      );

      getDropdownOptions(
        getFiltersDataResp.data?.payload.filters,
        getFiltersDataResp.data?.payload.allfilters
      );
    }
  }, [getFiltersDataResp.data]);

  const callFiltersApi = (
    dealerId,
    section,
    category,
    cic,
    dealerid,
    brandFilter,
    cityFilter,
    stateFilter,
    srch,
    parentDlerId
  ) => {
    fetchFiltersData(getFilterApiURL(), {
      pm_key: props.md5value,
      data: {
        dealerId: dealerId,
        parentDealerId: parentDlerId,
        section: section,
        activeFilters: {
          search: srch,
          category: category,
          cic: cic,
          childDealerId: dealerid,
          brand: brandFilter,
          city: cityFilter,
          state: stateFilter,
        },
      },
    });
  };

  const closeDToolTip = () => {
    // setDownloadThreholdError(false);
  };

  const onUpdateCallDashBoardApi = () => {
    let comp = this;
    var data = { data: { dealerId: dealerid } };

    fetchData(
      dashboardApi(),
      {
        pm_key: props.md5value,
        dealerId: dealerid,
      },
      {
        isFromUpdateDashboard: true,
      }
    );
    callOffersListApi(
      dealerid,
      selectedTab,
      cat,
      cic,
      dlerid,
      brandFilter,
      cityFilter,
      stateFilter,
      searchParam,
      "",
      1,
      selectLimit,
      false,
      parentDealerId
    );
    setAcctionList();
    setSortOpts(Constants.sortOptions);
    setColPrefs(
      window.is2wDealer ? Constants.colPreferences2W : Constants.colPreferences(
        selectedTab,
        props.isParentDealer,
        isIndividualDealer
      )
    );
    setDefaultColValues(Constants.selectedArr);
  };

  const sortdropdown = (checked, unchecked) => {
    let combinedArray = [];
    checked.sort((a, b) => (a.label > b.label ? 1 : -1));
    combinedArray.push(...checked, ...unchecked);
    return combinedArray;
  };

  const mapfilter = (checked) => {
    let checkedarray = [];

    checked?.map((val, ind) => {
      let brandobj = {};
      brandobj["label"] = val;
      brandobj["value"] = ind;
      checkedarray.push(brandobj);
    });
    return checkedarray;
  };
  const getDropdownOptions = (filterData, allfilters) => {
    let filtersdta = filterData;
    let catarr = [];
    let cicarr = [];
    let dealerarr = [];
    let brandarr = [];
    let cityarr = [];
    let statearr = [];
    catarr = mapfilter(filtersdta.category);
    cicarr = mapfilter(filtersdta.cic);
    dealerarr = mapfilter(filtersdta.childDealers);
    brandarr = mapfilter(filtersdta.brand);
    cityarr = mapfilter(filtersdta.cityname);
    statearr = mapfilter(filtersdta.statename);
    if (allfilters !== undefined) {
      catarr = getfilterdata(filtersdta.category, allfilters.uncheckedCategory);
      cicarr = getfilterdata(filtersdta.cic, allfilters.uncheckedCic);
      dealerarr = getfilterdata(
        filtersdta.childDealers,
        allfilters.uncheckedChildDealers
      );
      brandarr = getfilterdata(filtersdta.brand, allfilters.uncheckedBrand);
      cityarr = getfilterdata(filtersdta.cityname, allfilters.uncheckedCity);
      statearr = getfilterdata(filtersdta.statename, allfilters.uncheckedState);
    }
    setCategoryOpts(catarr);
    setCicOpts(cicarr);
    setDealerOpts(dealerarr);
    setBrandOpts(brandarr);
    setCityOpts(cityarr);
    setStateOpts(statearr);
  };

  const getfilterdata = (checkedfilter, uncheckedfilter) => {
    let arr = [];
    if (uncheckedfilter != undefined) {
      let checked = mapfilter(checkedfilter);
      let unchecked = mapfilter(uncheckedfilter);
      arr = sortdropdown(checked, unchecked);
    } else {
      arr = mapfilter(checkedfilter);
    }
    return arr;
  };

  const getTabValues = (key) => {
    const matchedItem = offersdta.find((item) => item[0] == key);
    return matchedItem ? matchedItem[1] : "";
  };

  const clickTab = (val) => {
    setSortopt("");
    setSelectedTag("");
    setSelectedPage(1)

    setAcctionList(val);
    setSelectedData([]);
    setActivetab(true);
    setSelectedTab(val);
    setSelectedRow([]);
    setActionStatus("");
    setActionMsg("");
    setSelectedsku("");
    setActnresp("");
    setIsGetOffersListLoading(true);
    let seltab = val;
    callOffersListApi(
      dealerid,
      val,
      cat,
      cic,
      dlerid,
      brandFilter,
      cityFilter,
      stateFilter,
      searchParam,
      "",
      1,
      20,
      false,
      parentDealerId
    );
    callFiltersApi(
      dealerid,
      seltab,
      cat,
      cic,
      dlerid,
      brandFilter,
      cityFilter,
      stateFilter,
      "",
      parentDealerId
    );
    let count = "";
    if (val === "new") count = getTabValues("new");
    else if (val === "active") count = getTabValues("active");
    else if (val === "inactive") count = getTabValues("inactive");
    else if (val === "lowstock") count = getTabValues("lowstock");
    else if (val === "outofstock") count = getTabValues("outofstock");
    else count = offersdta[5][1];
    selectCTA({
      selectedTab: val.charAt(0).toUpperCase() + val.slice(1),
      count: count,
      dealerId: dealerid,
      dealerName: supplierName,
      pageType: "Price Management",
      dealerType: window.dealer_type,
    });
  };

  const callFiltersData = (
    cat,
    cic,
    id,
    brandFilter,
    cityFilter,
    stateFilter,
    isFalseSearch = false
  ) => {
    setActionErr(false);
    setIsCsvError(false);
    setIsFilter(true);
    setIsFilterApplied(true);
    setIsFilterSearch(true);
    setBrand(brandFilter);
    setCat(cat);
    setCic(cic);
    setDlerid(id);
    setBrandFilter(brandFilter);
    setCityFilter(cityFilter);
    setStateFilter(stateFilter);
    setIsGetOffersListLoading(true);

    filterApi(
      cat,
      cic,
      id,
      brandFilter,
      cityFilter,
      stateFilter,
      isFalseSearch
    );
  };

  const filterApi = (
    cat,
    cic,
    id,
    brandFilter,
    cityFilter,
    stateFilter,
    isFalseSearch
  ) => {
    let searchParamValue = isFalseSearch ? "" : searchParam;
    callOffersListApi(
      dealerid,
      selectedTab,
      cat,
      cic,
      id,
      brandFilter,
      cityFilter,
      stateFilter,
      searchParamValue,
      "",
      1,
      selectLimit,
      false,
      parentDealerId
    );
    callFiltersApi(
      dealerid,
      selectedTab,
      cat,
      cic,
      id,
      brandFilter,
      cityFilter,
      stateFilter,
      searchParamValue,
      parentDealerId
    );
  };

  const getSearchVal = (e) => {
    setSearchParam(e.target.value);
  };

  const callSearch = (event) => {
    setActionErr(false);
    setIsFilter(false);
    setIsFilterApplied(false);
    setIsFilterSearch(true);
    setIsGetOffersListLoading(true);
    callOffersListApi(
      dealerid,
      selectedTab,
      cat,
      cic,
      dlerid,
      brandFilter,
      cityFilter,
      stateFilter,
      event,
      "",
      1,
      selectLimit,
      false,
      parentDealerId
    );
    var regExp = /[a-zA-Z]/g;

    console.log("aaa", regExp.test(event));
    searchTerm({
      ListingName: "Search Bar",
      dealerId: dealerid,
      dealerName: supplierName,
      searchValue: regExp.test(event) ? "SKU" : "Model ID",
      pageType: "Price Management",
      dealerType: window.dealer_type,
    });
  };

  const selectedlimit = (limit, pageNo) => {
    setIsGetOffersListLoading(true);
    setSelectedLimit(limit);
    callOffersListApi(
      dealerid,
      selectedTab,
      cat,
      cic,
      dlerid,
      brandFilter,
      cityFilter,
      stateFilter,
      searchParam,
      sortopt,
      pageNo,
      limit,
      false,
      parentDealerId
    );
  };

  const sortOptChangeNew = (value) => {
    setIsGetOffersListLoading();
    let sortOptn = value !== null ? value?.value : "";
    let opt = "";
    if (sortOptn == "producttitle") {
      opt = "sku";
      setSortopt(opt);
    } else if (sortOptn == "creationtime") {
      opt = "created_at";
      setSortopt(opt);
    } else if (sortOptn == "updatetime") {
      opt = "updated_at";
      setSortopt(opt);
    } else if (sortOptn == "outofstock") {
      opt = "inventory";
      setSortopt(opt);
    } else if (sortOptn == "lowstock") {
      opt = "inventory";
      setSortopt(opt);
    } else if (sortOptn == "expiredsku") {
      opt = "is_expired";
      setSortopt(opt);
    }
    sortSKU({
      dealerId: dealerid,
      dealerName: supplierName,
      listingSelected: value?.label,
      selectedTab: selectedTab,
      pageType: "Price Managment",
      dealerType: window.dealer_type,
    });
    callOffersListApi(
      dealerid,
      selectedTab,
      cat,
      cic,
      dlerid,
      brandFilter,
      cityFilter,
      stateFilter,
      searchParam,
      opt,
      selectedPage,
      selectLimit,
      false,
      parentDealerId
    );
  };
  const resetSearch = () => {
    setSearchParam("");
    setResetFilter(true);
    callFiltersData([], [], [], [], [], [], true);
    setLowStockSearchRecordsCount(0);
    setOutofStockSearchRecordsCount(0);
    setSearchActiveRecordsCount(0);
    setSearchInActiveRecordsCount(0);
    setNewSearchCount(0);
    setPricAlertSearchCount(0);
  };
  const getSelectedPage = (page, limit) => {
    setSelectedPage(page);
    setSelectedLimit(limit);
    setIsFilterSearch(false);
    setIsGetOffersListLoading(true);
    callOffersListApi(
      dealerid,
      selectedTab,
      cat,
      cic,
      dlerid,
      brandFilter,
      cityFilter,
      stateFilter,
      searchParam,
      sortopt,
      page,
      limit,
      false,
      parentDealerId
    );
  };
  const selectedActionResp = (status, msg, sku, resp) => {
    setActionErr(false);
    if (status == "success") {
      setActionStatus(status);
      setActionMsg(msg);
      setSelectedsku(sku);
      setActnresp(resp);

      onUpdateCallDashBoardApi();
    } else {
      setActionStatus(status);
      setActionMsg(msg);
      setSelectedsku(sku);
      setActnresp(resp);
    }
  };

  const resetPrice = (status) => {
    setActionStatus("");
    setActionMsg("");
    setSelectedsku("");
    setActnresp("");
  };

  const resetSaveActionResp = () => {
    setActionStatus("");
    setActionMsg("");
    setActnresp("");
  };

  const onPrevSuccess = (status) => {
    setActionErr(false);
  };

  const changeTag = (value) => {
    debugger;
    callOffersListApi(
      dealerid,
      selectedTab,
      cat,
      cic,
      dlerid,
      brandFilter,
      cityFilter,
      stateFilter,
      searchParam,
      value,
      selectedPage,
      selectLimit,
      false,
      parentDealerId
    );
    setSelectedTag(value);
    setSortopt(value);
  };

  const onClickNotification = (tag,tab) => {
    callOffersListApi(
      dealerid,
      tab,
      cat,
      cic,
      dlerid,
      brandFilter,
      cityFilter,
      stateFilter,
      searchParam,
      tag,
      selectedPage,
      selectLimit,
      false,
      parentDealerId
    );
    setSelectedTag(tag);
    setSortopt(tag);

    setActnonslctd(
      tab === Constants.priceManagement.new
        ? Constants.actnonslctdNew
        : Constants.actnonslctd
    );


    setSelectedTab(tab);
    setActionStatus("");
    setActionMsg("");
    setSelectedsku("");
    setActnresp("");
    setIsGetOffersListLoading(true);

  }

  const getUpdateddata = (status, msg, sku, resp, selectedTab) => {
    setActionErr(false);
    if (status == "success") {
      onUpdateCallDashBoardApi();
      setActionStatus(status);
      setActionMsg(msg);
      setSelectedsku(sku);
      setActnresp(resp);
      setSelectedTab(selectedTab);
    } else {
      setActionStatus(status);
      setActionMsg(msg);
      setSelectedsku(sku);
      setActnresp(resp);
    }
  };

  const getSelectedStatus = (selectedstatus) => {
    setActionErr(false);
    setSelectedstatus(selectedstatus);
  };

  const getDealerIds = () => {
    var dealerIds = [];
    if (dlerid.length > 0) {
      dealerIds = dlerid;
    } else if (dealerOpts.length > 0) {
      dealerOpts.map((val, ind) => {
        dealerIds.push(val.label);
      });
    }
    return dealerIds;
  };

  const downloadCityCsvDataFunc = (downloadType, downloadMethod) => {
    if (downloadMethod != null) {
      if (downloadMethod == "expired-sku") {
        setDownloadType(downloadType);
        setDownloadMethod(downloadMethod);
        setIs_download_expired(true);
        callOffersListApi(
          dealerid,
          selectedTab,
          cat,
          cic,
          dlerid,
          brandFilter,
          cityFilter,
          stateFilter,
          searchParam,
          "",
          1,
          selectLimit,
          true,
          parentDealerId
        );
      } else {
        setIs_download_expired(false);
        setDownloadType(downloadType);
        setDownloadMethod(downloadMethod);
        callOffersListApi(
          dealerid,
          downloadMethod,
          cat,
          cic,
          dlerid,
          brandFilter,
          cityFilter,
          stateFilter,
          searchParam,
          "",
          1,
          selectLimit,
          true,
          parentDealerId
        );
      }
    } else {
      setDownloadType(downloadType);
      setDownloadMethod(downloadMethod);

      callOffersListApi(
        dealerid,
        selectedTab,
        cat,
        cic,
        dlerid,
        brandFilter,
        cityFilter,
        stateFilter,
        searchParam,
        "",
        1,
        selectLimit,
        true,
        parentDealerId
      );
    }
  };

  const setColumnPrefernces = (value) => {
    setSelevent(value);
  };

  const resetFilters = (isFiltered = false) => {
    if (isFiltered) {
      setResetFilter(false);
    }
  };

  const uploadedFileResponse = (value) => {
    setFileData(value);
  };

  const getSelectedRow = (row) => {
    setSelectedRow(row);
  };

  const setBrandCategory = (data, cond) => {
    setStatus(true);
    if (cond === "Brand") setBrand(data);
    else setCategory(data);
  };

  const tabChange = (newValue) => {
    onclickLevel2HeaderOptionGTM({
      ListingName: "Search Bar",
      selectedList:
        newValue === 0 ? "Listing Management" : "Logistics Management",
      eventLabel: "{{}}",
      dealerId: dealerid,
      dealerName: supplierName,
      // searchValue: regExp.test(event) ? "SKU" : "Model ID",
      pageType: "Price Management",
      dealerType: window.dealer_type,
    });
    setSelevent([]);
    setFileData({});
    setSelectedData([]);
    props.setLevel2HeaderValue(newValue)
  };

  const {
    csvError,
    csvFileName,
    csvHeaderValue,
    csvSuccess,
    downloadCsvValue,
    downloadable,
    maxDealer,
    message,
    partial,
    progressPercentValue,
    speialCharError,
    showHeaderMessage,
  } = fileData;

  let responseMessage;
  responseMessage = (
    <ResponseMessage
      isCsvError={csvError}
      speialCharError={speialCharError}
      isMaxDealer={maxDealer}
      isPartial={partial}
      errorMessage={message}
      isShowHeaderMessage={showHeaderMessage}
      isDownloadable={downloadable}
      downloadCsvData={downloadCsvValue}
      csvFileName={csvFileName}
      progressPercent={progressPercentValue}
      isCsvSuccess={csvSuccess}
      csvHeader={csvHeaderValue}
    />
  );

  // if (isDashBoadLoading) {
  //   return <FullPageLoader />;
  // }

  return (
    <div className="maindiv">
      <div id="stickyMainHeader" className="stickyMainHeader">
        <Header
          supplierName={supplierName}
          dealerid={dealerid}
          dealerName={supplierName}
          md5value={props.md5value}
          callSearch={callSearch}
          resetSearch={resetSearch}
          searchParam={searchParam}
          getSearchVal={getSearchVal}
          dashboardResponse = {data?.payload}
          onClickNotification={onClickNotification}

        />
        {!window.is2wDealer && (
          <Level2Header
            value={props.level2HeaderValue}
            isLoading={getofferslistDataResp.isLoading}
            onChange={tabChange}
            getmagentodeliveryflagResp={props.getmagentodeliveryflagResp}
            isParentDealer={props.isParentDealer}
            isIndividualDealer = {isIndividualDealer}
            replacementFlag={props.replacementFlag}
          />
        )}
      </div>
       {!window.is2wDealer && <Agreement
        aggrement={props.aggrement}
        agrefresh={props.agrefresh}
        isParentDealer={isParentDealer}
        fileData={fileData}
        dealerid={dealerid}
        dealerName={supplierName}
        selectedTab={selectedTab}
        parentDealerId={parentDealerId}
        /> }
      {/* {offersdta.length > 0 ? ( */}
      <div className="contleft">
        {/* <h2 className="txt">{prodTitle}</h2>
          <div className="contleft titleContainer">
            <h1 className="txt listingTitle">LISTING MANAGEMENT</h1>
          </div> */}
          {responseMessage}
          {isDashBoadLoading && <TabLoader />}
          {window.is2wDealer || window.isLogistic ? (
            !isDashBoadLoading && <Tabsbar
              offersdta={offersdta}
              clickTab={clickTab}
              searchActiveRecordsCount={searchActiveRecordsCount}
              totalRecords={totalRecords}
              searchRecords={searchRecords}
              searchInActiveRecordsCount={searchInActiveRecordsCount}
              lowStockSearchRecordsCount={lowStockSearchRecordsCount}
              outofStockSearchRecordsCount={outofStockSearchRecordsCount}
              pricAlertSearchCount={pricAlertSearchCount}
              newSearchRecordCount={newSearchCount}
              selectedTab={selectedTab}
              isDisaplyXYformat={
                (isAnyFilterApplied() || searchParam.length > 0) &&
                !getofferslistDataResp.isLoading
              }
            />
          ) : (
            !isDashBoadLoading && <TabsBarNewUI
              offersdta={offersdta}
              clickTab={clickTab}
              searchActiveRecordsCount={searchActiveRecordsCount}
              totalRecords={totalRecords}
              searchRecords={searchRecords}
              searchInActiveRecordsCount={searchInActiveRecordsCount}
              lowStockSearchRecordsCount={lowStockSearchRecordsCount}
              outofStockSearchRecordsCount={outofStockSearchRecordsCount}
              pricAlertSearchCount={pricAlertSearchCount}
              newSearchRecordCount={newSearchCount}
              selectedTab={selectedTab}
              selectedTag={selectedTag}
              changeTag={changeTag}
              isDisaplyXYformat={
                (isAnyFilterApplied() || searchParam.length > 0) &&
                !getofferslistDataResp.isLoading
              }
              downloadPayloadData={downloadPayloadData}
            />
          )}
          <div className="sectndiv">
            <CenterSections
              //Props required for middlesection
              selevent={selevent}
              selectedTab={selectedTab}
              parentDlerId={parentDealerId}
              colPrefs={colPrefs}
              md5value={props.md5value}
              selectedData={selectedData}
              downloadData={downloadCityCsvDataFunc}
              actnonslctd={actnonslctd}
              isFilterApplied={isAnyFilterApplied()}
              selectedRow={selectedRow}
              setIsGetOffersListLoading={setIsGetOffersListLoading}
              startSkeletonLoader={(e) => setIsGetOffersListLoading(e)}
              isParentDealer={isParentDealer}
              dealerid={props.dealerId}
              dealerOpts={dealerOpts}
              parentDealerId={parentDealerId}
              offer_header_sample={offer_header_sample}
              dlerid={dlerid}
              selectedActionResp={selectedActionResp}
              offer_header_description={offer_header_description}
              offer_header_resp={offer_header_resp}
              cat={cat}
              sendCheckboxValue={setColumnPrefernces}
              cic={cic}
              brandFilter={brandFilter}
              cityFilter={cityFilter}
              stateFilter={stateFilter}
              searchParam={searchParam}
              downloadHanlder={downloadHanlder}
              sendFileStatus={uploadedFileResponse}
              selectedsku={selectedsku}
              listdata={listdata}
              actnresp={actnresp}
              actionStatus={actionStatus}
              actionMsg={actionMsg}
              getSelectedRow={getSelectedRow}
              getSelectedStatus={getSelectedStatus}
              onUpdateCallDashBoardApi={onUpdateCallDashBoardApi}
              selectedPage={selectedPage}
              selectedLimit={selectLimit}
              offersdashboardResp={data}
              resetSaveActionResp={resetSaveActionResp}
              //Props required for Filters
              childIds={dlerid}
              categoryOpts={categoryOpts}
              fltersdata={fltersdata}
              isIndividualDealer={isIndividualDealer}
              cicOpts={cicOpts}
              brandOpts={brandOpts}
              cityOpts={cityOpts}
              stateOpts={stateOpts}
              callFiltersData={callFiltersData}
              resetSearch={resetSearch}
              resetFilter={resetFilter}
              resetFilters={resetFilters}
              dealerIds={getDealerIds}
              // ref={filterElement}
              downloadError={downloadError}
              downloadThreholdError={downloadThreholdError}
              closeDToolTip={closeDToolTip}
              dealerName={supplierName}
              fileData={fileData}
              resetPrice={resetPrice}
              //Props required for SortOptions
              options={sortOpts}
              sortOptChangeFun={sortOptChangeNew}
              seconds={seconds}
              startRecords={startRecords}
              parentCallback={setBrandCategory}
              category={category}
              brand={brand}
              dashBoardResp={data}
              isFilter={isFilter}
              getFiltersDataResp={getofferslistDataResp?.data}
              downloadPayloadData={downloadPayloadData}
            />
          <section>
            {isGetOffersListLoading && <AgGridLoader loading={true} />}
            {/* {! isGetOffersListLoading && */}
            <Grid
              dlerid={dlerid}
              dealerid={dealerid}
              parentDealerId={parentDealerId}
              isParentDealer = {props.isParentDealer}
              isIndividualDealer = {isIndividualDealer}
              md5value={props.md5value}
              logisticsData={logisticsData}
              listdata={listdata}
              selval={selval}
              selevent={selevent}
              getSelectedRow={getSelectedRow}
              selectedlimit={selectedlimit}
              getSelectedPage={getSelectedPage}
              getUpdateddata={getUpdateddata}
              selectedRow={selectedRow}
              actionStatus={actionStatus}
              actionMsg={actionMsg}
              selectedsku={selectedsku}
              actnresp={actnresp}
              getSelectedStatus={getSelectedStatus}
              selectedstatus={selectedstatus}
              isGetOffersListLoading={isGetOffersListLoading}
              selectedActionResp={selectedActionResp}
              selectedTab={selectedTab}
              downloadHanlder={downloadHanlder}
              onPrevSuccess={onPrevSuccess}
              totalRecords={totalRecords}
              totalItems={totalItems}
              startRecords={startRecords}
              isFilterSearch={isFilterSearch}
              dealerName={supplierName}
              filter={[
                ...cat,
                ...cic,
                ...brandFilter,
                ...cityFilter,
                ...stateFilter,
                ...dlerid,
              ]}
              cat={cat}
              cic={cic}
              brandFilter={brandFilter}
              cityFilter={cityFilter}
              stateFilter={stateFilter}
              category={category}
              brand={brand}
              status={status}
              getmagentodeliveryflagResp={props.getmagentodeliveryflagResp}
            ></Grid>
            {/* } */}
          </section>
        </div>
      </div>
      {/* // ) : ( // "" // )} */}
      <div className="loader">
        <PulseLoader color="#262d3f" />
      </div>
    </div>
  );
};
export default TabsComponent;
