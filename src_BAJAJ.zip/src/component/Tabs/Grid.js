import React from "react";
import OffersListGrid2W from "../Grid/OffersListGrid2W";
import OffersListGridLogistics from "../Grid/OfferListGridLogistics";
import OffersListGrid from "../Grid/OffersListGrid";

const Grid = (props) => {
  const {
    dlerid,
    dealerid,
    parentDealerId,
    isIndividualDealer,
    isParentDealer,
    logisticsData,
    selval,
    selevent,
    getSelectedRow,
    selectedlimit,
    getSelectedPage,
    getUpdateddata,
    selectedRow,
    actionStatus,
    actionMsg,
    selectedsku,
    actnresp,
    getSelectedStatus,
    selectedstatus,
    isGetOffersListLoading,
    selectedActionResp,
    selectedTab,
    downloadHanlder,
    onPrevSuccess,
    totalRecords,
    totalItems,
    startRecords,
    isFilterSearch,
    supplierName,
    cat,
    cic,
    brandFilter,
    cityFilter,
    stateFilter,
    category,
    brand,
    status,
    listdata,
    getmagentodeliveryflagResp,
  } = props;

  const filter = [].concat(
    cat,
    cic,
    brandFilter,
    cityFilter,
    stateFilter,
    dlerid
  );
  if (window.is2wDealer) {
    return (
      <OffersListGrid2W
        childIds={dlerid}
        dealerid={dealerid}
        parentDlerId={parentDealerId}
        md5value={props.md5value}
        gridrows={listdata}
        selval={selval}
        selevent={selevent}
        getSelectedRow={getSelectedRow}
        selectedlimit={selectedlimit}
        getSelectedPage={getSelectedPage}
        getUpdateddata={getUpdateddata}
        selectedRow={selectedRow}
        actionStatus={actionStatus}
        actionMsg={actionMsg}
        selectedsku={selectedsku}
        actnresp={actnresp}
        getSelectedStatus={getSelectedStatus}
        selectedstatus={selectedstatus}
        isGetOffersListLoading={isGetOffersListLoading}
        selectedActionResp={selectedActionResp}
        selectedTab={selectedTab}
        downloadHanlder={downloadHanlder}
        onPrevSuccess={onPrevSuccess}
        totalRecords={totalRecords}
        totalItems={totalItems}
        startRecords={startRecords}
        isFilterSearch={isFilterSearch}
        dealerName={supplierName}
        filter={filter}
        category={category}
        brand={brand}
        status={status}
      ></OffersListGrid2W>
    );
  } else if (window.isLogistic) {
    return (
      <OffersListGridLogistics
        childIds={dlerid}
        dealerid={dealerid}
        parentDlerId={parentDealerId}
        md5value={props.md5value}
        gridrows={listdata}
        selval={selval}
        selevent={selevent}
        getSelectedRow={getSelectedRow}
        selectedlimit={selectedlimit}
        getSelectedPage={getSelectedPage}
        getUpdateddata={getUpdateddata}
        selectedRow={selectedRow}
        actionStatus={actionStatus}
        actionMsg={actionMsg}
        selectedsku={selectedsku}
        actnresp={actnresp}
        getSelectedStatus={getSelectedStatus}
        selectedstatus={selectedstatus}
        isGetOffersListLoading={isGetOffersListLoading}
        selectedActionResp={selectedActionResp}
        selectedTab={selectedTab}
        downloadHanlder={downloadHanlder}
        onPrevSuccess={onPrevSuccess}
        totalRecords={totalRecords}
        totalItems={totalItems}
        startRecords={startRecords}
        isFilterSearch={isFilterSearch}
        dealerName={supplierName}
        filter={filter}
        category={category}
        brand={brand}
        status={status}
        getmagentodeliveryflagResp={getmagentodeliveryflagResp}
      ></OffersListGridLogistics>
    );
  } else {
    return (
      <OffersListGrid
        childIds={props.dlerid}
        dealerid={dealerid}
        parentDlerId={parentDealerId}
        isIndividualDealer={isIndividualDealer}
        isParentDealer = {isParentDealer}
        md5value={props.md5value}
        gridrows={listdata}
        selval={selval}
        selevent={selevent}
        getSelectedRow={getSelectedRow}
        selectedlimit={selectedlimit}
        getSelectedPage={getSelectedPage}
        getUpdateddata={getUpdateddata}
        selectedRow={selectedRow}
        actionStatus={actionStatus}
        actionMsg={actionMsg}
        selectedsku={selectedsku}
        actnresp={actnresp}
        getSelectedStatus={getSelectedStatus}
        selectedstatus={selectedstatus}
        isGetOffersListLoading={isGetOffersListLoading}
        selectedActionResp={selectedActionResp}
        selectedTab={selectedTab}
        downloadHanlder={downloadHanlder}
        onPrevSuccess={onPrevSuccess}
        totalRecords={totalRecords}
        totalItems={totalItems}
        startRecords={startRecords}
        isFilterSearch={isFilterSearch}
        dealerName={supplierName}
        filter={filter}
        category={category}
        brand={brand}
        status={status}
      ></OffersListGrid>
    );
  }
};

export default Grid;
