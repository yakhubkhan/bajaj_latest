import React from "react";
import "./TabItem.css";

const TabItem = (props) => {
  const { isSelected, subTitleColor, subTitleBgColor, expiredSkuTitle } = props;
  const is2wDealer = window.is2wDealer;
  return (
    <div
      className={
        `${
          window.isLogistic ? "tabItemContainer-logistic" : "tabItemContainer"
        } disp_flex alignitemsCenter` + (isSelected ? " isSelected" : "")
      }
      onClick={props.onClick}
    >
      <div className="tabImageContainer">
        <img height="50px" src={props.icon} alt="listIcon" />
      </div>
      <div className="disp_flex tabTitleContainer">
        <div>
          <span className={"tabTitle" + (isSelected ? " whiteColorTxt" : "")}>
            {props.title}
          </span>
          <div className={"tabCount" + (isSelected ? " whiteColorTxt" : "")}>
            {props.count}
          </div>
        </div>
        <div className="disp_flex tabExtraCountContainer">
          {props.subTitle && (
            <span
              className="tabSubTitle"
              style={{ color: subTitleColor, backgroundColor: subTitleBgColor }}
            >
              {props.subTitle}
            </span>
          )}
          {!is2wDealer && expiredSkuTitle && (
            <span className="expiredSkuCount">{expiredSkuTitle}</span>
          )}
        </div>
      </div>
      {props.newCatalogue && (
        <div className="newCatalogue disp_flex tabExtraCountContainer">
          <span className="newCatalogue-span">{props.newCatalogue}</span>
        </div>
      )}
    </div>
  );
};

export default TabItem;
