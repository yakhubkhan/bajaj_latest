import React, { useState } from "react";
import "./TabItem.css";

const TabItemWithTags = (props) => {
  const {
    isSelected,
    title,
    count,
    subTitleColor,
    subTitleBgColor,
    expiredSkuTitle,
    imgColor,
    selectedTag,
    tabsData,
    hotsellingData,
  } = props;
  const is2wDealer = window.is2wDealer;

  const isNewTabSelected = props.selectedTab == "new";
  const isActiveTabSelected = props.selectedTab == "active";
  const isInActiveTabSelected = props.selectedTab == "inactive";
  const isPriceAlertTabSelected = props.selectedTab == "pricealert";

  const onClickTag = (e, val, count) => {
    if (isSelected) {
      e.stopPropagation();
      e.preventDefault();
      if(count && count > 0){
      props.changeTag(val);
      }
    }
  };

  return (
    <div
      className={
        "tabItemContainerwithTags disp_flex" +
        (isSelected ? " tabItemContainerwithTagsSelected" : "")
      }
      onClick={props.onClick}
    >
      <div
        className={
          "tabTitleContainerwithTag" +
          (isSelected ? " tabTitleContainerwithTagSelected" : "")
        }
      >
        <span className={isSelected ? "titleTab" : "titleTab tabsTextColor"}>
          {title}
        </span>
        <span className="titleTab">{count}</span>
      </div>
      <div className="disp_flex">
        <div>
          <div
            className={
              "tabImageContainerWithTag disp_flex alignitemsCenter" +
              (isSelected ? " tabImageContainerWithTagSelected" : "")
            }
            style={{
              backgroundColor: imgColor,
              height: isSelected ? "40px" : "72px",
            }}
          >
            <img height="40px" src={props.icon} alt="listIcon" />
          </div>
        </div>
        <div className="tagsGrid">
          {props.title === "New Listing" && (
            <div
              className={
                "newcatalogueTag" +
                (selectedTag == "new_product" ? " selectedTag" : "")
              }
              onClick={(e) => onClickTag(e, "new_product",tabsData.new_catalog)}
            >
              <span className="autoScaledspan">
                {tabsData.new_catalog} New Catalog
              </span>
            </div>
          )}
          {props.title === "Active Listing" && (
            <div
              className={
                "lowstockTag" +
                (selectedTag == "inventory" && isActiveTabSelected
                  ? " selectedTag"
                  : "")
              }
              onClick={(e) => onClickTag(e, "inventory",tabsData.lowstock)}
            >
              <span className="autoScaledspan">
                {tabsData.lowstock} Low Stock
              </span>
            </div>
          )}
          {props.title === "Inactive Listing" && (
            <div
              className={
                "lowstockTag" +
                (selectedTag == "inventory" && isInActiveTabSelected
                  ? " selectedTag"
                  : "")
              }
              onClick={(e) => onClickTag(e, "inventory",tabsData.outofstock)}
            >
              <span className="autoScaledspan">
                {tabsData.outofstock} Out of Stock
              </span>
            </div>
          )}
          <div
            className={
              "hotSellingTag" +
              (selectedTag == "hot_selling" && isSelected ? " selectedTag" : "")
            }
            onClick={(e) => onClickTag(e, "hot_selling",hotsellingData)}
          >
            <span className="autoScaledspan">{hotsellingData} Hot Selling</span>
          </div>
          {props.title === "Active Listing" && (
            <div
              className={
                "autoScaledTag" +
                (selectedTag == "auto_scaled" ? " selectedTag" : "")
              }
              onClick={(e) => onClickTag(e, "auto_scaled",tabsData.autoscaled)}
            >
              <span className="autoScaledspan">
                {tabsData.autoscaled} Auto Scaled
              </span>
            </div>
          )}
          {props.title === "Inactive Listing" && (
            <div
              className={
                "autoScaledTag" +
                (selectedTag == "deactivated" ? " selectedTag" : "")
              }
              onClick={(e) => onClickTag(e, "deactivated",tabsData.deactivated)}
            >
              <span className="autoScaledspan">
                {tabsData.deactivated} Deactivated
              </span>
            </div>
          )}
          {props.title === "Active Listing" && (
            <div
              className={
                "expiredTag" +
                (selectedTag == "is_expired" && isActiveTabSelected
                  ? " selectedTag"
                  : "")
              }
              onClick={(e) => onClickTag(e, "is_expired", tabsData.active_expired_sku)}
            >
              <span className="autoScaledspan">
                {tabsData.active_expired_sku} Expired SKU
              </span>
            </div>
          )}
          {props.title === "Inactive Listing" && (
            <div
              className={
                "expiredTag" +
                (selectedTag == "is_expired" && isInActiveTabSelected
                  ? " selectedTag"
                  : "")
              }
              onClick={(e) => onClickTag(e, "is_expired",tabsData.inactive_expired_sku)}
            >
              <span className="autoScaledspan">
                {tabsData.inactive_expired_sku} Expired SKU
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TabItemWithTags;
