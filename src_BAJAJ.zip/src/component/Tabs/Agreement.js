/* eslint-disable */
import React from "react";
import { callProceedDataLayer } from "../../gtm";
import Modal from "react-bootstrap/Modal";

const Agreement = (props) => {
  const { isParentDealer, parentDealerId } = props;
  let isValidAgreement =
    props.aggrement && typeof props.aggrement.code !== "undefined"
      ? props.aggrement.code
      : 0;
  let agreementLink =
    props.aggrement && typeof props.aggrement.link !== "undefined"
      ? props.aggrement.link
      : "";
  let childDealerMessage =
    "To proceed further agreement to be accepted by parent code " +
    parentDealerId +
    ", please login using parent code credential and accept the agreement";
  let noLinkHtml = !props.isParentDealer
    ? childDealerMessage
    : "TnC mapping is incomplete. Please reach out to your Bajaj Representative for same";
  let isLinkAvail = agreementLink
    ? "Please proceed to read our Terms of Service."
    : noLinkHtml;
  let agrHtml = props.isParentDealer ? isLinkAvail : childDealerMessage;

  const callDataLayer = () => {
    callProceedDataLayer({
      dealerId: props.dealerid,
      dealerName: props.dealerName,
      selectedTab: "Proceed",
    });
  };

  return isValidAgreement > 0 && isParentDealer ? (
    <div className="agreement_popup_container">
      <div className="agreement_popup">
        {props.agrefresh && (
          <div className="agree_refresh">Please refresh the page</div>
        )}
        {isValidAgreement == 1 && (
          <div>
            <h3 className="agree_header">Agreement</h3>

            <div className="terms_agreement">{agrHtml}</div>
            {props.isParentDealer && agreementLink && (
              <div onClick={callDataLayer}>
                <a
                  href={agreementLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="agree_button"
                >
                  Proceed
                </a>
              </div>
            )}
          </div>
        )}
        {isValidAgreement == 2 && (
          <div>
            <h3 className="agree_header">Agreement</h3>
            <div className="terms_agreement">{noLinkHtml}</div>
          </div>
        )}
      </div>
    </div>
  ) : isValidAgreement > 0 && !isParentDealer ? (
    <Modal show={true} className="modal_agreement">
      <Modal.Body>
        <div>
          <h3 className="main_agreement_header">Agreement</h3>
          <div className="agrement_header">{childDealerMessage}</div>
        </div>
      </Modal.Body>
    </Modal>
  ) : null;
};

export default Agreement;
