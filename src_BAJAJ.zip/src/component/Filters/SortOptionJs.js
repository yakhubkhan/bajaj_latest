
import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import * as Constants from "../../utils/Constant";
import arrowDown from "../../images/downarrow1.png";
import "./SortOption.css";
import cancel from "../../images/cancel.png";


const SortOption = (props) => {
  const [, setStatus] = useState(false);
  const [sortOptionValue, setSortOption] = useState();
  const [selectedSortBy, setSelectedSortBy] = useState("");

 

  useEffect(() => {
    if (window.is2wDealer) {
      if (props.selectedTab === "inactive") {
        setSortOption(Constants.twoWheelerInActiveTabSortOptions);
      } else if (props.selectedTab === "active") {
        setSortOption(Constants.twoWheelerActiveTabSortOptions);
      } else if (props.selectedTab === "new") {
        setSortOption(Constants.twoWheelerCommonSortOptions);
      }
    } else if (props.selectedTab === "inactive") {
      setSortOption(Constants.sortOptions1);
    } else if (props.selectedTab === "active") {
      setSortOption(Constants.sortOptions2);
    } else {
      setSortOption(Constants.sortOptions);
    }

    if (
      props.selectedTab === "new" &&
      (props.brand.length || props.category.length)
    ) {
      setStatus(false);
    } else if (
      props.selectedTab === "new" &&
      (props.brand.length === 0 || props.category.length === 0)
    ) {
      setStatus(true);
    } else {
      setStatus(false);
    }
  }, [props]);

  const onClickOption = (opt) => {
    if (opt) {
      setSelectedSortBy(opt.label);
      props.sortOptChangeFun(opt);
    } else {
      setSelectedSortBy("");
      props.sortOptChangeFun("");
    }
  };
  const multiCheckBox = (data, index) => {
    return (
      <div key = {"multiCheckBox"+index}>
        <div className="form-check-custom">
          <span
            className="form-check-label-custom"
            htmlFor={"flexCheckCheckedMain" + data.title}
            onClick={() => onClickOption(data)}
          >
            {data.label}
          </span>
        </div>
      </div>
    );
  };
  return (
    
    <div className="dropdown sortDrpdwnBtn">
      <div className="sortbyToggle">
        <div className={selectedSortBy.length > 0 ? "columnPrefContainer" : ""}>
          <div className="clmPrefTitle1">
            {selectedSortBy.length > 0 ? selectedSortBy : "Sort by"}
          </div>
          {selectedSortBy.length > 0 && (
            <img
              alt = "cancel"
              className="columnPrefcloseImg"
              src={cancel}
              onClick={() => onClickOption()}
            />
          )}
        </div>
      </div>
      <div
        className={`dropdown-toggle dropdown-toggle-split sortbyToggle removeHardDrpdwnIcon tgldrpdwn`}
        data-toggle="dropdown"
        aria-haspopup="true"
        aria-expanded="true"
        title="Sort By"
      ></div>
      <div
        className="dropdown-menu dropdown-menu-sort drpdwnMenu"
        aria-labelledby="dropdownMenuButton"
      >
        <div className="clmPrefDrpDwnItm sort-dropdwn">
          {sortOptionValue &&
            sortOptionValue.map((mainItem, index) => {
              return multiCheckBox(mainItem, index);
            })}
        </div>
      </div>
      <img
        alt = "arrowDown"
        src={arrowDown}
        height="16px"
        object-fit= "contain"
        className="download_icon rotateIconArrow"
      />
    </div>
  );
};
SortOption.propTypes = {
  options: PropTypes.array,
  sortOptChangeFun: PropTypes.func,
};

export default SortOption;

