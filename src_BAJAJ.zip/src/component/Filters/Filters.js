import React, { useState } from "react";
import MultiCheckboxSearch from "../Select/MultiCheckbox";
import { resetFilters, applyFilter } from "../../gtm";

const Filters = (props) => {
  const [catValues, SetCatValues] = useState([]);
  const [cicValues, SetCicValues] = useState([]);
  const [dealerValues, SetDealerValues] = useState([]);
  const [brandValues, SetBrandValues] = useState([]);
  const [cityValues, SetCityValues] = useState([]);
  const [stateValues, SetStateValues] = useState([]);
  const [categoryState, setCategoryState] = useState(false);
  const [cicState, setCicState] = useState(false);
  const [dealerState, setDealerState] = useState(false);
  const [brandState, setBrandState] = useState(false);
  const [cityState, setCityState] = useState(false);
  const [stateState, setStateState] = useState(false);
  const is2wDealer = window.is2wDealer;

  const callReset = () => {
    if (!props.isFilterApplied) {
      return;
    }
    SetCatValues([]);
    SetCicValues([]);
    SetDealerValues([]);
    SetBrandValues([]);
    SetCityValues([]);
    SetStateValues([]);
    setCategoryState(false);
    setCicState(false);
    setDealerState(false);
    setBrandState(false);
    setCityState(false);
    setStateState(false);
    props.callFilter([], "");
    props.resetSearch();
    resetFilters({
      dealerId: props.dealerid,
      dealerName: props.dealerName,
      selectedTab: props.selectedTab,
      pageType: "Price Management",
      dealerType: window.dealer_type,
      selectedFilter: props.selectedFilter,
    });
  };

  const changeFilter = (data) => {
    if (
      data &&
      data.label &&
      data.label === "Category" &&
      data.value.length > 0
    )
      setCategoryState(true);
    else if (
      data &&
      data.label &&
      data.label === "Category" &&
      data.value.length === 0
    )
      setCategoryState(false);
    else if (
      data &&
      data.label &&
      (data.label === "CIC" || data.label === "Variants") &&
      data.value.length > 0
    )
      setCicState(true);
    else if (
      data &&
      data.label &&
      (data.label === "CIC" || data.label === "Variants") &&
      data.value.length === 0
    )
      setCicState(false);
    else if (
      data &&
      data.label &&
      data.label === "Dealer ID" &&
      data.value.length > 0
    )
      setDealerState(true);
    else if (
      data &&
      data.label &&
      data.label === "Dealer ID" &&
      data.value.length === 0
    )
      setDealerState(false);
    else if (
      data &&
      data.label &&
      data.label === "Brand" &&
      data.value.length > 0
    )
      setBrandState(true);
    else if (
      data &&
      data.label &&
      data.label === "Brand" &&
      data.value.length === 0
    )
      setBrandState(false);
    else if (
      data &&
      data.label &&
      data.label === "City" &&
      data.value.length > 0
    )
      setCityState(true);
    else if (
      data &&
      data.label &&
      data.label === "City" &&
      data.value.length === 0
    )
      setCityState(false);
    else if (
      data &&
      data.label &&
      data.label === "State" &&
      data.value.length > 0
    )
      setStateState(true);
    else if (
      data &&
      data.label &&
      data.label === "State" &&
      data.value.length === 0
    )
      setStateState(false);
  };

  const handleApplyReset = (optionValues, label) => {
    var catValue = catValues;
    var cicValue = cicValues;
    var dealerValue = dealerValues;
    var brandValue = brandValues;
    var cityValue = cityValues;
    var stateValue = stateValues;
    if (label === "Category") {
      SetCatValues(optionValues);
      catValue = optionValues;
      callDataLayer(optionValues, label);
      props.callFilter(optionValues, label);
    } else if (label === "Variants") {
      SetCicValues(optionValues);
      cicValue = optionValues;
      callDataLayer(optionValues, label);
    } else if (label === "Dealer ID") {
      SetDealerValues(optionValues);
      dealerValue = optionValues;
      callDataLayer(optionValues, label);
    } else if (label === "Brand") {
      SetBrandValues(optionValues);
      brandValue = optionValues;
      callDataLayer(optionValues, label);
      props.callFilter(optionValues, label);
    } else if (label === "City") {
      SetCityValues(optionValues);
      cityValue = optionValues;
      callDataLayer(optionValues, label);
    } else if (label === "State") {
      SetStateValues(optionValues);
      stateValue = optionValues;
      callDataLayer(optionValues, label);
    }
    props.callFiltersData(
      catValue,
      cicValue,
      dealerValue,
      brandValue,
      cityValue,
      stateValue
    );
  };

  const callDataLayer = (data, label) => {
    applyFilter({
      dealerId: props.dealerid,
      dealerName: props.dealerName,
      selectedValue: data,
      selectedFilter: label,
      selectedValue: data.toString().replaceAll(",", "/"),
      pageType: "Price Managment",
      dealerType: window.dealer_type,
    });
  };

  return (
    <div className="d-flex alignBottom">
      <div className="disp_flex flexColumn">
        <div className="Product-label">Product</div>
        <div className="disp_flex">
          <div className="fltrminwdth">
            <MultiCheckboxSearch
              label="Category"
              options={props.categoryOpts}
              onApply={handleApplyReset}
              onReset={handleApplyReset}
              changeFilter={changeFilter}
              status={categoryState}
              resetFilter={props.resetFilter}
              resetFilters={props.resetFilters}
              selectedTab={props.selectedTab}
              dealerId={props.dealerid}
              dealerName={props.dealerName}
              brand={brandValues}
              category={catValues}
            />
          </div>

          <div className="fltrminwdth">
            <MultiCheckboxSearch
              label="Variants"
              options={props.cicOpts}
              onApply={handleApplyReset}
              onReset={handleApplyReset}
              changeFilter={changeFilter}
              status={cicState}
              resetFilter={props.resetFilter}
              resetFilters={props.resetFilters}
              selectedTab={props.selectedTab}
              dealerId={props.dealerid}
              dealerName={props.dealerName}
              brand={brandValues}
              category={catValues}
            />
          </div>

          <div className="fltrminwdth">
            <MultiCheckboxSearch
              label="Brand"
              options={props.brandOpts}
              onApply={handleApplyReset}
              onReset={handleApplyReset}
              changeFilter={changeFilter}
              status={brandState}
              resetFilter={props.resetFilter}
              resetFilters={props.resetFilters}
              selectedTab={props.selectedTab}
              dealerId={props.dealerid}
              dealerName={props.dealerName}
              brand={brandValues}
              category={catValues}
            />
          </div>
        </div>
      </div>

      {!is2wDealer && props.isParentDealer && !props.isIndividualDealer && (
        <div className="verticalLine"></div>
      )}
      {!is2wDealer && props.isParentDealer && !props.isIndividualDealer && (
        <div className={`${window.isLogistic ? "business-main" : ""}`}>
          <div
            className={`${
              window.isLogistic ? "business-product-label" : "Product-label"
            }`}
          >
            Business
          </div>
          <div className="disp_flex">
            {props.parentDlerId && (
              <div className="fltrminwdth">
                <MultiCheckboxSearch
                  label="Dealer ID"
                  options={props.dealerOpts}
                  onApply={handleApplyReset}
                  onReset={handleApplyReset}
                  changeFilter={changeFilter}
                  status={dealerState}
                  resetFilter={props.resetFilter}
                  resetFilters={props.resetFilters}
                  selectedTab={props.selectedTab}
                  downloadError={props.downloadError}
                  dealerId={props.dealerid}
                  dealerName={props.dealerName}
                  brand={brandValues}
                  category={catValues}
                />
              </div>
            )}
          </div>
        </div>
      )}
      {!is2wDealer && props.selectedTab !== "new" && (
        <div className="verticalLine"></div>
      )}
      {!is2wDealer && props.selectedTab !== "new" && (
        <div>
          <div className="Product-label">Location</div>
          <div className="disp_flex">
            <div className="fltrminwdth">
              <MultiCheckboxSearch
                label="State"
                options={props.stateOpts}
                onApply={handleApplyReset}
                onReset={handleApplyReset}
                changeFilter={changeFilter}
                status={stateState}
                resetFilter={props.resetFilter}
                resetFilters={props.resetFilters}
                selectedTab={props.selectedTab}
                dealerId={props.dealerid}
                dealerName={props.dealerName}
                downloadError={props.downloadError}
                brand={brandValues}
                category={catValues}
              />
            </div>
            <div className="fltrminwdth">
              <MultiCheckboxSearch
                label="City"
                options={props.cityOpts}
                onApply={handleApplyReset}
                onReset={handleApplyReset}
                changeFilter={changeFilter}
                status={cityState}
                resetFilter={props.resetFilter}
                resetFilters={props.resetFilters}
                selectedTab={props.selectedTab}
                dealerId={props.dealerid}
                dealerName={props.dealerName}
                brand={brandValues}
                category={catValues}
              />
            </div>
          </div>
        </div>
      )}
      <div className="resetAll">
        <button
          className={`${
            window.isLogistic ? "resetLabel" : ""
          } resetAllBtn resetAll ${
            is2wDealer && (props.isFilterApplied ? "" : "disableResetBtn")
          }`}
          onClick={callReset}
        >
          Reset All
        </button>
      </div>
    </div>
  );
};
export default Filters;
