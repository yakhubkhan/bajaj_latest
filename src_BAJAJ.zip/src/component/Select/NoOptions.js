import React from "react";

const NoOptions = (props) => {
  return (
    <div className="main-dropdown-wrapper">
      <div className="search-wrapper">
        <div className="search-input">
          <input
            type="search"
            onChange={props.searchOptions}
            placeholder="Search..."
            value={props.userInput}
          />
        </div>
      </div>

      <div className="searchContent">
        <div className="select-container">
          <button className="search-resetall" onClick={props.handleReset}>
            Reset
          </button>
        </div>
      </div>

      <div className="no-options"> No options</div>
    </div>
  );
};

export default NoOptions;
