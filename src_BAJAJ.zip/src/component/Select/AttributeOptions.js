import React from "react";

const AttributeOptions = (props) => {
  return (
    <div className="main-dropdown-wrapper">
      <div className="search-wrapper">
        <div className="search-input">
          <input
            type="search"
            onChange={props.searchOptions}
            placeholder="Search..."
            value={props.userInput}
          />
        </div>
      </div>

      <div className="searchContent">
        <div className="select-container">
          <div className="search-option-container">
            <label className="multicheckbox-list-item-label">
              <input
                type="checkbox"
                className="multi-list-item-checkbox"
                onChange={props.selectAllFunction}
                checked={props.selectAll}
              />
              <span className="input-span-checkbox">All</span>
            </label>
          </div>
        </div>
        <div className="multicheckbox-list">
          {props.renderSearchOption.map((searchOption, index) => (
            <div className="search-option-container" key={index}>
              <label
                role="checkbox"
                aria-checked="false"
                className="multicheckbox-list-item-label"
                htmlFor={props.searchInputClass + index}
              >
                <input
                  value={searchOption.label}
                  onChange={props.setValues}
                  className="multi-list-item-checkbox"
                  type="checkbox"
                  id={props.searchInputClass + index}
                  checked={props.isChecked(searchOption.label)}
                />
                <span className="input-span-checkbox">
                  {searchOption.label}
                </span>
              </label>
            </div>
          ))}
        </div>
        <button
          className={
            props?.checkedValues?.length === 0 ? "initalSearch" : "serach-apply"
          }
          onClick={props.handleApply}
        >
          Apply
        </button>
      </div>
    </div>
  );
};

export default AttributeOptions;
