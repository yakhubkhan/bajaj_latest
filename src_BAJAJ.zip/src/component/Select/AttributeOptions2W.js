import React from "react";

const AttributeOptions2W = (props) => {
  return (
    <div className="main-dropdown-wrapper2W">
      <div className="search-wrapper2W">
        <div className="search-input2W">
          <input
            type="search"
            onChange={props.searchOptions}
            placeholder="Search..."
            value={props.userInput}
          />
        </div>
      </div>

      <div className="searchContent2W">
        <div className="select-container">
          {/* <button className="search-selectall" onClick={props.selectAll}>
            Select All
          </button> */}
          <div className="search-option-container">
            <label className="multicheckbox-list-item-label">
              <input
                type="checkbox"
                className="multi-list-item-checkbox2W"
                onClick={props.selectAllFunction}
                checked={props.selectAll}
              />
              <span className="input-span-checkbox checkbox_text">All</span>
            </label>
          </div>
        </div>
        <div className="multicheckbox-list">
          {props.renderSearchOption.map((searchOption, index) => (
            <div className="search-option-container" key={index}>
              <label
                role="checkbox"
                aria-checked="false"
                className="multicheckbox-list-item-label"
                htmlFor={props.searchInputClass + index}
              >
                <input
                  value={searchOption.label}
                  onChange={props.setValues}
                  className="multi-list-item-checkbox2W"
                  type="checkbox"
                  id={props.searchInputClass + index}
                  checked={props.isChecked(searchOption.label)}
                />
                <span className="input-span-checkbox checkbox_text">
                  {searchOption.label}
                </span>
              </label>
            </div>
          ))}
        </div>
        <button
          className={
            props?.checkedValues?.length == 0
              ? "initalSearch2W"
              : "serach-apply2W"
          }
          // disabled={!props.checkedValues}
          onClick={props.handleApply}
        >
          Apply
        </button>
      </div>
    </div>
  );
};

export default AttributeOptions2W;
