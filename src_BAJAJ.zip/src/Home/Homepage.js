import React, { useEffect, useState } from "react";
import Header from "../Pages/Header";
import Level2Header from "../Pages/Level2Header";
import { Player,BigPlayButton } from "video-react";
// import "node_modules/video-react/dist/video-react.css";
import "../../node_modules/video-react/dist/video-react.css";
import posterImage from "../images/blankPage.png";

const Homepage = (props) => {
  const {
    supplierName,
    dealerId,
    md5value,
    level2HeaderValue,
    isParentDealer,
    setLevel2HeaderValue
  } = props;

  return (
    <div className="maindiv">
      <div id="stickyMainHeader" className="stickyMainHeader">
        <Header
          supplierName={supplierName}
          dealerid={dealerId}
          md5value={md5value}
          // callSearch={callSearch}
          // resetSearch={resetSearch}
          // searchParam={searchParam}
          // getSearchVal={getSearchVal}
        />
        {!window.is2wDealer && (
          <Level2Header
            value={level2HeaderValue}
            // isLoading={getofferslistDataResp.isLoading}
            onChange={value => setLevel2HeaderValue(value)}
            // getmagentodeliveryflagResp={props.getmagentodeliveryflagResp}
            isParentDealer={isParentDealer}
            // isIndividualDealer = {isIndividualDealer}
          />
        )}
        <Player
          fluid={false}
          position="center"
          width={"100%"}
          height={300}
          // className="gunavideoPlayer"
          playsInline
          // poster={posterImage}
          src="https://media.w3.org/2010/05/sintel/trailer_hd.mp4"
        >
          <BigPlayButton position="center" />
          </Player>
      </div>
    </div>
  );
};

export default Homepage;
