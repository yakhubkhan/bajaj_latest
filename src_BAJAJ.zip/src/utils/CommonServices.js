/* eslint-disable */
import { ExportToCsv } from "export-to-csv";
import * as Constants from "./Constant";
import React from "react";
import CryptoJS from "crypto-js";

const uploadedOfferHeader = (
  ofd,
  isDownload = false,
  isCity = false,
  subSection
) => {
  var dealerId = typeof ofd.DEALERID !== "undefined" ? ofd.DEALERID : "";
  var sku = typeof ofd.SKU !== "undefined" ? ofd.SKU : "";
  var modelId = typeof ofd.MODELID !== "undefined" ? ofd.MODELID : "";
  var state = typeof ofd.STATE !== "undefined" ? ofd.STATE : "";
  var brand = typeof ofd.BRAND !== "undefined" ? ofd.BRAND : "";
  var category = typeof ofd.CATEGORY !== "undefined" ? ofd.CATEGORY : "";
  var modelNo = typeof ofd.MODEL_NO !== "undefined" ? ofd.MODEL_NO : "";
  var name = typeof ofd.NAME !== "undefined" ? ofd.NAME : "";
  var cityId = typeof ofd.CITYID !== "undefined" ? ofd.CITYID : "";
  var cityName = typeof ofd.CITY !== "undefined" ? ofd.CITY : "";
  var sellingPrice = typeof ofd.MRP !== "undefined" ? ofd.MRP : "";
  var mop = typeof ofd.MOP !== "undefined" ? ofd.MOP : "";
  var RefPrice =
    typeof ofd.REFERENCEPRICE !== "undefined" ? ofd.REFERENCEPRICE : "";
  var BestRefPrice =
    typeof ofd.BEST_REFERENCE_PRICE !== "undefined"
      ? ofd.BEST_REFERENCE_PRICE
      : "";
  var offerPrice = typeof ofd.OFFERPRICE !== "undefined" ? ofd.OFFERPRICE : "";
  var sellerSkuId =
    typeof ofd.SELLER_SKU_ID !== "undefined" ? ofd.SELLER_SKU_ID : "";
  var prodStatus = typeof ofd.STATUS !== "undefined" ? ofd.STATUS : "";
  var inventory = typeof ofd.INVENTORY !== "undefined" ? ofd.INVENTORY : "";
  var uploadStatus =
    typeof ofd.upload_status !== "undefined" ? ofd.upload_status : "";
  var model_code_validation =
    typeof ofd.OEM_MODEL_CODE !== "undefined" && ofd.OEM_MODEL_CODE !== null
      ? ofd.OEM_MODEL_CODE
      : "";
  var installation_charges =
    typeof ofd.INSTALLATION_CHARGES !== "undefined"
      ? ofd.INSTALLATION_CHARGES
      : "";
  var checksum =
      typeof ofd.CHECKSUM !== "undefined"
        ? ofd.CHECKSUM
        : "";
  let deliveryFee =
    typeof ofd.delivery_fee !== "undefined" ? ofd.delivery_fee : "";
  let logisticsBy =
    typeof ofd.logistics_by !== "undefined" ? ofd.logistics_by : "";
  let logisticsFee =
    typeof ofd.logistics_fee_paid_by !== "undefined"
      ? ofd.logistics_fee_paid_by
      : "";
  
      var ex_Showroom_Price =
      typeof ofd.Ex_Showroom_Price !== "undefined"
        ? ofd.Ex_Showroom_Price
        : "";
        var insurance =
        typeof ofd.insurance !== "undefined"
          ? ofd.insurance
          : "";
          var rto =
          typeof ofd.RTO !== "undefined"
            ? ofd.RTO
            : "";


  var offerHeaderDesc;
  if (isCity) {
    offerHeaderDesc = [
      dealerId,
      sku,
      sellerSkuId,
      modelId,
      brand,
      category,
      modelNo,
      model_code_validation,
      name,
      cityId,
      cityName,
      state,
      sellingPrice,
      mop,
      RefPrice,
      BestRefPrice,
      offerPrice,
      prodStatus,
      inventory,
      installation_charges,
    ];
  } else if (subSection === "price") {
    offerHeaderDesc = [
      dealerId,
      sku,
      modelId,
      name,
      cityId,
      cityName,
      sellingPrice,
      mop,
      RefPrice,
      BestRefPrice,
      offerPrice,
      checksum
    ];
  } else if (subSection === "status_inventory") {
    offerHeaderDesc = [
      dealerId,
      sku,
      modelId,
      name,
      cityId,
      cityName,
      prodStatus,
      inventory,
      checksum
    ];
  } else if (subSection === "installation_charges") {
    offerHeaderDesc = [
      dealerId,
      sku,
      modelId,
      name,
      cityId,
      cityName,
      installation_charges,
      checksum
    ];
  } else if (
    subSection === "active-logistic" ||
    subSection === "parent-active-logistic"
  ) {
    offerHeaderDesc = [
      dealerId,
      sku,
      modelId,
      cityId,
      cityName,
      offerPrice,
      logisticsBy,
      logisticsFee,
      deliveryFee,
      checksum
    ];
  } else if (subSection == "tw-all") {
    offerHeaderDesc = uploadedOfferHeader2w(ofd)

  } else {
    offerHeaderDesc = [
      dealerId,
      sku,
      sellerSkuId,
      modelId,
      brand,
      category,
      modelNo,
      model_code_validation,
      name,
      cityId,
      cityName,
      state,
      sellingPrice,
      mop,
      RefPrice,
      BestRefPrice,
      offerPrice,
      prodStatus,
      inventory,
      installation_charges,
      checksum
    ];
  }
  if (!isDownload) {
    offerHeaderDesc.push(uploadStatus);
  }

  return offerHeaderDesc;
};

export const uploadedOfferHeaderLogistics = (ofd, isDownload = false) => {
  var dealerId = typeof ofd.dealer_id !== "undefined" ? ofd.dealer_id : "";
  var sku = typeof ofd.sku !== "undefined" ? ofd.sku : "";
  var modelId = typeof ofd.model_id !== "undefined" ? ofd.model_id : "";
  var category =
    typeof ofd.attribute_set_id !== "undefined" ? ofd.attribute_set_id : "";

  var cityId = typeof ofd.cityid !== "undefined" ? ofd.cityid : "";
  var cityName = typeof ofd.cityname !== "undefined" ? ofd.cityname : "";
  var offerPrice =
    typeof ofd.offer_price !== "undefined" ? ofd.offer_price : "";
  let deliveryFee =
    typeof ofd.delivery_fee !== "undefined" ? ofd.delivery_fee : "";
  let logisticsBy =
    typeof ofd.logistics_by !== "undefined" ? ofd.logistics_by : "";
  let logisticsFee =
    typeof ofd.logistics_fee_paid_by !== "undefined"
      ? ofd.logistics_fee_paid_by
      : "";

      return [
        dealerId,
        sku,
        modelId,
        cityId,
        cityName,
        offerPrice,
        logisticsBy,
        logisticsFee,
        deliveryFee,
      ];
};

export const uploadedOfferHeader2w = (ofd) => {
  var dealerId = typeof ofd.DEALERID !== "undefined" ? ofd.DEALERID : "";
  var sku = typeof ofd.SKU !== "undefined" ? ofd.SKU : "";
  var modelId = typeof ofd.MODELID !== "undefined" ? ofd.MODELID : "";
  var category =
    typeof ofd.CATEGORY !== "undefined" ? ofd.CATEGORY : "";
  var cityId = typeof ofd.CITYID !== "undefined" ? ofd.CITYID : "";
  var cityName = typeof ofd.CITY !== "undefined" ? ofd.CITY : "";
  var insurance = typeof ofd.INSURANCE_PRICE !== "undefined" ? ofd.INSURANCE_PRICE : "";
  var inventory = typeof ofd.INVENTORY !== "undefined" ? ofd.INVENTORY : "";
  // var prod_status = typeof ofd.inventory !== "undefined" ? ofd.inventory : "";
  // var maxORP = typeof ofd.inventory !== "undefined" ? ofd.inventory : "";

  var brand = typeof ofd.BRAND !== "undefined" ? ofd.BRAND : "";
  var name = typeof ofd.NAME !== "undefined" ? ofd.NAME : "";
  var state = typeof ofd.STATE !== "undefined" ? ofd.STATE : "";
  var max_orp =
  typeof ofd.MAX_ORP !== "undefined"
    ? ofd.MAX_ORP
    : "";
    var min_ex_Showroom_Price =
    typeof ofd.min_ex_Showroom_Price !== "undefined"
      ? ofd.min_ex_Showroom_Price
      : "";
  var ex_Showroom_Price =
  typeof ofd.EX_SHOWROOM_PRICE !== "undefined"
    ? ofd.EX_SHOWROOM_PRICE
    : "";
    var insurance =
    typeof ofd.INSURANCE_PRICE !== "undefined"
      ? ofd.INSURANCE_PRICE
      : "";
      var rto =
      typeof ofd.RTO_CHARGES !== "undefined"
        ? ofd.RTO_CHARGES
        : "";
        var inventory = typeof ofd.INVENTORY !== "undefined" ? ofd.INVENTORY : "";
        var status = typeof ofd.STATUS !== "undefined" ? ofd.STATUS : "";



        return [
          dealerId,
          sku,
          modelId,
          brand,
          category,
          name,
          cityId,
          cityName,
          state,
          max_orp,
          ex_Showroom_Price,
          insurance,
          rto,
          inventory,
          status
        ];
};

export const getArrangedData = (offersData, subSection) => {
  return offersData.map((item, index) => {
    let offerPrice = item.offer_price ? item.offer_price : 0;
    let cityId = typeof item.cityid !== "undefined" ? item.cityid : "";
    let cityName = typeof item.cityname !== "undefined" ? item.cityname : "";
    let name =
      typeof item.cic !== "undefined" && item.cic !== "" ? item.cic : item.sku;
    let modelId = typeof item.model_id !== "undefined" ? item.model_id : "";
    let inventory = typeof item.inventory !== "undefined" ? item.inventory : 0;
    let referencePrice =
      typeof item.referenceprice !== "undefined" ? item.referenceprice : "";
    let bestreferencePrice =
      typeof item.best_reference_price !== "undefined"
        ? item.best_reference_price
        : 0;
    let stateName = typeof item.statename !== "undefined" ? item.statename : "";
    let category =
      typeof item.attribute_set_id !== "undefined" ? item.attribute_set_id : 0;
    let model_no = typeof item.model_no !== "undefined" ? item.model_no : 0;
    let brand = typeof item.brand !== "undefined" ? item.brand : 0;
    let sellerSkuId =
      typeof item.seller_sku_id !== "undefined" ? item.seller_sku_id : 0;
    let dealerId = typeof item.dealer_id !== "undefined" ? item.dealer_id : "";
    let sellingPrice =
      typeof item.selling_price !== "undefined" ? item.selling_price : "";
    let mopPrice = typeof item.mop_price !== "undefined" ? item.mop_price : "";
    let sku = typeof item.sku !== "undefined" ? item.sku : "";
    let prodStatus =
      typeof item.prod_status !== "undefined" ? item.prod_status : "";
    let model_code_validation =
      typeof item.model_code_validation !== "undefined" &&
      item.model_code_validation !== null
        ? item.model_code_validation
        : "";
    let installation_charges =
      typeof item.installation_charges !== "undefined"
        ? item.installation_charges
        : "";
    if (subSection === "price") {

      const row = [
        dealerId,
        sku,
        modelId,
        name,
        cityId,
        cityName,
        sellingPrice,
        mopPrice,
        referencePrice,
        bestreferencePrice,
        offerPrice,
      ];
      return [...row, ...[getmd5fromrowArray(row, subSection)]];
    } else if (subSection === "status_inventory") {
      const row = [
        dealerId,
        sku,
        modelId,
        name,
        cityId,
        cityName,
        prodStatus,
        inventory,
      ];

      return [...row, ...[getmd5fromrowArray(row, subSection)]];

    } else if (subSection === "installation_charges") {
      const row = [
        dealerId,
        sku,
        modelId,
        name,
        cityId,
        cityName,
        installation_charges,
      ];

      return [...row, ...[getmd5fromrowArray(row, subSection)]];
    } else {

      const row = [
        dealerId,
        sku,
        sellerSkuId,
        modelId,
        brand,
        category,
        model_no,
        model_code_validation,
        name,
        cityId,
        cityName,
        stateName,
        sellingPrice,
        mopPrice,
        referencePrice,
        bestreferencePrice,
        offerPrice,
        prodStatus,
        inventory,
        installation_charges,
      ];

      return [...row, ...[getmd5fromrowArray(row, subSection)]];
    }
  });
};

export const getArrangedLogisticData = (
  offersData,
  getmagentodeliveryflagResp
) => {
  const getLogisticByFalgValue = (logisticByValue) => {
    const matchedObj = getmagentodeliveryflagResp?.data?.payload.find(
      (item) => item.delivery_by === logisticByValue
    );
    return matchedObj ? matchedObj.flag : "";
  };
  return offersData.map((item) => {
    let cityId =
      typeof item.cityid !== "undefined" && item.cityid !== null
        ? item.cityid
        : "";
    let cityName =
      typeof item.cityname !== "undefined" && item.cityname !== null
        ? item.cityname
        : "";
    let modelId =
      typeof item.model_id !== "undefined" && item.model_id !== null
        ? item.model_id
        : "";
    let dealerId =
      typeof item.dealer_id !== "undefined" && item.dealer_id !== null
        ? item.dealer_id
        : "";
    let sku =
      typeof item.sku !== "undefined" && item.sku !== null ? item.sku : "";
    let deliveryFee =
      typeof item.delivery_fee !== "undefined" && item.delivery_fee !== null
        ? item.delivery_fee
        : "";
    let logisticsBy =
      typeof item.logistics_by !== "undefined"
        ? getLogisticByFalgValue(item.logistics_by)
        : "";
    let logisticsFee =
      typeof item.logistics_fee !== "undefined" && item.logistics_fee !== null
        ? item.logistics_fee.charAt(0)
        : "";
    let offerPrice =
      typeof item.offer_price !== "undefined" && item.offer_price !== null
        ? item.offer_price
        : 0;

    const row = [
      dealerId,
      sku,
      modelId,
      cityId,
      cityName,
      offerPrice,
      logisticsBy,
      logisticsFee,
      deliveryFee,
    ];

    return [...row, ...[getmd5fromrowArrayLogistics(row)]];
  });
};

export const getArranged2wData = (
  offersData
) => {
  return offersData.map((item, index) => {
    let cityId =
      typeof item.cityid !== "undefined" && item.cityid != null
        ? item.cityid
        : "";
    let cityName =
      typeof item.city !== "undefined" && item.city != null
        ? item.city
        : "";
    let modelId =
      typeof item.model_id !== "undefined" && item.model_id != null
        ? item.model_id
        : "";
    let brand = typeof item.brand !== "undefined" ? item.brand : 0;
    let category =
    typeof item.category !== "undefined" ? item.category : "";
    let name =
    typeof item.variants !== "undefined" && item.variants !== "" ? item.variants : item.sku;
    let stateName = typeof item.statename !== "undefined" ? item.statename : "";


    let dealerId =
      typeof item.dealer_id !== "undefined" && item.dealer_id != null
        ? item.dealer_id
        : "";
    let sku =
      typeof item.sku !== "undefined" && item.sku != null ? item.sku : "";

      let minExShowroomPrice =
      typeof item.minExShowroomPrice !== "undefined" && item.minExShowroomPrice != null
        ? item.minExShowroomPrice
        : 0;

    let exShowroomPrice =
      typeof item.Ex_Showroom_Price !== "undefined" && item.Ex_Showroom_Price != null
        ? item.Ex_Showroom_Price
        : 0;

    let RTO =
      typeof item.RTO !== "undefined" && item.RTO != null
        ? item.RTO
        : 0;
    let insurance =
      typeof item.Insurance !== "undefined" && item.Insurance != null
        ? item.Insurance
        : 0;
    let inventory =
      typeof item.inventory !== "undefined" && item.inventory != null
        ? item.inventory
        : 0;
    let prod_status =
      typeof item.prod_status !== "undefined" && item.prod_status != null
        ? item.prod_status
        : 0;
    let maxORP =
        typeof item.Max_ORP !== "undefined" && item.Max_ORP != null
          ? item.Max_ORP
          : 0;
    let onRoadPrice =
          typeof item.on_road_price !== "undefined" && item.on_road_price != null
            ? item.on_road_price
            : 0;

    return [
      dealerId,
      sku,
      modelId,
      brand,
      category,
      name,
      cityId,
      cityName,
      stateName,
      maxORP,
      exShowroomPrice,
      insurance,
      RTO,
      inventory,
      prod_status
    ];
  });
};

export const downloadCallback = (
  downloadType,
  downloadOffersData,
  subSection
) => {

  var fileName = downloadType === "city" ? "City" : "Offers";

  let headers = [];

  if(window.isLogistic) {
    headers=  [...Constants.downloadLogisticCsvHeader,...["CHECKSUM"]];

  }else if(window.is2wDealer) {
    headers= Constants.download2wCsvHeader

  } else {
    headers =
    downloadType === "city"
      ? Constants.downloadCityCsvHeader
      : Constants.getHeaderData(subSection);
  }
  var fileName = downloadType === "city" ? "City" : "Offers";

  const fullData = [headers, ...downloadOffersData];
  console.log("fullData", fullData);


  const csvString = fullData.map(row =>
    row
    .map(String)  // convert every value to String
    .map(v => v.replaceAll('"', '""'))  // escape double colons
    .join(',')  // comma-separated
  ).join('\r\n');

  var blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
  var url = URL.createObjectURL(blob);

  // Create a link to download it
  var pom = document.createElement('a');
  pom.href = url;
  pom.setAttribute('download', fileName);
  pom.click();
};

export const convertToLabelValueObjs = (array) => {
  let catarr = [];
  array.map((val, ind) => {
    let categoryobj = {};
    categoryobj["label"] = val;
    categoryobj["value"] = ind;
    catarr.push(categoryobj);
  });
  return catarr;
};

export const checkSkuLowStockInventory = (sku, selectedTab) => {
  return sku.inventory > 0 && sku.inventory <= 5 && selectedTab == "active";
};

export const checkSkuStockOutInventory = (sku,selectedTab) => {
  return sku.inventory === 0  && selectedTab == "inactive";
}
export const getmd5fromrow = (row, key) => {
  let checksum_modify ="";

  const sellerSkuId = row["SELLER_SKU_ID"]  == "null" ? "" : row["SELLER_SKU_ID"];
  const offerPrice = row["OFFERPRICE"] == "null" ? "" : `${parseInt(row["OFFERPRICE"])}`;
  const status = row["STATUS"] == "null" ? "" : row["STATUS"];
  const inventory = row["INVENTORY"] == "null" ? "" : row["INVENTORY"];
  const instChrgs = row["INSTALLATION_CHARGES"] == "null" ? "" : row["INSTALLATION_CHARGES"]

  switch (key) {
    case "all":
      checksum_modify =
      sellerSkuId +
      offerPrice +
      status +
      inventory +
      instChrgs
      break;
    case "price":
      checksum_modify = offerPrice;
      break;
    case "status_inventory":
      checksum_modify = status + inventory;
      break;
    case "installation_charges":
      checksum_modify = instChrgs;
      break;
    default:
      checksum_modify =
      sellerSkuId +
      offerPrice +
      status +
      inventory +
      instChrgs;
      break;
  }
  return checksum_modify ? CryptoJS.MD5(String(checksum_modify)).toString() : ""
};

export const getmd5fromrowArray = (row, key) => {
  debugger;
  let checksum_modify = "";
  switch (key) {
    case "all":
    case "new-product":
      checksum_modify = `${row[2] == null || row[2] == "null" ? "" : row[2]}${
        row[16] == null || row[16] == "null" ? "" : row[16]
      }${row[17] == null || row[17] == "null" ? "" : row[17]}${
        row[18] == null || row[18] == "null" ? "" : row[18]
      }${row[19] == null || row[19] == "null" ? "" : row[19]}`;
      break;
    case "price":
      checksum_modify = `${row[10]}`;
      break;
    case "status_inventory":
      checksum_modify = `${row[6]}${row[7]}`;
      break;
    case "installation_charges":
      checksum_modify = `${row[6]}`;
      break;
    default:
      checksum_modify = `${row[2] == null || row[2] == "null" ? "" : row[2]}${
        row[16] == null || row[16] == "null" ? "" : row[16]
      }${row[17] == null || row[17] == "null" ? "" : row[17]}${
        row[18] == null || row[18] == "null" ? "" : row[18]
      }${row[19] == null || row[19] == "null" ? "" : row[19]}`;
      break;
  }
  return checksum_modify
    ? CryptoJS.MD5(String(checksum_modify)).toString()
    : "";
};

export const getmd5fromrowArrayLogistics = (row) => {
  let checksum_modify = `${row[6] == null ? "" : row[6]}${
        row[7] == null ? "" : row[7]
      }${row[8] == null ? "" : row[8]}`;

  return checksum_modify ? CryptoJS.MD5(String(checksum_modify)).toString() : "";
};

export const getmd5fromrowLogistics = (row) => {
  const checksum_modify = row.LOGISTICS_BY + row["LOGISTICS_FEE (Paid By)"] + row.DELIVERY_FEE
  return checksum_modify ? CryptoJS.MD5(String(checksum_modify)).toString() : ""
};

export default uploadedOfferHeader;
