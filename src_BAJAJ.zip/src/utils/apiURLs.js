// import React from "react";

export const dashboardApi = () => {
  if (window.isLogistic) {
    return "/offerslogisticdashboard/" + window.dealerId;
  } else if (window.is2wDealer) {
    return "/twowheelerdashboard/" + window.dealerId;
  } else {
    return "/offersdashboard/" + window.dealerId;
  }
};

export const saveActionApi = () => {
  if (window.isLogistic) {
    return "/updateofferlogisticaction";
  } else if (window.is2wDealer) {
    return "/updateofferaction";
  } else {
    return "/updateofferaction";
  }
};

export const getFilterApiURL = () => {
  if (window.isLogistic) {
    return "/getlogisticfilters";
  } else if (window.is2wDealer) {
    return "/gettowheelerfilters";
  } else {
    return "/getfilters";
  }
};

export const getofferListApiURL = () => {
  if (window.isLogistic) {
    return "/getlogisticofferslist";
  } else if (window.is2wDealer) {
    return "/gettwowheelerofferslist";
  } else {
    return "/getofferslist";
  }
};

export const requestDownloadApiURL = () => {
  if (window.isLogistic) {
    return "/requestdownloadofferslogistics";
  } else if (window.is2wDealer) {
    return "/requestdownloadoffers";
  } else {
    return "/requestdownloadoffers";
  }
};

export const getcsvdownloadsApiURL = () => {
  if (window.isLogistic) {
    return "/getcsvdownloadslogistics";
  } else if (window.is2wDealer) {
    return "/getcsvdownloads2w";
  } else {
    return "/getcsvdownloads";
  }
};

export const getAuditLogApiURL = () => {
  if (window.isLogistic) {
    return "/massofferaction";
  } else if (window.is2wDealer) {
    return "/twowheelermassofferaction";
  } else {
    return "/massofferaction";
  }
}
export const inventoryOfferListListAPI = () => {
  return "/inventoryrequestlist";
};

export const getinventorycsvdownloadsApiURL = () => {
  return "/getinventorycsvdownloads";
};

export const inventoryFilterListListAPI = () => {
  return "/inventoryfilterlist";
}
export const returnOfferListtAPI = () => {
  return "/getreturnandreplacementlist";
};

export const saveActionReplacement = () => {
  return "/updatereturnandreplacementlist";
};
