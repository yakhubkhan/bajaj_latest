export const resps = {
  status: "failed",
  payload: null,
  errorBean: [
    {
      errorCode: 5,
      errorMessage: "Please enter offer price",
    },
  ],
};
