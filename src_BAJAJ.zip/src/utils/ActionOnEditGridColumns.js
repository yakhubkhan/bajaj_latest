import SaveAction from "../component/Grid/SaveAction";
import dateField from "../component/Grid/DateField";
import Price from "../component/Grid/Price";
import Stock, { StockValueEditor } from "../component/Grid/Stock";
import Status from "../component/Grid/Status";
import CreationTime from "../component/Grid/CreationTime";
import MrpMop from "../component/Grid/MrpMop";
import visibleOnWebsite from "../component/Grid/VisibleOnWebsite";
import imgComponent from "../component/Grid/ImageComponent";
import SellerSku from "../component/Grid/SellerSku";
import { cellbg } from "../component/Grid/GridColumns";

export const gridColumns = () => {
  return [
    {
      headerName: "All",
      field: "all",
      width: 80,
      minWidth: 80,
      maxWidth: 80,
      cellClass: cellbg,
      headerClass: "allHeaderEdit",
      pinned: "left",
      lockPinned: true,
      autoHeight: true,
      editable: false,
      lockPosition: true,
      checkboxSelection: function (params) {
        return params.columnApi.getRowGroupColumns().length === 0;
      },
      headerCheckboxSelection: function (params) {
        return params.columnApi.getRowGroupColumns().length === 0;
      },
      cellStyle: {
        backgroundColor: "#EBF3FF",
      },
    },
    {
      headerName: "SKU",
      field: "sku",
      cellClass: cellbg,
      resizable: true,
      width: 100,
      minWidth: 100,
      maxWidth: 236,
      cellStyle: {
        "text-overflow": "clip",
        "word-wrap": "break-word",
        overflow: "visible",
        "white-space": "normal",
        "user-select": "text",
        backgroundColor: "#EBF3FF",
      },
    },
    {
      headerName: "Model ID",
      field: "model_id",
      width: 70,
      minWidth: 70,
      maxWidth: 150,
      cellClass: cellbg,
      cellStyle: {
        backgroundColor: "#EBF3FF",
      },
    },
    {
      headerName: "Stock",
      cellEditor: "StockValueEditor",
      field: "inventory",
      editable: true,
      cellRenderer: "Stock",
      width: 70,
      minWidth: 70,
      maxWidth: 150,
      cellClass: cellbg,
      cellStyle: {
        backgroundColor: "#EBF3FF",
      },
    },
    {
      headerName: "Price",
      field: "offer_price",
      editable: true,
      cellRenderer: "Price",
      width: 90,
      minWidth: 90,
      maxWidth: 150,
      cellClass: cellbg,
      cellStyle: {
        backgroundColor: "#EBF3FF",
      },
    },
    {
      headerName: "Status",
      field: "prod_status",
      cellRenderer: "Status",
      width: 80,
      minWidth: 80,
      maxWidth: 250,
      cellClass: cellbg,
      cellStyle: {
        backgroundColor: "#EBF3FF",
      },
    },
    {
      headerName: "Seller SKU ID",
      field: "seller_sku_id",
      editable: true,
      cellRenderer: "SellerSku",
      width: 90,
      minWidth: 50,
      maxWidth: 150,
      cellClass: cellbg,
      cellStyle: {
        backgroundColor: "#EBF3FF",
      },
    },
    {
      field: "dealer_id",
      headerName: "Dealer ID",
      cellClass: cellbg,
      width: 70,
      minWidth: 70,
      maxWidth: 150,
      cellStyle: {
        backgroundColor: "#EBF3FF",
      },
    },
    {
      headerName: "MRP/MOP",
      field: "MRP/MOP",
      cellRenderer: "MrpMop",
      width: 82,
      minWidth: 82,
      maxWidth: 250,
      cellClass: cellbg,
      cellStyle: {
        backgroundColor: "#EBF3FF",
      },
    },

    {
      headerName: "Best Reference Price",
      field: "best_reference_price",
      width: 82,
      minWidth: 82,
      maxWidth: 250,
      cellClass: cellbg,
      cellStyle: {
        backgroundColor: "#EBF3FF",
      },
    },
    {
      field: "cityname",
      headerName: "CITY",
      cellClass: cellbg,
      width: 65,
      minWidth: 65,
      maxWidth: 150,
      cellStyle: {
        backgroundColor: "#EBF3FF",
      },
    },
    {
      field: "referenceprice",
      headerName: "Ref Price",
      cellClass: cellbg,
      width: 70,
      minWidth: 70,
      maxWidth: 150,
      cellStyle: {
        backgroundColor: "#EBF3FF",
      },
    },
    {
      headerName: "Action",
      field: "action",
      cellRenderer: "saveaction",
      width: 90,
      minWidth: 50,
      maxWidth: 150,
      pinned: "right",
      lockPinned: true,
      cellClass: cellbg,
      cellStyle: {
        backgroundColor: "#EBF3FF",
      },
    },
  ];
};

export const dropdownOptions = () => {
  return [
    { name: "Match MOP", value: "matchmop" },
    { name: "Match MRP", value: "matchmrp" },
    { name: "Active All", value: "activate" },
    { name: "Inactive All", value: "deactivate" },
  ];
};

export const framecomponents = () => {
  return {
    saveaction: SaveAction,
    dateField: dateField,
    Price: Price,
    Stock: Stock,
    StockValueEditor: StockValueEditor,
    creationTime: CreationTime,
    MrpMop: MrpMop,
    visibleOnWebsite: visibleOnWebsite,
    imgComponent: imgComponent,
    Status: Status,
    SellerSku: SellerSku,
  };
};
