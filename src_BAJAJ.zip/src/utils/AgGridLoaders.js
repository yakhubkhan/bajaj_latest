import Skeleton from "react-loading-skeleton";
import downarrow from "../images/downarrow.png";
import React from "react";

export const defaultdridcols = (props) => {
  return [
    {
      headerName: "All",
      field: "all",
      width: 40,
      minWidth: 40,
      maxWidth: 80,
      cellClass: "no-border",
      pinned: "left",
      lockPinned: true,
      lockPosition: true,
      headerComponent: props.isHeaderLoading ? "skuHeadercomponent" : null,
      checkboxSelection: function (params) {
        // return params.columnApi.getRowGroupColumns().length === 0;
        return true;
      },
      headerCheckboxSelection: function (params) {
        // return params.columnApi.getRowGroupColumns().length === 0;
        return true;
      },
    },
    {
      headerName: "SKU",
      field: "sku",
      cellClass: "no-border skuloaderCell",
      resizable: true,
      // width: 100,
      // minWidth: 90,
      // maxWidth: 236,
      cellRenderer: "skucomponent",
      headerClass: 'skuHeaderClass',
      headerComponent: props.isHeaderLoading ? "skuHeadercomponent" : null,
      cellStyle: {
        "text-overflow": "clip",
        "word-wrap": "break-word",
        overflow: "visible",
        "white-space": "normal",
        "user-select": "text",
        // width: '15vw'
      },
    },
    {
      headerName: "Model ID",
      field: "model_id",
      cellRenderer: "modelcomponent",
      headerComponent: props.isHeaderLoading
        ? "commonHeadermodelcomponent"
        : null,
      width: 60,
      minWidth: 30,
      maxWidth: 150,
      
    },
    {
      headerName: "OEM Model Code",
      field: "model_code_validation",
      cellRenderer: "OEMmodelcomponent",
      headerComponent: props.isHeaderLoading
        ? "commonHeadermodelcomponent"
        : null,
      width: 90,
      minWidth: 50,
      maxWidth: 150,
    },
    {
      headerName: "MRP/MOP",
      field: "MRP/MOP",
      cellRenderer: "MrpMop",
      width: 82,
      minWidth: 82,
      maxWidth: 250,
      headerComponent: props.isHeaderLoading
        ? "commonHeadermodelcomponent"
        : null,
    },
    {
      headerName: "Stock",
      field: "inventory",
      cellRenderer: "Stock",
      width: 60,
      minWidth: 50,
      maxWidth: 150,
      headerComponent: props.isHeaderLoading
        ? "commonHeadermodelcomponent"
        : null,
    },
    {
      headerName: "Price",
      field: "offer_price",
      cellRenderer: "Price",
      width: 90,
      minWidth: 50,
      maxWidth: 150,
      headerComponent: props.isHeaderLoading
        ? "commonHeadermodelcomponent"
        : null,
      cellStyle: { width: "141px !important" },
    },
    // {
    //   headerName: "Best Reference Price",
    //   field: "best_reference_price",
    //   cellRenderer: "BestReferencePrice",
    //   width: 82,
    //   minWidth: 82,
    //   maxWidth: 250,
    //   headerComponent: props.isHeaderLoading
    //     ? "commonHeadermodelcomponent"
    //     : null,
    //   cellStyle: { width: "120px !important" },
    // },
    {
      headerName: "Status",
      field: "prod_status",
      cellRenderer: "Status",
      width: 82,
      minWidth: 82,
      maxWidth: 250,
      headerComponent: props.isHeaderLoading
        ? "commonHeadermodelcomponent"
        : null,
      cellStyle: { width: "100px !important", Right: "220px !important" },
    },
    {
      headerName: "Seller SKU ID",
      field: "seller_sku_id",
      cellRenderer: "SellerSku",
      width: 90,
      minWidth: 50,
      maxWidth: 150,
      headerComponent: props.isHeaderLoading
        ? "commonHeadermodelcomponent"
        : null,
      cellStyle: { width: "120px !important" },
    },

    {
      headerName: "Action",
      field: "action",
      cellRenderer: "saveaction",
      cellClass: "no-border",
      width: 90,
      minWidth: 50,
      maxWidth: 150,
      headerComponent: props.isHeaderLoading
        ? "commonHeadermodelcomponent"
        : null,
      pinned: "right",
      lockPinned: true,
    },
  ];
};
export const frameworkComponents = 
  {
    skucomponent: () => (
      <div style={{ lineHeight: "15px", textAlign: "left" }}>
        <Skeleton highlightColor="#C0C0C0" width="80%" borderRadius="0" />
        <Skeleton highlightColor="#C0C0C0" borderRadius="0" />
        <Skeleton highlightColor="#C0C0C0" width="90%" borderRadius="0" />
      </div>
    ),
    modelcomponent: () => (
      <Skeleton highlightColor="#C0C0C0" borderRadius="0" />
    ),
    OEMmodelcomponent: () => (
      <Skeleton highlightColor="#C0C0C0" borderRadius="0" />
    ),
    MrpMop: () => (
      <div>
        <Skeleton highlightColor="#C0C0C0" borderRadius="0" />
        <Skeleton
          highlightColor="#C0C0C0"
          containerClassName="mrpSecondLoaderContainer"
          width="90%"
          borderRadius="0"
        />
      </div>
    ),
    Stock: () => (
      <Skeleton
        highlightColor="#C0C0C0"
        containerClassName="stockLoaderContainer"
        borderRadius="0"
      />
    ),
    Price: () => (
      <Skeleton
        highlightColor="#C0C0C0"
        containerClassName="priceLoaderContainer"
        borderRadius="0"
      />
    ),
    // BestReferencePrice: () => (
    //   <Skeleton highlightColor="#C0C0C0" borderRadius="0" />
    // ),
    Status: () => (
      <div className="statusLoaderMain">
        <Skeleton
          highlightColor="#C0C0C0"
          containerClassName="statusLoaderContainer"
          borderRadius="0"
        />
        <img alt = "" className="downArrowStatus" src={downarrow} />
      </div>
    ),
    SellerSku: () => <Skeleton highlightColor="#C0C0C0" borderRadius="0" />,
  }
;
export const headerLoaderComponents = {
  skuHeadercomponent: () => (
    <Skeleton width="50px" highlightColor="#C0C0C0" borderRadius="0" />
  ),
  commonHeadermodelcomponent: () => (
    <Skeleton width="60px" highlightColor="#C0C0C0" borderRadius="0" />
  ),
};
export const defaultColDef = [
  {
    sortable: true,
    resizable: true,
  },
];
