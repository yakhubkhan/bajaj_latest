const baseUrl = () => {
  return "https://bajajmall.in/emistore/media/catalog/product"
  let baseurl = "";
  if (window.location.hostname === "localhost") {
    baseurl = "https://bajajmall.in/emistore/media/catalog/product";
  } else if (window.location.hostname === "bfsd.uat.bfsgodirect.com") {
    baseurl = "https://bfsd.uat.bfsgodirect.com/emistore/media/catalog/product";
  } else if (window.location.hostname === "www.bajajfinservmarkets.in") {
    baseurl =
      "https://www.bajajfinservmarkets.in/emistore/media/catalog/product";
  } else if (window.location.hostname === "bfsd.qa.bfsgodirect.com") {
    baseurl = "https://bfsd.qa.bfsgodirect.com/emistore/media/catalog/product";
  }
  return baseurl;
};

export default baseUrl;
