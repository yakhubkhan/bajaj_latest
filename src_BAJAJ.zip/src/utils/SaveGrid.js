export const successresps = {
  status: "success",
  payload: null,
  errorBean: [
    {
      errorCode: 10,
      errorMessage: "Successfully updated",
    },
  ],
};

export const blankdetails = {
  status: "failed",
  payload: null,
  errorBean: [
    {
      errorCode: 5,
      errorMessage: "Please fill blank fields",
    },
  ],
};
