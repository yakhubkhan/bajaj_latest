import lowStockNotification from "../images/lowStockNotification.svg"
import outOfStockNotification from "../images/outOfStockNotification.svg"
import expiredNotification from "../images/expiredNotification.svg"
import newCatalogNotification from "../images/newCatalogNotification.svg"
import autoscaledNotification from "../images/autoscaledNotification.svg"
import deactivatedNotification from "../images/deactivatedNotification.svg"
import hotSellingNotification from "../images/hotSellingNotification.svg"
import moment from "moment"

export const actnonslctd = [
  { name: "View Audit Log", value: "auditlog" },
  { name: "Match MOP", value: "matchmop" },
  { name: "Match MRP", value: "matchmrp" },
  { name: "Edit", value: "edit" },
];

export const actnonslctdNew = [
  { name: "Match MOP", value: "matchmop" },
  { name: "Match MRP", value: "matchmrp" },
  { name: "Edit", value: "edit" },
];
export const actnonslctd2W = [
  // { name: "View Audit Log", value: "auditlog" },
  { name: "View Audit Log", value: "auditlog" },
];
export const uploadOption2w = () => {
  return [
    {
      name: "All",
      uploadType: "All",
      key: "tw-all",
      headerDescriptionKey: "offer_2w_header_description",
      headerSampleKey: "offer_2w_header_sample",
      processURL: "/upload/process_csv_tw.php",
      priceManagementURL: "/upload/tw_management.php",
    },
  ];
};
export const logisticUploadOption = () => {
  return {
    name: "",
    uploadType: "",
    key: "active-logistic",
    headerDescriptionKey: "logistic_header_description",
    headerSampleKey: "logistic_header_sample",
    processURL: "/upload/process_csv_logistic.php",
    priceManagementURL: "/upload/logistic_management.php",
  };
};
export const logisticParentUploadOption = () => {
  return {
    name: "",
    uploadType: "",
    key: "parent-active-logistic",
    headerDescriptionKey: "logistic_header_description",
    headerSampleKey: "logistic_header_sample",
    processURL: "/upload/process_csv_logistic.php",
    priceManagementURL: "/upload/parent_logistic_upload.php",
  };
};

export const uploadOptionForNew = () => {
  return [
    {
      name: "All",
      uploadType: "",
      key: "",
      headerDescriptionKey: "offer_header_description",
      headerSampleKey: "offer_header_sample",
      processURL: "/upload/process_csv.php",
      priceManagementURL: "/upload/price_management.php",
    },
  ];
};

export const uploadRROptions = () => {
  return [
    {
      name: "All",
      uploadType: "All",
      key: "all",
      headerDescriptionKey: "RR_header_description",
      headerSampleKey: "RR_header_sample",
      processURL: "/upload/process_csv_rr.php",
      priceManagementURL: "/upload/price_manegement_rr.php",
    }
  ];
};

export const uploadOptions = () => {
  return [
    {
      name: "All",
      uploadType: "All",
      key: "all",
      headerDescriptionKey: "offer_header_description",
      headerSampleKey: "offer_header_sample",
      processURL: "/upload/process_csv.php",
      priceManagementURL: "/upload/price_management.php",
    },
    {
      name: "Price",
      uploadType: "Price",
      key: "price",
      headerDescriptionKey: "offer_price_header_description",
      headerSampleKey: "offer_price_header_sample",
      processURL: "/upload/process_csv_price.php",
      priceManagementURL: "/upload/price_management_price.php",
    },
    {
      name: "Status & Inventory",
      uploadType: "Status & Inventory",
      key: "status_inventory",
      headerDescriptionKey: "offer_status_inventory_header_description",
      headerSampleKey: "offer_status_inventory_header_sample",
      processURL: "/upload/process_csv_status_inventory.php",
      priceManagementURL: "/upload/price_management_status_inventory.php",
    },
    {
      name: "Installation charges",
      uploadType: "Installation charges",
      key: "installation_charges",
      headerDescriptionKey: "offer_installation_charges_header_description",
      headerSampleKey: "offer_installation_charges_header_sample",
      processURL: "/upload/process_csv_installation_charges.php",
      priceManagementURL: "/upload/price_management_installation_charges.php",
    },
  ];
};

export const parentUploadOptionforNew = () => {
  return [
    {
      name: "All",
      uploadType: "",
      key: "All",
      headerDescriptionKey: "offer_header_description",
      headerSampleKey: "offer_header_sample",
      processURL: "/upload/process_csv.php",
      priceManagementURL: "/upload/parent_price_upload.php",
    },
  ];
};
export const parentUploadOptions = () => {
  return [
    {
      name: "All",
      uploadType: "All",
      key: "all",
      headerDescriptionKey: "offer_header_description",
      headerSampleKey: "offer_header_sample",
      processURL: "/upload/process_csv.php",
      priceManagementURL: "/upload/parent_price_upload.php",
    },
    {
      name: "Price",
      uploadType: "Price",
      key: "price",
      headerDescriptionKey: "offer_header_description",
      headerSampleKey: "offer_header_sample",
      processURL: "/upload/process_csv_price.php",
      priceManagementURL: "/upload/parent_price_upload_price.php",
    },
    {
      name: "Status & Inventory",
      uploadType: "Status & Inventory",
      key: "status_inventory",
      headerDescriptionKey: "offer_header_description",
      headerSampleKey: "offer_header_sample",
      processURL: "/upload/process_csv_status_inventory.php",
      priceManagementURL: "/upload/parent_price_upload_status_inventory.php",
    },
  ];
};

export const csvHeader = [
  "DEALERID",
  "SKU",
  "SELLER_SKU_ID",
  "MODELID",
  "BRAND",
  "CATEGORY",
  "MODEL_NO",
  "OEM_MODEL_CODE",
  "NAME",
  "CITYID",
  "CITY",
  "STATE",
  "MRP",
  "MOP",
  "REFERENCEPRICE",
  "BEST_REFERENCE_PRICE",
  "OFFERPRICE",
  "STATUS",
  "INVENTORY",
  "INSTALLATION_CHARGES",
  "DELIVERY TAT (HOURS)",
  "UPLOAD STATUS",
];

// export const downloadCsvHeaderRR = [
//   "DEALERID",
//   "SKU",
//   "SELLER_SKU_ID",
//   "MODELID",
//   "CITYID",
//   "CITY",
//   "SERVICETYPE",
//   "TAT",
// ];

export const downloadCsvHeader = [
  "DEALERID",
  "SKU",
  "SELLER_SKU_ID",
  "MODELID",
  "BRAND",
  "CATEGORY",
  "MODEL_NO",
  "OEM_MODEL_CODE",
  "NAME",
  "CITYID",
  "CITY",
  "STATE",
  "MRP",
  "MOP",
  "REFERENCEPRICE",
  "BEST_REFERENCE_PRICE",
  "OFFERPRICE",
  "STATUS",
  "INVENTORY",
  "INSTALLATION_CHARGES",
];

export const priceCSVHeader = [
  "DEALERID",
  "SKU",
  "MODELID",
  "NAME",
  "CITYID",
  "CITY",
  "MRP",
  "MOP",
  "REFERENCEPRICE",
  "BEST_REFERENCE_PRICE",
  "OFFERPRICE",
];

export const statusInventeryCSVHeader = [
  "DEALERID",
  "SKU",
  "MODELID",
  "NAME",
  "CITYID",
  "CITY",
  "STATUS",
  "INVENTORY",
];

export const instalationChargesCSVHeader = [
  "DEALERID",
  "SKU",
  "MODELID",
  "NAME",
  "CITYID",
  "CITY",
  "INSTALLATION_CHARGES",
];

export const downloadLogisticCsvHeader = [
  "DEALERID",
  "SKU",
  "MODELID",
  "CITYID",
  "CITY",
  "OFFERPRICE",
  "LOGISTICS_BY",
  "LOGISTICS_FEE (Paid By)",
  "DELIVERY_FEE",
];

export const download2wCsvHeader = [
  "DEALERID",
  "SKU",
  "MODELID",
  "BRAND",
  "CATEGORY",
  "NAME",
  "CITYID",
  "CITY",
  "STATE",
  "MAX_ORP",
  // "Min_EX_SHOWROOM_PRICE",
  "EX_SHOWROOM_PRICE",
  "INSURANCE_PRICE",
  "RTO_CHARGES",
  "INVENTORY",
  "STATUS",
];

export const getHeaderData = (subSection,isParentUpload) => {
  let headers = []
  if(subSection === 'price'){
    headers = priceCSVHeader
  } else if(subSection === 'status_inventory') {
    headers = statusInventeryCSVHeader
  } else if(subSection === "installation_charges") {
    headers = instalationChargesCSVHeader
  } else {
    headers = downloadCsvHeader
  }
  if(!(window.is2wDealer || window.isLogistic)) {
    // headers.push("CHECKSUM")
    headers = [...headers, ...["CHECKSUM"]]
  }
  return headers
}

export const downloadCityCsvHeader = [
  "DEALERID",
  "SKU",
  "SELLER_SKU_ID",
  "MODELID",
  "BRAND",
  "CATEGORY",
  "MODEL_NO",
  "OEM_MODEL_CODE",
  "NAME",
  "CITYID",
  "CITY",
  "STATE",
  "MRP",
  "MOP",
  "REFERENCEPRICE",
  "BEST_REFERENCE_PRICE",
  "OFFERPRICE",
  "STATUS",
  "INVENTORY",
  "INSTALLATION_CHARGES",
];

export const sortOptions = [
  { label: "Product Title", value: "producttitle" },
  { label: "Creation time", value: "creationtime" },
  { label: "Update time", value: "updatetime" },
];

export const sortOptions1 = [
  { label: "Product Title", value: "producttitle" },
  { label: "Creation time", value: "creationtime" },
  { label: "Update time", value: "updatetime" },
  { label: "Out of stock", value: "outofstock" },
  { label: "Expired sku", value: "expiredsku" },
];

export const sortOptions2 = [
  { label: "Product Title", value: "producttitle" },
  { label: "Creation time", value: "creationtime" },
  { label: "Update time", value: "updatetime" },
  { label: "Low stock", value: "lowstock" },
  { label: "Expired sku", value: "expiredsku" },
];

export const twoWheelerCommonSortOptions = [
  { label: "Product Title", value: "producttitle" },
  { label: "Creation Time", value: "creationtime" },
  { label: "Update Time", value: "updatetime" },
];

export const twoWheelerActiveTabSortOptions = () => {
  return [
    ...twoWheelerCommonSortOptions,
    ...[{ label: "Low stock", value: "lowstock" }],
  ];
};
export const twoWheelerInActiveTabSortOptions = () => {
  return [
    ...twoWheelerCommonSortOptions,
    ...[{ label: "Out of Stock", value: "outofstock" }],
  ];
};

export const selectedArr = [
  { label: "SKU", value: "sku" },
  { label: "Model ID", value: "model_id" },
  { label: "Ex Showroom Price", value: "model_code_validation" },
  { label: "RTO Charges", value: "MRP/MOP" },
  { label: "Insurance Price", value: "offer_price" },
  { label: "Stock", value: "inventory" },
];
export const colPreferences = (
  selectedTab,
  isParentDealer,
  isIndividualDealer
) => {
  debugger
  let column = [
    {
      title: "Product Details",
      islogistics: 1,
      items: [
        { label: "Brand", value: "brand" },
        { label: "Category", value: "attribute_set_id" },
        { label: "Model No", value: "model_no" },
        { label: "Image", value: "image" },
      ],
    },
    {
      title: "Price",
      islogistics: 0,
      items: [
        { label: "Installation Charges", value: "installation_charges" },
        { label: "Min/Max", value: "Min/Max" },
        { label: "Ref Price", value: "referenceprice" },
        { label: "Best Reference Price", value: "best_reference_price" },
      ],
    },
    {
      title: "Dealer details",
      islogistics: 1,
      items: [
        {
          label: "Dealer ID",
          value: "dealer_id",
          hide: selectedTab == "new" && isParentDealer && !isIndividualDealer,
        },
        { label: "CITYID", value: "cityid" },
        {
          label: "CITY",
          value: "cityname",
          hide: selectedTab == "new" && isParentDealer,
        },
        { label: "State", value: "statename" },
      ],
    },
    {
      title: "Time",
      islogistics: 0,
      items: [
        { label: "Creation Time", value: "created_at" },
        { label: "Update Time", value: "updated_at" },
      ],
    },
    {
      title: "Visibility",
      islogistics: 1,
      items: [{ label: "E-Store Link", value: "visibleOnWebsite" }],
    },
  ];

  if (window.isLogistic) {
    column = column.filter((pref) => pref.islogistics === 1);
  }

  return column;
};

export const filters = {
  resetAll: "Reset All",
};

export const sortOption = {
  selectSku: "Please select SKUs using Category or Brand filter first",
};

export const priceManagement = {
  offerSheet: "Offer Sheet",
  new: "new",
  filter: "FILTERS",
  filters: "Filters",
  setting: "SETTINGS",
  settings: "Settings",
  edit: "edit",
  auditlog: "auditlog",
  audit_log: "Audit Log",
  createdBy: "Created By:",
  createdOn: "Created On:",
  cityDownload: "City Download",
}
export const colPreferences2W = () => {
  let column = [
    {
      title: "Product Details",
      items: [
        { label: "Brand", value: "brand" },
        { label: "Category", value: "category" },
        { label: "Model No", value: "model_no" },
        { label: "Image", value: "image" },
      ],
    },
    {
      title: "Price",
      items: [{ label: "On Road Price", value: "on_road_price" }],
    },
    {
      title: "Dealer details",
      items: [
        { label: "Dealer ID", value: "dealer_id" },
        { label: "CITYID", value: "cityid" },
        { label: "CITY", value: "city" },
        { label: "State", value: "statename" },
      ],
    },
    {
      title: "Time",
      items: [
        { label: "Creation Time", value: "created_at" },
        { label: "Update Time", value: "updated_at" },
      ],
    },
    {
      title: "Visibility",
      items: [{ label: "E-Store Link", value: "visibleOnWebsite" }],
    },
  ];

  return column;
};



export const createNotificationData = (dashboardResponse) => {
  const localStorageKey = "notificationData" + window.dealerId;
  const prevNotificationData = JSON.parse(localStorage.getItem(localStorageKey));
  const isExpaired = prevNotificationData?.createdAt != moment(new Date()).format("MM/DD/YYYY")

  if (prevNotificationData && !isExpaired) {
    return prevNotificationData;
  }


  if (isExpaired) {
    localStorage.removeItem(localStorageKey)
  }


  const isTimeAfter9AM = moment().hour() >= 9
  debugger;

  if (dashboardResponse && isTimeAfter9AM) {
    const notificationObjects = [];

    Object.keys(dashboardResponse).forEach((key) => {
      let title = "";
      let count = dashboardResponse[key]
      let description = "";
      let tag = "";
      let tab = "";
      let image = "";
      let time = new Date();

      switch (key) {
        case "lowstock":
          title = "Low stock";
          description = `You have ${dashboardResponse[key]} ${title} SKUs pending in your Active Listing. Click here to check.`;
          tag = "inventory";
          tab = "active";
          image = lowStockNotification;
          break;
        case "outofstock":
          title = "Out of Stock";
          description = `You have ${dashboardResponse[key]} ${title} SKUs pending in your In Active Listing. Click here to check.`;
          tag = "inventory";
          tab = "inactive";
          image = outOfStockNotification;
          break;
        case "active_expired_sku":
          title = "Expired SKUs";
          description = `You have ${dashboardResponse[key]} ${title} pending in your Active Listing. Click here to check.`;
          tag = "is_expired";
          tab = "active";
          image = expiredNotification;
          break;
        case "inactive_expired_sku":
          title = "Expired SKUs";
          description = `You have ${dashboardResponse[key]} ${title} pending in your In Active Listing. Click here to check.`;
          tag = "is_expired";
          tab = "inactive";
          image = expiredNotification;
          break;

        case "new_catalog":
          title = "New Catalogue";
          description = `You have ${dashboardResponse[key]} ${title} SKUs pending in your New Listing. Click here to check.`;
          tag = "new_product";
          tab = "new";
          image = newCatalogNotification;
          break;

        case "autoscaled":
          title = "Auto-scaled";
          description = `You have ${dashboardResponse[key]} ${title} SKUs pending in your Active Listing. Click here to check.`;
          tag = "auto_scaled";
          tab = "active";
          image = autoscaledNotification;
          break;

        case "deactivated":
          title = "Deactivated SKUs";
          description = `You have ${dashboardResponse[key]} ${title} pending in your In Active Listing. Click here to check.`;
          tag = "deactivated";
          tab = "inactive";
          image = deactivatedNotification;
          break;

        case "hotselling_active":
          title = "Hot selling";
          description = `You have ${dashboardResponse[key]} ${title} SKUs pending in your Active Listing. Click here to check.`;
          tag = "hot_selling";
          tab = "active";
          image = hotSellingNotification;
          break;

        case "hotselling_inactive":
          title = "Hot selling";
          description = `You have ${dashboardResponse[key]} ${title} SKUs pending in your In Active Listing. Click here to check.`;
          tag = "hot_selling";
          tab = "inactive";
          image = hotSellingNotification;
          break;

        case "hotselling_pricealert":
          title = "Hot selling";
          description = `You have ${dashboardResponse[key]} ${title} SKUs pending in your Price Alert Listing. Click here to check.`;
          tag = "hot_selling";
          tab = "pricealert";
          image = hotSellingNotification;
          break;

        case "hotselling_new":
          title = "Hot selling";
          description = `You have ${dashboardResponse[key]} ${title} SKUs pending in your New Listing. Click here to check.`;
          tag = "hot_selling";
          tab = "new";
          image = hotSellingNotification;
          break;

        default:
          break;
      }

      if (title != "" && count > 0) {
        notificationObjects.push({
          title,
          description,
          tag,
          tab,
          image,
          time,
          isSeen: false,
        });
      }
    });

    console.log("notificationObjects", notificationObjects);
    localStorage.setItem(
      localStorageKey,
      JSON.stringify({
        createdAt: moment(new Date()).format("MM/DD/YYYY"),
        notifications: notificationObjects,
      })
    );
    const notificationData = JSON.parse(
      localStorage.getItem(localStorageKey)
    );
    console.log("notificationData", notificationData);

    return notificationData;

  }
  return null
};
