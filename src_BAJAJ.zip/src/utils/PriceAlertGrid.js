import { cellbg } from "../component/Grid/GridColumns";

const PriceAlertGrid = (selectedTab,selevent) => {
  // const cellbg = (params) => {
  //   return params.rowIndex % 2 !== 0 ? "gray no-border" : "lightgray no-border";
  // };

  const isBestRefPriceselectedinColumns = selevent?.some(
    (item) => item.value == "best_reference_price"
  );
  const isRefPriceselectedinColumns = selevent?.some(
    (item) => item.value == "referenceprice"
  );

  let priceAlert = [
    {
      headerName: "Reference Price",
      field: "referenceprice",
      hide: selectedTab === "pricealert" ? false : !isRefPriceselectedinColumns,
      cellRenderer: "ReferencePrice",
      width: 150,
      minWidth: 150,
      maxWidth: 150,
      cellClass: cellbg,
      cellStyle: {
        borderRight: "1px solid #E8E7E6 !important",
        borderBottom: "1px solid #E8E7E6 !important"
      }
    },
    {
      headerName: "Best Reference Price",
      field: "best_reference_price",
      hide: selectedTab === "pricealert" ? false : !isBestRefPriceselectedinColumns,
      cellRenderer: "Best Reference Price",
      width: 200,
      minWidth: 200,
      maxWidth: 200,
      cellClass: cellbg,
      cellStyle: {
        // borderRight: "1px solid #E8E7E6 !important",
        borderBottom: "1px solid #E8E7E6 !important"
      }
    },
  ];
  return priceAlert;
};

export default PriceAlertGrid;
