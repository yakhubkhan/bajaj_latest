const selectCTA = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: ` ${
      e.selectedTab == "Pricealert"
        ? "Price alert Tab"
        : `${e.selectedTab} Listing Tab`
    } `,
    eventLabel: e.count,
    pageType: e.pageType,
    DealerID: e.dealerId,
    DealerType: e.dealerType,
  });
};

const searchTerm = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: `${e.ListingName} click`,
    eventLabel: e.searchValue,
    pageType: e.pageType,
    DealerID: e.dealerId,
    DealerType: e.dealerType,
  });
};
const onclickLevel2HeaderOptionGTM = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: `${e.selectedList} click `,
    eventLabel: e.eventLabel,
    pageType: e.pageType,
    DealerID: e.dealerId,
    DealerType: e.dealerType,
  });
};
const dealerAgreementDownloadGTM = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: "Dealer Name click",
    eventLabel: "Download Agreement",
    pageType: e.pageType,
    DealerName: e.dealerName,
    DealerID: e.dealerId,
    DealerType: e.dealerType,
  });
};

const auditLogApply = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: "Action on selected",
    eventLabel: e.selectionType,
    pageType: e.pageType,
    DealerID: e.dealerId,
    DealerType: e.dealerType,
  });
};

const resetFilters = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: "Reset All click",
    eventLabel: "Remove selected filter",
    pageType: e.pageType,
    "Dealer ID": e.dealerId,
    DealerType: e.dealerType,
  });
};
const dealerNameGTM = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: "Dealer Name",
    eventLabel: "Dealer_Name_hover_text",
    pageType: e.pageType,
    DealerName: e.dealerName,
    DealerID: e.dealerId,
    DealerType: e.dealerType,
  });
};

const resetSKU = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: "All checkbox click",
    eventLabel: "{{}}",
    // eventAction: `All | ${e.selectedTab} | ${e.filter}`,
    pageType: e.pageType,
    DealerID: e.dealerId,
    DealerType: e.dealerType,
  });
};

const applyFilter = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: `${e.selectedFilter} click`,
    eventLabel: `${e.selectedValue}`,
    pageType: e.pageType,
    DealerID: e.dealerId,
    DealerType: e.dealerType,
  });
};

const uploadOffer = (e) => {
  window.dataLayer.push({
    event: "price_management",
    eventCategory: "Price Management",
    eventAction: `${e.eventName} click`,
    eventLabel: e.label,
    pageType: e.pageType,
    DealerID: e.dealerId,
    DealerType: e.dealerType,
  });
};

const applyOffer = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: `${e.fileType} | ${e.upload}`,
    "Dealer ID": e.dealerId,
    "Dealer Name": e.dealerName,
  });
};

const saveItem = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: "Save click",
    eventLabel: "Stock/Status/Price/update count",
    pageType: e.pageType,
    DealerID: e.dealerId,
    ModelID: e.item.model_id,
    DealerType: e.dealerType,
  });
};

const sortSKU = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: "Sort By click",
    eventLabel: e.listingSelected,
    pageType: e.pageType,
    DealerID: e.dealerId,
    DealerType: e.dealerType,
  });
};

const selectColumnPrefernces = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: "Columns click",
    eventLabel: `${e.selectedItem}`,
    pageType: e.pageType,
    DealerID: e.dealerId,
    DealerType: e.dealerType,
  });
};

const onPageRefresh = (e) => {
  window.dataLayer &&
    window.dataLayer.push({
      event: "Price_Management",
      eventCategory: "Price Management",
      eventAction: "Page Load",
      "Dealer ID": e.dealerId,
      "Dealer Name": e.dealerName,
    });
};

const onCSVUpload = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: `Download CSV ${e.code} | ${e.upload}`,
    "Dealer ID": e.dealerId,
    "Dealer Name": e.dealerName,
  });
};

const onDownloadCSV = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: `${e.eventName} click`,
    eventLabel: e.section,
    pageType: e.pageType,
    DealerID: e.dealerId,
    DealerType: e.dealerType,
  });
};

const selectAllItem = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: `Select_All_Category/CIC/Dealer ID | Filter Selected | Listing Selected | ${e.item}`,
    "Dealer ID": e.dealerId,
    "Dealer Name": e.dealerName,
  });
};

const callProceedDataLayer = (e) => {
  window.dataLayer.push({
    event: "price_management",
    eventCategory: "Price Management",
    eventAction: e.selectedTab,
    "Dealer ID": e.dealerId,
    "Dealer Name": e.dealerName,
  });
};

const selectAllGtm = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: `Select_All_Category/CIC/Dealer ID | Filter Selected | Listing Selected | ${e.label}`,
    "Dealer ID": e.dealerId,
    "Dealer Name": e.dealerName,
  });
};

const resetFilterGtm = (e) => {
  window.dataLayer.push({
    event: "Price_Management",
    eventCategory: "Price Management",
    eventAction: `Reset_Category/CIC/Dealer ID | Filters Selected | Listing Selected | ${e.label}`,
    "Dealer ID": e.dealerId,
    "Dealer Name": e.dealerName,
  });
};

export {
  selectCTA,
  searchTerm,
  auditLogApply,
  resetFilters,
  resetSKU,
  applyFilter,
  applyOffer,
  uploadOffer,
  saveItem,
  sortSKU,
  selectColumnPrefernces,
  onPageRefresh,
  onCSVUpload,
  onDownloadCSV,
  selectAllItem,
  callProceedDataLayer,
  selectAllGtm,
  resetFilterGtm,
  onclickLevel2HeaderOptionGTM,
  dealerAgreementDownloadGTM,
  dealerNameGTM,
};
