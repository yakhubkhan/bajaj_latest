import React from "react";

import Dashboard from "./Pages/Dashboard";

const App = () => {
  return <Dashboard />;
};

export default App;
