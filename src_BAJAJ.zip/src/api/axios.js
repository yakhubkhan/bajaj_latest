/*
 * @Author: emb-nirmgan
 * @Date: 2018-09-24 15:18:36
 * @Last Modified by: manappa
 * @Last Modified time: 2019-11-04 19:25:51
 */
import axios from "axios";
const hostname = window && window.location && window.location.hostname;

var baseURL = "";
var csvURL = "";

if (hostname === "localhost") {
  baseURL = "https://bfl.qa.emimalls.in/dps/web/api";
  csvURL = "https://bfl.qa.emimalls.in/dps/web/app";
}
if (hostname === "bfl.dev.emimalls.in") {
  baseURL = "https://bfl.dev.emimalls.in/dps/web/api";
  csvURL = "https://bfl.dev.emimalls.in/dps/web/app";
}

if (hostname === "estore.dev.bfsgodirect.com") {
  baseURL = "https://estore.dev.bfsgodirect.com/dps/web/api";
  csvURL = "https://estore.dev.bfsgodirect.com/dps/web/app";
}
if (hostname === "bfsd.qa.bfsgodirect.com") {
  baseURL = "https://bfsd.qa.bfsgodirect.com/dps/web/api";
  csvURL = "https://bfsd.qa.bfsgodirect.com/dps/web/app";
}
if (hostname === "bfl.qa.emimalls.in") {
  baseURL = "https://bfl.qa.emimalls.in/dps/web/api";
  csvURL = "https://bfl.qa.emimalls.in/dps/web/app";
}
if (hostname === "bfl.uat.emimalls.in") {
  baseURL = "https://bfl.uat.emimalls.in/dps/web/api";
  csvURL = "https://bfl.uat.emimalls.in/dps/web/app";
}
if (hostname === "bfsd.uat.bfsgodirect.com") {
  baseURL = "https://pm.uat.bfsgodirect.com/dps/web/api";
  csvURL = "https://pm.uat.bfsgodirect.com/dps/web/app";
}
if (hostname === "n2p.bajajfinservmarkets.in") {
  baseURL = "https://n2p.bajajfinservmarkets.in/dps/web/api";
  csvURL = "https://n2p.bajajfinservmarkets.in/dps/web/app";
}
if (hostname === "n2p.bajajmall.in") {
  baseURL = "https://n2p.bajajmall.in/dps/web/api";
  csvURL = "https://n2p.bajajmall.in/dps/web/app";
}
if (hostname === "dps.embdev.in/api") {
  baseURL = "http://dps.embdev.in/api";
  csvURL = "http://dps.embdev.in/api";
}
if (hostname === "www.bajajfinservmarkets.in") {
  baseURL = "https://pm.bajajfinservmarkets.in/dps/web/api";
  csvURL = "https://pm.bajajfinservmarkets.in/dps/web/app";
}
if (hostname === "www.bajajmall.in") {
  baseURL = "https://pm.bajajmall.in/dps/web/api";
  csvURL = "https://pm.bajajmall.in/dps/web/app";
}

export const axiospricemgmt = axios.create({
  baseURL,
  headers: {},
  responseType: "json",
});
export const axioscsvdata = axios.create({
  csvURL,
  headers: {},
  responseType: "json",
});

export const uploadUrl = csvURL;
export { baseURL };
