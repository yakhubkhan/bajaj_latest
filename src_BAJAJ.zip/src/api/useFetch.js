import { useState } from "react";
import { baseURL } from "./axios";
import axios from "axios";

const useFetch = (method, url, body) => {
  const [data, setData] = useState();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState();
  const [extraObj, setExtraObj] = useState();


  const fetchData = async (newURL, newBody, extraObj) => {
    setIsLoading(true);
    try {
      const resp = await axios({
        method: method,
        url: baseURL + (newURL || url),
        data: newBody || body,
      });
      const data = await resp?.data;
      setExtraObj(extraObj)
      setData(data);
      setIsLoading(false);
    } catch (error) {
      setError(error);
      setIsLoading(false);
    }
  };
  return [{ data, isLoading, error }, fetchData, extraObj];
};

export default useFetch;
