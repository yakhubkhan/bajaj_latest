import React, { useEffect, useState } from "react";
import "./Header.css";
import userLogo from "../images/Dealer_Profile_Logo.svg";
import BajajMallLogo from "../images/headerLogo.svg";
import SearchInput from "../component/SearchInput/SearchInput";
import useFetch from "../api/useFetch";
import Notification from "./Notification";
import { createNotificationData } from "../utils/Constant";
import { dealerAgreementDownloadGTM, dealerNameGTM } from "../../src/gtm";

const Header = (props) => {
  const [isOpen, setIsOpen] = useState(false);
  const [notificationData, setNotificationData] = useState();

  const [getFiltersDataResp, fetchDealerAgreement] = useFetch(
    "POST",
    "/getdealeragreementpdfdownloads",
    null
  );

  useEffect(() => {
    if (getFiltersDataResp.data) {
      const aggrementName = getFiltersDataResp.data.data?.path
        ?.split("/")
        ?.pop();
      download_file(getFiltersDataResp.data.data.path, aggrementName);
    }
  }, [getFiltersDataResp.data]);

  useEffect(() => {
    console.log("props.dashboardResponse", props.dashboardResponse);
    if (props.dashboardResponse) {
      const notificationData = createNotificationData(props.dashboardResponse);
      setNotificationData(notificationData);
    }
  }, [props.dashboardResponse]);

  /* Helper function for download */
  function download_file(fileURL, fileName) {
    // for non-IE
    if (!window.ActiveXObject) {
      var save = document.createElement("a");
      save.href = fileURL;
      save.target = "_blank";
      var filename = fileURL.substring(fileURL.lastIndexOf("/") + 1);
      save.download = fileName || filename;
      if (
        navigator.userAgent.toLowerCase().match(/(ipad|iphone|safari)/) &&
        navigator.userAgent.search("Chrome") < 0
      ) {
        document.location = save.href;
        // window event not working here
      } else {
        var evt = new MouseEvent("click", {
          view: window,
          bubbles: true,
          cancelable: false,
        });
        save.dispatchEvent(evt);
        (window.URL || window.webkitURL).revokeObjectURL(save.href);
      }
    }

    // for IE < 11
    else if (!!window.ActiveXObject && document.execCommand) {
      var _window = window.open(fileURL, "_blank");
      _window.document.close();
      _window.document.execCommand("SaveAs", true, fileName || fileURL);
      _window.close();
    }
  }
  /* download for agreement */
  const downloadagreement = () => {
    const payload = {
      pm_key: props.md5value,
      data: {
        dealerId: props.dealerid,
      },
    };
    fetchDealerAgreement(null, payload);
    dealerAgreementDownloadGTM({
      dealerId: props.dealerid,
      dealerName: props.dealerName,
      selectedTab: props.selectedTab,
      pageType: "Price Management",
      dealerType: window.dealer_type,
      selectedFilter: props.selectedFilter,
    });
  };
  /* to set button open or not */
  const openbutton = () => {
    dealerNameGTM({
      dealerId: props.dealerid,
      dealerName: props.dealerName,
      selectedTab: props.selectedTab,
      pageType: "Price Management",
      dealerType: window.dealer_type,
      selectedFilter: props.selectedFilter,
    });
    if (!isOpen) {
      setIsOpen(true);
    } else {
      setIsOpen(false);
    }
  };

  const is2wDealer = window.is2wDealer;
  return (
    <div className="main_header disp_flex spaceBtwn">
      <div className="disp_flex alignitemsCenter">
        <img className="img_cls" src={BajajMallLogo} alt="logo"></img>
      </div>
      <div className="disp_flex alignitemsCenter">
        <SearchInput
          callSearch={props.callSearch}
          resetSearch={props.resetSearch}
          searchParam={props.searchParam}
          getSearchVal={props.getSearchVal}
        ></SearchInput>

        {props.dashboardResponse && !window.isLogistic && !window.is2wDealer ? (
          <Notification
            notificationData={notificationData}
            setNotificationData={setNotificationData}
            onClickNotification={props.onClickNotification}
          />
        ) : (
          ""
        )}

        <div className="disp_flex alignitemsCenter">
          <div className="user_icon hoverText" data-hover={props.supplierName}>
            <img
              className="dealeUuserIcon"
              src={userLogo}
              alt="user_logo"
            ></img>
          </div>

          <div>
            <div onClick={openbutton}>
              {props.supplierName && (
                <div
                  className="dealerName hoverText"
                  data-hover={props.supplierName}
                >
                  {`${props.supplierName.substring(0, 12)}...`}
                </div>
              )}

              <div className="dealerID">Dealer id:{window.dealerId}</div>
            </div>
            {isOpen && (
              <div className="agreement">
                <div className="download-agreement" onClick={downloadagreement}>
                  <span className="agreement-text">Download Agreement</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
