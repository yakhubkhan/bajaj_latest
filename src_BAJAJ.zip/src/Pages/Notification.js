import React, { useEffect, useState } from "react";
import "./Notification.css";
import HeaderNotificationBell from "../images/headerNotificationBell.svg";
import moment from "moment";
import { createNotificationData } from "../utils/Constant";
let isNotificationAnimated = false;

const Notification = (props) => {
  useEffect(() => {
    const notificationData = createNotificationData(null);
    const isContainsAnyUnseenNotification =
      notificationData?.notifications?.some((item) => item.isSeen == false);

    if (
      props.notificationData &&
      !isNotificationAnimated &&
      isContainsAnyUnseenNotification
    ) {
      startBellAnimation();
    }
  }, [props.notificationData]);

  const startBellAnimation = () => {
    isNotificationAnimated = true;
    if (document.getElementById("bellDiv")) {
      document.getElementById("bellDiv").classList.add("bellAnimation");
    }
    timerToStopBellAnimation();
  };

  const stopBellAnimation = () => {
    if (document.getElementById("bellDiv")) {
      document.getElementById("bellDiv").classList.remove("bellAnimation");
    }
  };

  const timerToStopBellAnimation = () => {
    const bellTimer = setInterval(() => {
      stopBellAnimation();
      clearInterval(bellTimer);
    }, 5000);
  };

  const notificationItem = (item, index) => {
    const isFirstunReadNotification =
      !item.isSeen &&
      (index == 0 || props.notificationData?.notifications[index - 1]?.isSeen);
    const isLasttunReadNotification =
      !item.isSeen &&
      (index == props.notificationData?.notifications?.length - 1 ||
        props.notificationData?.notifications[index + 1]?.isSeen);

    return (
      <div
        className={
          "disp_flex notificationItem" +
          (item.isSeen ? "" : " isUnreadNotification") +
          (isFirstunReadNotification ? " isFirstunReadNotification" : "") +
          (isLasttunReadNotification ? " isLasttunReadNotification" : "")
        }
        onClick={() => {
          item.isSeen = true;
          const notificationData = createNotificationData(null);
          notificationData.notifications.splice(index, 1, item);
          localStorage.setItem(
            "notificationData" + window.dealerId,
            JSON.stringify(notificationData)
          );
          props.setNotificationData(notificationData);
          debugger;
          props.onClickNotification(item.tag, item.tab);
        }}
      >
        <img className="notificationIcon" height="32px" src={item.image} />
        <div>
          <div className="disp_flex notificationTitileContainer">
            <div className="notificationTitle">{item.title}</div>
            <div className="notificationTime">
              {moment(item.time).fromNow()}
            </div>
          </div>
          <div className="notificationDescription">{item.description}</div>
        </div>
      </div>
    );
  };

  return (
    <div className="notificationBell">
      <div class="dropdown">
        <div
          className="dropdown-toggle removeHardDrpdwnIcon"
          data-toggle="dropdown"
        >
          <div
            id="bellDiv"
            className="bellContainer"
            // onClick={() => startBellAnimation()}
          >
            <img height="35px" src={HeaderNotificationBell} />
          </div>
        </div>
        <div class="dropdown-menu dropdown-menu-right notificationMenu">
          <div className="notificationText">Notifications</div>
          {props.notificationData?.notifications?.length > 0 ? (
            <div className="notificationContainer">
              {props.notificationData?.notifications?.map((item, index) => {
                return notificationItem(item, index);
              })}
            </div>
          ) : (
            <div className="noNotifications">No notifications found</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Notification;
