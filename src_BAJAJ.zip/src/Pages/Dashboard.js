// /* eslint-disable */
// import React, { useEffect, useState } from "react";
// import ".././App.css";
// import TabsComponent from ".././component/Tabs/TabsComponent.js";
// import CryptoJS from "crypto-js";
// import GoToTopLogo from "../../src/images/Top_Icon.png";
// import FullPageLoader from ".././component/SkeletonLoaders/FullPageLoader";
// import useFetch from "../api/useFetch";
// import { onPageRefresh } from "../gtm";
// import DashboardIr from "../component/InventoryReport/Dashboard_IR";

// const Dashboard = () => {
//   const [isEqual, setIsEqual] = useState(false);
//   const [isParentDealer, setIsParentDealer] = useState(false);
//   const [md5Format, setMd5Format] = useState();
//   const [aggrement, setAggrement] = useState({});
//   const [isScrolled, setIsScrolled] = useState("");
//   const [ispageLoading, setIspageLoading] = useState(true);
//   const [dealerName, setsupplierName] = useState(true);

//   const [isIR, setisIr] = useState(false);
//   const hostname = window && window.location && window.location.hostname;
//   let url = window.location.href;
//   var urlSplit = url.split("/")[hostname === "localhost" ? 3 : 4];
//   let auth = urlSplit.split("=")[1].split("&")[0];

//   const [{ data }, fetchData] = useFetch("POST", "/validatedealer", {
//     auth,
//   });
//   const [getmagentodeliveryflagResp, getmagentodeliveryflagapi] = useFetch(
//     "POST",
//     "/getmagentodeliveryflag"
//   );

//   const [isvalidagreementResp, isvalidagreementFetchData] = useFetch(
//     "POST",
//     "/isvalidagreement",
//     null
//   );

//   const handleScroll = (event) => {
//     setIsScrolled(window.scrollY !== 0);
//   };

//   useEffect(() => {
//     window.onload = () => {
//       setIspageLoading(false);
//     };
//     return () => {
//       window.removeEventListener("scroll", handleScroll);
//     };
//   }, []);

//   useEffect(() => {
//     window.addEventListener("scroll", handleScroll);
//     if (urlSplit === "") {
//       window.open("https://www.bajajfinservmarkets.in/emi-store", "_self");
//     } else {
//       fetchData();
//     }
//   }, []);

//   useEffect(() => {
//     if (data) {
//       // console.log("opopop", data);
//       var isEqual = false;
//       setIsEqual(false);
//       if (typeof data?.status !== "undefined" && data.status == 1) {
//         // console.log("resps", data);
//         var dealerId = data.data?.dealer_id;
//         setsupplierName(data.data?.supplier_name);
//         let strDealerId = dealerId.toString();
//         let md5dlerid = CryptoJS.MD5(strDealerId);
//         let md5format = md5dlerid.toString();
//         setMd5Format(md5format);
//         window.dealerId = dealerId;
//         window.is2wDealer = data.data?.dealer_type == "2w";
//         // window.is2wDealer = true;
//         // window.isLogistic = true;
//         if (typeof data.data.parent_dealer_id !== "undefined") {
//           window.dealerId = dealerId;
//           dealerId = data.data.parent_dealer_id;
//         } else {
//           setIsParentDealer(true);
//         }
//         setIsEqual(true);
//         isEqual = true;
//         isvalidagreementFetchData(null, {
//           dealer_id: data.data.parent_dealer_id || window.dealerId,
//         });
//         getmagentodeliveryflagapi(null, {
//           pm_key: md5format,
//           data: {
//             dealerId: window.dealerId,
//           },
//         });
//         onPageRefresh({
//           dealerId: dealerId,
//           dealerName: data.data.supplier_name ? data.data.supplier_name : "",
//         });
//       }
//       if (!isEqual) {
//         window.open("https://www.bajajfinservmarkets.in/stores/", "_self");
//       }
//     }
//   }, [data]);

//   useEffect(() => {
//     if (isvalidagreementResp.data) {
//       setAggrement(isvalidagreementResp.data);
//     }
//   }, [isvalidagreementResp.data]);

//   const setInventoryReport = (value) => {
//     setisIr(value);
//   };

//   if (ispageLoading) {
//     return <FullPageLoader />;
//   }

//   return (
//     <div className="App">
//       {isEqual ? (
//         <div>
//           {!isIR ? (
//             <TabsComponent
//               validDealderId={window.dealerId}
//               supplierName={dealerName}
//               dealer={window.dealerId}
//               isParentDealer={isParentDealer}
//               dealerId={window.dealerId}
//               md5value={md5Format}
//               setInventoryReport={setInventoryReport}
//               aggrement={aggrement}
//               agrefresh="false"
//               getmagentodeliveryflagResp={getmagentodeliveryflagResp}
//             ></TabsComponent>
//           ) : (
//             <DashboardIr setInventoryReport={setInventoryReport}></DashboardIr>
//           )}
//           {isScrolled && (
//             <div
//               className="goToTopContainer"
//               onClick={() => window.scrollTo(0, 0)}
//             >
//               <img src={GoToTopLogo} alt="logo" className="img_up"></img>
//               {/* <div class="icon" onClick={() => window.scrollTo(0, 0)}></div> */}
//             </div>
//           )}
//         </div>
//       ) : (
//         ""
//       )}
//     </div>
//   );
// };

// export default Dashboard;
/* eslint-disable */
import React, { useEffect, useState } from "react";
import ".././App.css";
import TabsComponent from ".././component/Tabs/TabsComponent.js";
import CryptoJS from "crypto-js";
import GoToTopLogo from "../../src/images/Top_Icon.png";
import FullPageLoader from ".././component/SkeletonLoaders/FullPageLoader";
import useFetch from "../api/useFetch";
import { onPageRefresh } from "../gtm";
import DashboardRR from "../component/ReturnReplacement/Dashboard_RR";
import DashboardIr from "../component/InventoryReport/Dashboard_IR";
import Homepage from "../Home/Homepage";

const Dashboard = () => {
  const [isEqual, setIsEqual] = useState(false);
  const [isParentDealer, setIsParentDealer] = useState(false);
  const [md5Format, setMd5Format] = useState();
  const [aggrement, setAggrement] = useState({});
  const [isScrolled, setIsScrolled] = useState("");
  const [ispageLoading, setIspageLoading] = useState(true);
  const [dealerName, setsupplierName] = useState(true);
  const [level2HeaderValue, setLevel2HeaderValue] = useState(0)
  const [replacementFlag, setReplacementFlag] = useState();

  const hostname = window && window.location && window.location.hostname;
  let url = window.location.href;
  var urlSplit = url.split("/")[hostname === "localhost" ? 3 : 4];
  let auth = urlSplit.split("=")[1].split("&")[0];

  const [{ data }, fetchData] = useFetch("POST", "/validatedealer", {
    auth,
  });
  const [getmagentodeliveryflagResp, getmagentodeliveryflagapi] = useFetch(
    "POST",
    "/getmagentodeliveryflag"
  );

  const [isvalidagreementResp, isvalidagreementFetchData] = useFetch(
    "POST",
    "/isvalidagreement",
    null
  );

  const handleScroll = (event) => {
    setIsScrolled(window.scrollY !== 0);
  };

  useEffect(() => {
    window.onload = () => {
      setIspageLoading(false);
    };
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    if (urlSplit === "") {
      window.open("https://www.bajajfinservmarkets.in/emi-store", "_self");
    } else {
      fetchData();
    }
  }, []);

  useEffect(() => {
    if (data) {
      var isEqual = false;
      setIsEqual(false);
      if (typeof data?.status !== "undefined" && data.status === 1) {
        var dealerId = data.data?.dealer_id;
        setsupplierName(data.data?.supplier_name);
        setReplacementFlag(data.data?.replacement_flag);
        let strDealerId = dealerId.toString();
        let md5dlerid = CryptoJS.MD5(strDealerId);
        let md5format = md5dlerid.toString();
        setMd5Format(md5format);
        window.dealerId = dealerId;
        const dealer_type = data.data?.dealer_type;
        window.dealer_type = dealer_type;
        window.is2wDealer =
          dealer_type == "2W" ||
          dealer_type == "2W_Urban" ||
          dealer_type == "2W_Rural";
        // window.is2wDealer = true;
        // window.isLogistic = true;
        if (typeof data.data.parent_dealer_id !== "undefined") {
          window.dealerId = dealerId;
          dealerId = data.data.parent_dealer_id;
        } else {
          setIsParentDealer(true);
        }
        setIsEqual(true);
        isEqual = true;
        !window.is2wDealer &&
          isvalidagreementFetchData(null, {
            dealer_id: data.data.parent_dealer_id || window.dealerId,
          });
        getmagentodeliveryflagapi(null, {
          pm_key: md5format,
          data: {
            dealerId: window.dealerId,
          },
        });
        onPageRefresh({
          dealerId: dealerId,
          dealerName: data.data.supplier_name ? data.data.supplier_name : "",
        });
      }
      if (!isEqual) {
        window.open("https://www.bajajfinservmarkets.in/stores/", "_self");
      }
    }
  }, [data]);

  useEffect(() => {
    if (isvalidagreementResp.data) {
      setAggrement(isvalidagreementResp.data);
    }
  }, [isvalidagreementResp.data]);

  if (ispageLoading) {
    return <FullPageLoader />;
  }

  const getHomeDashboard = () => {
    switch (level2HeaderValue) {
      case 'home':
        return <Homepage
        supplierName={dealerName}
        setLevel2HeaderValue = {setLevel2HeaderValue}
         />
      case 0:
      case 1:
        return (
          <TabsComponent
            validDealderId={window.dealerId}
            supplierName={dealerName}
            dealer={window.dealerId}
            isParentDealer={isParentDealer}
            dealerId={window.dealerId}
            md5value={md5Format}
            aggrement={aggrement}
            agrefresh="false"
            getmagentodeliveryflagResp={getmagentodeliveryflagResp}
            level2HeaderValue={level2HeaderValue}
            setLevel2HeaderValue={setLevel2HeaderValue}
            replacementFlag={replacementFlag}
          ></TabsComponent>
        );
      case 2:
        return (
          <DashboardRR
            supplierName={dealerName}
            dealer={window.dealerId}
            isParentDealer={isParentDealer}
            dealerId={window.dealerId}
            md5value={md5Format}
            level2HeaderValue={level2HeaderValue}
            setLevel2HeaderValue={setLevel2HeaderValue}
            replacementFlag={replacementFlag}
          ></DashboardRR>
        );
      case 3:
        return (
          <DashboardIr
            validDealderId={window.dealerId}
            supplierName={dealerName}
            dealer={window.dealerId}
            isParentDealer={isParentDealer}
            dealerId={window.dealerId}
            md5value={md5Format}
            dealerGroupId={data?.data?.dealer_grp_id}
            setLevel2HeaderValue={setLevel2HeaderValue}
          ></DashboardIr>
        );

      default:
        break;
    }
  };
  return (
    <div className="App">
      {isEqual ? (
        <div>
          {getHomeDashboard()}

          {isScrolled && (
            <div
              className="goToTopContainer"
              onClick={() => window.scrollTo(0, 0)}
            >
              <img src={GoToTopLogo} alt="logo" className="img_up"></img>
            </div>
          )}
        </div>
      ) : (
        ""
      )}
    </div>
  );
};

export default Dashboard;
