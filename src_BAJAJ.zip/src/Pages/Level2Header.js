import React from "react";
import "./Header.css";
import "./Level2Header.css";
import userLogo from "../images/Vector.svg";

const Level2Header = (props) => {
  const onClickTab = (newValue) => {
    window.isLogistic = newValue == 1;
    props.onChange(newValue);
  };
  return (
    <>
      <div className="disp_flex Level2HeaderContainer">
        <div className="homeIcon_header"  
        // onClick={() => onClickTab("home")}
        >
          <img className="homeIcon" src={userLogo} alt="user_logo"></img>
        </div>
        <div className="disp_flex  Level2_disp">
          <div
            className={
              "level2HeaderTitle" +
              (props.isLoading ? " level2TabLoading" : "") +
              (props.value === 0 ? " bottomBorder" : "")
            }
            onClick={() => onClickTab(0)}
          >
            Listing Management
          </div>
          <div
            className={
              "level2HeaderTitle" +
              (props.isLoading ||
              props.getmagentodeliveryflagResp?.data?.payload == null
                ? " level2TabLoading"
                : "") +
              (props.value === 1 ? " bottomBorderLogistic" : "")
            }
            onClick={() => onClickTab(1)}
          >
            Logistics Management
          </div>
          {props.isParentDealer && !props.isIndividualDealer && (
            <div
              className={
                "level2HeaderTitle" +
                // (props.isLoading ||
                // props.getmagentodeliveryflagResp?.data?.payload == null
                //   ? " level2TabLoading"
                //   : "") +
                (props.value == 3 ? " bottomBorder" : "")
              }
              onClick={() => props.onChange(3)}
            >
              Reports
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Level2Header;
